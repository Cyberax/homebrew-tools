# Locking

The locking is managed mostly at coarse-grained level of store managers, we just lock them
completely when a change is warranted.

Locks must be acquired in the following order to avoid deadlocks:
1. Queue store (and individual queues)
2. Node store (and individual nodes)
3. Task store (and individual tasks)
4. Task
5. Subtask

Locks are not recursive and this order MUST also apply even for read-only locks. Otherwise
deadlocks might occur if the upper lock is waiting on getting a full lock.

# Mixing read and write locks
It's safe to mix read and write locks if the locking order is conserved and read and write locks
are not interleaved.

So it's safe to do:
1) Write-lock the queue.
2) Write-lock node store.
3) Read-lock an individual node and modify its state.

# Task and node statuses

Task and node states are handled somewhat differently, the locking is more fine-grained here - 
each subtask has its own lock to manage its node assignments. For the overall task the status
is updated using atomics to avoid locks.
