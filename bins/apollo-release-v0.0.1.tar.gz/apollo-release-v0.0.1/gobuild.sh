#!/bin/bash
set -eux

export GOPATH="$(pwd)/.gobuild"
SRCDIR="${GOPATH}/src"

[ -d ${GOPATH} ] && rm -rf ${GOPATH}
mkdir -p ${GOPATH}/{src,pkg,bin}
mkdir -p ${SRCDIR}/apollo
cp -a $(pwd)/* ${SRCDIR}/apollo
cd ${SRCDIR}/apollo && dep ensure
cd ${SRCDIR}/apollo && make
