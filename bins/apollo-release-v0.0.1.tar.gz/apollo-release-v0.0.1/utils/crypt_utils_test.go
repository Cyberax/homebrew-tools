package utils

import (
	"crypto/rand"
	"crypto/tls"
	"crypto/x509"
	"encoding/base64"
	"encoding/pem"
	"github.com/stretchr/testify/assert"
	"golang.org/x/crypto/nacl/box"
	"net"
	"testing"
)

func TestGenerateRandId(t *testing.T) {
	assert.Equal(t, 16, len(*GenerateRandId()))
	assert.Equal(t, 32, len(*GenerateRandIdSized(16)))
}

func TestSecureBox(t *testing.T) {
	cliPublicKey, cliPrivateKey, _ := box.GenerateKey(rand.Reader)
	senderPublicKey, senderPrivateKey, _ := box.GenerateKey(rand.Reader)

	encrypted := EncryptMessage("hello,world", cliPublicKey, senderPrivateKey)
	message, ok := DecryptMessage(encrypted,
		base64.StdEncoding.EncodeToString(senderPublicKey[:]), cliPrivateKey)
	assert.Equal(t, true, ok)
	assert.Equal(t, "hello,world", message)

	// Corrupt the message
	encrypted = "nopenope" + encrypted[8:]
	_, ok = DecryptMessage(encrypted,
		base64.StdEncoding.EncodeToString(senderPublicKey[:]), cliPrivateKey)
	assert.Equal(t, false, ok)
}

func TestSignatures(t *testing.T) {
	ca := MakeCACert()

	// Create a CSR now
	dnsNames := []string{"a.com"}
	ips := []net.IP{net.ParseIP("1.2.3.4"), net.ParseIP("AA:BB:CC:DD::FF")}

	_, csrBytes := MakeKeyAndCSR()

	tlsCaCert, e := tls.X509KeyPair([]byte(ca.CertData), []byte(ca.KeyData))
	assert.NoError(t, e)

	signedCert, e := SignCertificateRequest(csrBytes, tlsCaCert, dnsNames, ips)
	assert.NoError(t, e)

	block, _ := pem.Decode(signedCert)
	certificate, e := x509.ParseCertificate(block.Bytes)
	assert.NoError(t, e)

	// Now check that the CA is chained correctly
	caBlock, _ := pem.Decode([]byte(ca.CertData))
	caCert, e := x509.ParseCertificate(caBlock.Bytes)
	assert.NoError(t, e)
	assert.NoError(t, certificate.CheckSignatureFrom(caCert))

	// Check subjects
	assert.Equal(t, "a.com", certificate.DNSNames[0])
	assert.Equal(t, net.ParseIP("1.2.3.4").String(),
		certificate.IPAddresses[0].String())
	assert.Equal(t, net.ParseIP("AA:BB:CC:DD::FF").String(),
		certificate.IPAddresses[1].String())
}
