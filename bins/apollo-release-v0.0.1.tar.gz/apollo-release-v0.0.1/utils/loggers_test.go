package utils

import (
	"bytes"
	"github.com/sirupsen/logrus"
	"github.com/stretchr/testify/assert"
	"golang.org/x/net/context"
	"log"
	"os"
	"runtime"
	"strconv"
	"strings"
	"sync"
	"testing"
	"time"
)

func line() int {
	_, _, line, _ := runtime.Caller(1)
	return line
}

type syncBuffer struct {
	b bytes.Buffer
	m sync.Mutex
}
func (b *syncBuffer) Read(p []byte) (n int, err error) {
	b.m.Lock()
	defer b.m.Unlock()
	return b.b.Read(p)
}
func (b *syncBuffer) Write(p []byte) (n int, err error) {
	b.m.Lock()
	defer b.m.Unlock()
	return b.b.Write(p)
}
func (b *syncBuffer) String() string {
	b.m.Lock()
	defer b.m.Unlock()
	return b.b.String()
}

func TestLoggerFilenames(t *testing.T) {
	var buffer syncBuffer
	// Setup logrus
	logrus.AddHook(NewFilenameLoggerHook())
	logrus.SetOutput(&buffer)
	defer logrus.SetOutput(os.Stderr)

	// Use logrus for standard log output
	log.SetFlags(log.Lshortfile)
	log.SetOutput(logrus.StandardLogger().Writer())

	log.Printf("This is a test from stdlog %d", 42); line1 := line()
	logrus.Warnf("This is logrus warning %d", 55); line2 := line()

	// Standard logging is asynchronous. Wait for it to be flushed.
	// PS: I feel dirty.
	// TODO: whack that part of Logrus with a stick.
	time.Sleep(2000*time.Millisecond)

	split := strings.Split(buffer.String(), "\n")
	prefix1 := "source=\"loggers_test.go:" + strconv.Itoa(line1) + "\""
	prefix2 := "source=\"utils/loggers_test.go:" + strconv.Itoa(line2) + "\""

	assert.True(t, strings.HasSuffix(split[0], prefix1) || strings.HasSuffix(split[1], prefix1))
	assert.True(t, strings.HasSuffix(split[0], prefix2) || strings.HasSuffix(split[1], prefix2))
}

func TestContextLogging(t *testing.T) {
	var buffer syncBuffer
	// Setup logrus
	logrus.AddHook(NewFilenameLoggerHook())
	logrus.SetOutput(&buffer)

	ctx := SaveLoggerToContext(context.Background(), logrus.StandardLogger())
	ctx = SaveReqIdToContext(ctx, "req1")
	assert.Equal(t, "req1", GetReqIdFromContext(ctx))

	AddLoggerFields(ctx, logrus.Fields{"tag": "test"})
	CL(ctx).Warnf("This is a test")

	split := strings.Split(buffer.String(), "\n")
	assert.True(t, strings.Contains(split[0], "This is a test"))
}

func TestBadContext(t *testing.T) {
	assert.Panics(t, func() {
		AddLoggerFields(context.Background(), logrus.Fields{"tag": "test"})
	})

	assert.Panics(t, func() {
		GetReqIdFromContext(context.Background())
	})
}
