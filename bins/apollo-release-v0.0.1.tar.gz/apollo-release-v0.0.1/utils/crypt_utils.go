package utils

import (
	"bytes"
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/tls"
	"crypto/x509"
	"crypto/x509/pkix"
	"encoding/base64"
	"encoding/hex"
	"encoding/pem"
	"errors"
	"golang.org/x/crypto/nacl/box"
	"io"
	"math/big"
	"net"
	"time"
)

type EC25519PublicKey *[32]byte
type EC25519PrivateKey *[32]byte

type TlsData struct {
	CertData string
	KeyData string
}

const SignAlgo = x509.ECDSAWithSHA512

func GenerateRandId() *string {
	return GenerateRandIdSized(8)
}

func GenerateRandIdSized(bytes int) *string {
	r := make([]byte, bytes)
	_, err := rand.Read(r)
	if err != nil {
		panic("Failed to get random data")
	}
	val := hex.EncodeToString(r)
	return &val
}

func EncryptMessage(data string, publicKey EC25519PublicKey,
	senderPrivateKey EC25519PrivateKey) string {

	var nonce [24]byte
	if _, err := io.ReadFull(rand.Reader, nonce[:]); err != nil {
		panic(err)
	}

	// Seal the message, using the first 24 bytes to store the nonce
	encrypted := box.Seal(nonce[:], []byte(data), &nonce, publicKey, senderPrivateKey)
	return base64.StdEncoding.EncodeToString(encrypted)
}

func DecryptMessage(boxStr string, senderPublicKeyStrBase64 string,
	ourPrivateKey EC25519PrivateKey) (string, bool) {

	senderPublicKeyBytes, err := base64.StdEncoding.DecodeString(senderPublicKeyStrBase64)
	if err != nil {
		return "", false
	}
	var senderPublicKey [32]byte
	copy(senderPublicKey[:], senderPublicKeyBytes)

	boxBytes, err := base64.StdEncoding.DecodeString(boxStr)
	if err != nil {
		return "", false
	}

	var decryptNonce [24]byte
	copy(decryptNonce[:], boxBytes[:24])

	decrypted, ok := box.Open(nil, boxBytes[24:], &decryptNonce, &senderPublicKey, ourPrivateKey)
	if !ok {
		return "", false
	}

	return string(decrypted), true
}

func MakeCACert() *TlsData {
	serialNumberLimit := new(big.Int).Lsh(big.NewInt(1), 128)
	serialNumber, err := rand.Int(rand.Reader, serialNumberLimit)
	PanicIfError(err)

	// Create a simpel self-signed certificate and key
	template := &x509.Certificate {
		IsCA : true,
		DNSNames: []string{"*"}, // This will allow validation to go through for any name
		BasicConstraintsValid : true,
		SubjectKeyId : []byte{1,2,3},
		SerialNumber : serialNumber,
		Subject : pkix.Name{
			Country : []string{"N/A"},
			Organization: []string{"Apollo"},
		},
		NotBefore : time.Now(),
		NotAfter : time.Now().AddDate(50,0,0),
		// see http://golang.org/pkg/crypto/x509/#KeyUsage
		ExtKeyUsage : []x509.ExtKeyUsage{x509.ExtKeyUsageClientAuth, x509.ExtKeyUsageServerAuth},
		KeyUsage : x509.KeyUsageDigitalSignature|x509.KeyUsageCertSign,
	}

	// generate private key
	privatekey, err := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	PanicIfError(err)
	publickey := &privatekey.PublicKey

	// create a self-signed certificate. template = parent
	var parent = template
	cert, err := x509.CreateCertificate(rand.Reader, template, parent, publickey,privatekey)
	PanicIfError(err)
	var certOut bytes.Buffer
	err = pem.Encode(io.Writer(&certOut), &pem.Block{Type: "CERTIFICATE", Bytes: cert})
	PanicIfError(err)

	// save private key
	privateKeyBytes, err := x509.MarshalECPrivateKey(privatekey)
	PanicIfError(err)
	var keyOut bytes.Buffer
	err = pem.Encode(io.Writer(&keyOut), &pem.Block{Type: "PRIVATE KEY", Bytes: privateKeyBytes})
	PanicIfError(err)

	return &TlsData{
		CertData: string(certOut.Bytes()),
		KeyData: string(keyOut.Bytes()),
	}
}

// Generate a new private key with dnsNames and IPs as SANs and create a
// certificate signing request for it
func MakeKeyAndCSR() ([]byte, []byte) {
	// generate private key
	privateKey, err := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	PanicIfError(err)

	marshalledPrivKey, err := x509.MarshalECPrivateKey(privateKey)
	PanicIfError(err)

	var privKeyBytes bytes.Buffer
	err = pem.Encode(io.Writer(&privKeyBytes),
		&pem.Block{Type: "PRIVATE KEY", Bytes: marshalledPrivKey})
	PanicIfError(err)

	subj := pkix.Name{
		CommonName:         "ApolloInfra",
		Country:            []string{"N/A"},
		Province:           []string{"N/A"},
		Locality:           []string{"N/A"},
		Organization:       []string{"N/A"},
		OrganizationalUnit: []string{"N/A"},
	}

	template := x509.CertificateRequest{
		Subject:            subj,
		SignatureAlgorithm: SignAlgo,
	}

	csrBytes, err := x509.CreateCertificateRequest(rand.Reader, &template, privateKey)
	PanicIfError(err)

	var pemBytes bytes.Buffer
	err = pem.Encode(&pemBytes, &pem.Block{Type: "CERTIFICATE REQUEST", Bytes: csrBytes})
	PanicIfError(err)

	return privKeyBytes.Bytes(), pemBytes.Bytes()
}

// Use the CA data to sign a certificate request
func SignCertificateRequest(csr []byte, caCert tls.Certificate,
	dnsNames []string, ips []net.IP) ([]byte, error) {

	x509Cert, err := x509.ParseCertificate(caCert.Certificate[0])
	if err != nil {
		return nil, err
	}

	block, _ := pem.Decode(csr)
	csrv, err := x509.ParseCertificateRequest(block.Bytes)
	if err != nil {
		return nil, err
	}

	err = csrv.CheckSignature()
	if err != nil {
		return nil, err
	}

	var dnsNotNull []string
	for _, n := range dnsNames {
		if n != "" {
			dnsNotNull = append(dnsNotNull, n)
		}
	}
	var ipsNotNull []net.IP
	for _, n := range ips {
		if n != nil {
			ipsNotNull = append(ipsNotNull, n)
		}
	}

	template := &x509.Certificate{
		SerialNumber:          big.NewInt(time.Now().UnixNano()),
		Subject:               csrv.Subject,
		PublicKeyAlgorithm:    csrv.PublicKeyAlgorithm,
		PublicKey:             csrv.PublicKey,
		SignatureAlgorithm:    SignAlgo,
		DNSNames:              dnsNotNull,
		IPAddresses:           ipsNotNull,
		BasicConstraintsValid: true,
		IsCA:                  false,

		NotBefore: time.Now(),
		NotAfter:  time.Now().AddDate(1, 0, 0),
		// see http://golang.org/pkg/crypto/x509/#KeyUsage
		ExtKeyUsage: []x509.ExtKeyUsage{x509.ExtKeyUsageClientAuth, x509.ExtKeyUsageServerAuth},
		KeyUsage:    x509.KeyUsageDigitalSignature | x509.KeyUsageCertSign,
	}

	certBytes, err := x509.CreateCertificate(rand.Reader, template, x509Cert,
		csrv.PublicKey, caCert.PrivateKey)
	if err != nil {
		return nil, err
	}

	var pemBytes bytes.Buffer
	err = pem.Encode(&pemBytes, &pem.Block{Type: "CERTIFICATE", Bytes: certBytes})
	if err != nil {
		return nil, err
	}

	return pemBytes.Bytes(), nil
}

func MakeClientCert(ca tls.Certificate) tls.Certificate {
	// Create our own temporary key
	key, csr := MakeKeyAndCSR()

	signedCert, err := SignCertificateRequest(csr, ca, []string{}, []net.IP{})
	PanicIf(err != nil, "Failed to sign CSR")

	res, err := tls.X509KeyPair(signedCert, key)
	PanicIfError(err)
	return res
}

// A verifier that does NOT validate the hostnames in the certificate but
// does check for certificate validity and its signers.
type VerifierFunc func(rawCerts [][]byte, verifiedChains [][]*x509.Certificate) error
func DomainNameIgnoringVerifier(opts x509.VerifyOptions) VerifierFunc {

	// Prepare the verifier options
	//opts := x509.VerifyOptions{
	//	Roots:         x509.NewCertPool(),
	//	CurrentTime:   time.Now(),
	//	DNSName:       "", // We explicitly skip DNS verification
	//	Intermediates: x509.NewCertPool(),
	//}

	return func(rawCerts [][]byte, verifiedChains [][]*x509.Certificate) error {
		certs := make([]*x509.Certificate, len(rawCerts))
		for i, asn1Data := range rawCerts {
			cert, err := x509.ParseCertificate(asn1Data)
			if err != nil {
				return errors.New("tls: failed to parse certificate from server: " + err.Error())
			}
			certs[i] = cert
		}
		for i, cert := range certs {
			if i == 0 {
				continue
			}
			opts.Intermediates.AddCert(cert)
		}
		_, err := certs[0].Verify(opts)
		return err
	}
}
