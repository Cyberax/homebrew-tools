package scheduler

import (
	"apollo/data"
	"apollo/proto/gen/models"
	. "apollo/utils"
	"context"
	"github.com/sirupsen/logrus"
	"sort"
	"time"
)

type Scheduler struct {
	ctx    context.Context
	cancel context.CancelFunc

	stores data.Stores
}

func NewScheduler(stores data.Stores) *Scheduler {
	ctx, cancel := context.WithCancel(context.Background())
	ctx = SaveLoggerToContext(ctx, logrus.StandardLogger())
	AddLoggerFields(ctx, logrus.Fields{"Scheduler": "1"})

	res := Scheduler{
		ctx:             ctx,
		cancel:          cancel,
		stores:          stores,
	}
	return &res
}

func (s *Scheduler) RunSchedulerLoop() {
	CL(s.ctx).Infof("Starting the scheduler loop")

	// The channel is used to only kick the scheduler, so we're fine
	// with losing some of notifications for it.
	nodeNotify := make(chan string, 1)

	// Subscribe to messages now
	s.stores.LS.Subscribe(data.NotifySubtaskScheduled, data.NotifyForAllKeys,
		nodeNotify, false)
	defer s.stores.LS.Unsubscribe(data.NotifySubtaskScheduled, data.NotifyForAllKeys, nodeNotify)

	ticker := time.NewTicker(1000 * time.Millisecond)
	defer ticker.Stop()

loop:
	for ; ; {
		select {
		case <-ticker.C:
		case _, ok := <-nodeNotify:
			if !ok {
				CL(s.ctx).Infof("Scheduler loop stopping")
				break loop
			}
		case <-s.ctx.Done():
			CL(s.ctx).Infof("Interrupt signal received, scheduler is stopping")
			break loop
		}

		s.doScheduling()
	}
}

func (s *Scheduler) getCommittedRamAndCpu(nodes []*data.StoredNode, sess *data.Session) (
	map[string]int64, map[string]int64) {

	committedRamMb := make(map[string]int64)
	committedCpus := make(map[string]int64)
	for _, nd := range nodes {
		committedRamMb[nd.Key] = 0
		committedCpus[nd.Key] = 0

		subtasksKeys := s.stores.NS.GetNodeSubtasks(nd.Key)
		if subtasksKeys == nil {
			continue
		}
		for _, stKey := range subtasksKeys {
			task := s.stores.TS.GetTask(stKey.SKey.ParentKey, sess, data.LockModeNone)
			if task == nil {
				continue
			}
			subtask := s.stores.TS.GetSubtaskAndCheckRetry(stKey, sess, data.LockModeNone)
			if subtask == nil {
				continue
			}

			curUse := subtask.PerfStats.CurValues.RAMUseMb
			if curUse > task.ExpectedRAMMb {
				committedRamMb[nd.Key] = committedRamMb[nd.Key] + curUse
			} else {
				committedRamMb[nd.Key] = committedRamMb[nd.Key] + task.ExpectedRAMMb
			}

			if task.CanUseAllCpus {
				committedCpus[nd.Key] = 1000
			} else {
				committedCpus[nd.Key] = committedCpus[nd.Key] + 1
			}
		}
	}

	return committedRamMb, committedCpus
}

type byFreeRam struct {
	nodes []*data.StoredNode
	committedRamMb map[string]int64
}

func (b byFreeRam) Len() int {
	return len(b.nodes)
}

func (b byFreeRam) Swap(i, j int) {
	tmp := b.nodes[i]
	b.nodes[i] = b.nodes[j]
	b.nodes[j] = tmp
}

func (b byFreeRam) Less(i, j int) bool {
	n1 := b.nodes[i]
	n1Free := n1.Info.RAM.RAMTotalMb - b.committedRamMb[n1.Key]

	n2 := b.nodes[i]
	n2Free := n2.Info.RAM.RAMTotalMb - b.committedRamMb[n2.Key]

	return n1Free > n2Free
}

func (s *Scheduler) doScheduling() {
	sess := s.stores.LS.Session(s.ctx)
	defer sess.UnlockAll()

	tasks := s.stores.TS.ListTasks(nil, true, func(
		task *data.StoredTask, cnt data.SubtaskCounts) bool {
		return task.OverallStatus == models.TaskStateEnumScheduled && cnt.Pending > 0
	})

	nodes := s.stores.NS.ListNodes(nil, func(node *data.StoredNode) bool {
		return node.Online
	}, sess)
	ramUsed, cpuUsed := s.getCommittedRamAndCpu(nodes, sess)

	// Sort the list of nodes by available RAM (from higher to lower)
	sort.Sort(byFreeRam{nodes: nodes, committedRamMb: ramUsed})

	// Iterate through tasks and find if they can be dispatched on any node with
	// enough available RAM.
	for _, t := range tasks {
		subtasksToSchedule := t.Counts.Pending

		for _, st := range t.Subtasks {
			if st.Status != models.SubtaskStateEnumWaiting {
				continue
			}

			// Find the node with enough RAM
			var found = false
			for _, n := range nodes {
				if t.Task.CanUseAllCpus && cpuUsed[n.Key] != 0 {
					continue
				}
				if n.Info.CPU.CPUCount - cpuUsed[n.Key] <= 0 {
					continue
				}
				if n.Info.RAM.RAMTotalMb - ramUsed[n.Key] < t.Task.ExpectedRAMMb {
					continue
				}
				// Dispatch the subtask!
				if !s.assignTask(st.Key, n.Key) {
					continue
				}

				// Correct our indexes
				if t.Task.CanUseAllCpus {
					cpuUsed[n.Key] = 1000
				} else {
					cpuUsed[n.Key] = cpuUsed[n.Key] + 1
				}
				ramUsed[n.Key] = ramUsed[n.Key] + t.Task.ExpectedRAMMb

				found = true
				subtasksToSchedule--
				break
			}

			if !found || subtasksToSchedule == 0 {
				break
			}
		}
	}

}

func (s *Scheduler) Cancel() {
	s.cancel()
}

func (s *Scheduler) assignTask(subtaskKey string, nodeKey string) bool {
	CL(s.ctx).Infof("Assigning a task %s to node %s", subtaskKey, nodeKey)
	sess := s.stores.LS.Session(s.ctx)
	defer sess.UnlockAll()

	node := s.stores.NS.GetNode(nodeKey, sess, data.LockModeFull)
	subtask := *s.stores.TS.GetSubtask(data.MustParseSubtaskKey(subtaskKey), sess, data.LockModeFull)

	if subtask.Status != models.SubtaskStateEnumWaiting {
		return false
	}
	PanicIf(subtask.CurrentAssignment != nil, "Already assigned: " + subtaskKey)

	subtask.CurrentAssignment = &models.SubtaskAssignment{
		AssignedNode: node.Key,
		AssignmentTime: FromTime(time.Now()),
	}
	subtask.Status = models.SubtaskStateEnumDispatched

	s.stores.TS.UpdateSubtask(&subtask, sess)
	return true
}
