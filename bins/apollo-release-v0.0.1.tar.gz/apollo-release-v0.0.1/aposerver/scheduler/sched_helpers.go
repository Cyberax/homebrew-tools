package scheduler

import (
	"apollo/data"
	"apollo/proto/gen/models"
	"apollo/utils"
	"time"
)

func FailTask(ts *data.TaskStore, key string, reason string, sess *data.Session) {
	task := *ts.GetTask(key, sess, data.LockModeFull)
	if data.IsTaskFinished(&task) {
		return
	}

	task.OverallStatus = models.TaskStateEnumFailed
	// TODO: update performance stats

	// Lock subtasks
	for i := task.StartArrayIndex; i < task.EndArrayIndex; i++ {
		subtaskKey := data.SubtaskKey{ParentKey: key, Index: i}
		subtask := *ts.GetSubtask(subtaskKey, sess, data.LockModeFull)

		// Subtask and task are both locked so that we are guaranteed to not
		// race with the node assignment
		if subtask.Status == models.SubtaskStateEnumWaiting {
			subtask.CurrentAssignment = &models.SubtaskAssignment{
				Exited: true,
				ExitError: reason,
				ExitTimestamp: utils.FromTime(time.Now()),
			}
			subtask.PushCurrentAssignmentToHistory()
			subtask.CurrentAssignment = nil

			subtask.StatusChangeTime = utils.FromTime(time.Now())
			subtask.Status = models.SubtaskStateEnumFailed
			subtask.RetryNum++
			ts.UpdateSubtask(&subtask, sess)
		}
		// The tasks that are in dispatched and later stages can't be failed
		// directly and have to be failed by the task minder.

		sess.UnlockItem(data.LockSubtask, subtaskKey.String())
	}

	sess.AddNotify(data.NotifyTaskDone, task.Key)
	ts.UpdateTask(&task, sess)
}
