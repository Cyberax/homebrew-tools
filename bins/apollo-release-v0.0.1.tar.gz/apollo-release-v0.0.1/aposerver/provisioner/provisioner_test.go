package provisioner

import (
	"apollo/data"
	"context"
)

type ProvisionerTestContext struct {
	queueStore *data.QueueStore
	locker *data.LockStore
	ctx context.Context
}

func makeTestContext() *ProvisionerTestContext {
	store := data.NewFakeMemStore()
	//noinspection GoUnhandledErrorResult
	store.InitSchema(map[string]int64{
		data.ConfigStoreTable: 5,
		data.QueueTable:       5,
		data.NodeTable:        5,
		data.TaskTable:        5,
		data.SubtaskTable:     5,
	})

	locker := data.NewLockStore()
	queueStore := data.NewQueueStore(store)
	ctx := context.Background()
	sess := locker.Session(ctx)
	defer sess.UnlockAll()

	q1 := &data.StoredQueue{Key: "q-1"}
	q1.LaunchTemplateID = "lt-05c5b23939434861a"
	q1.InstanceTypes = []string{"c4.xlarge", "c4.2xlarge", "m5.xlarge", "m5.2xlarge"}
	_ = queueStore.StoreNewQueue(q1, sess)

	return &ProvisionerTestContext{
		locker: locker,
		queueStore: queueStore,
		ctx: ctx,
	}
}

//func TestProvisioning(t *testing.T) {
//	tc := makeTestContext()
//	cfg, err := external.LoadDefaultAWSConfig()
//	assert.NoError(t, err)
//
//	qf := QueueFulfiller{
//		queueKey:   "q-1",
//		ctx:        tc.ctx,
//		awsConn:    cfg,
//		queueStore: tc.queueStore,
//		locker:     tc.locker,
//	}
//	qf.RunSpotInstance()
//}