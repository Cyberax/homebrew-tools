package provisioner

import (
	. "apollo/utils"
	"context"
	"fmt"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/ssm"
	"github.com/pkg/errors"
	"time"
)

const LaunchTemplate = `#/bin/bash
cat << EOF > /etc/docker/ca.pem
%s
EOF

cat << EOF > /etc/docker/cert.pem
%s
EOF

cat << EOF > /etc/docker/key.pem
%s
EOF

cat << EOF > /etc/docker/daemon.json
{
    "hosts": ["tcp://0.0.0.0:2376", "unix:///var/run/docker.sock"],
    "tls": true,
    "tlsverify": true,
    "tlscacert": "/etc/docker/ca.pem",
    "tlscert": "/etc/docker/cert.pem",
    "tlskey": "/etc/docker/key.pem",
    "runtimes": {
        "nvidia": {
            "path": "nvidia-container-runtime",
            "runtimeArgs": []
        }
    }
}
EOF

service docker stop
killall -9 dockerd && /bin/true
service docker start
`

type AmazonLinuxProvisioner struct {
	ctx context.Context
	config aws.Config
}

func NewAmazonLinuxProvisioner(ctx context.Context, awsCfg aws.Config) *AmazonLinuxProvisioner {
	return &AmazonLinuxProvisioner{
		ctx: ctx,
		config: awsCfg,
	}
}

func (p *AmazonLinuxProvisioner) InjectDockerCA(instanceId string,
	data TlsData, caCert string) error {

	doc := fmt.Sprintf(LaunchTemplate, caCert, data.CertData, data.KeyData)

	CL(p.ctx).Infof("Trying to initialize instance %s", instanceId)

	sm := ssm.New(p.config)
	req := sm.SendCommandRequest(&ssm.SendCommandInput{
		InstanceIds:  []string{instanceId},
		DocumentName: aws.String("AWS-RunShellScript"),
		Parameters:   map[string][]string{
			"commands": {doc},
			"executionTimeout": {"120"}},
		TimeoutSeconds: aws.Int64(120),

	})

	output, err := req.Send()
	if err != nil {
		return err
	}

	ticker := time.NewTicker(1 * time.Second)
	defer ticker.Stop()
	for ;; {
		select {
		case <- ticker.C:
		case <- p.ctx.Done():
			return p.ctx.Err()
		}

		lcir := sm.ListCommandInvocationsRequest(&ssm.ListCommandInvocationsInput{
			CommandId:  output.Command.CommandId,
			InstanceId: aws.String(instanceId),
		})
		listOutput, err := lcir.Send()
		if err != nil {
			return err
		}

		status := listOutput.CommandInvocations[0].Status
		if status == ssm.CommandInvocationStatusCancelled || status ==
			ssm.CommandInvocationStatusTimedOut ||
			status == ssm.CommandInvocationStatusFailed ||
			status == ssm.CommandInvocationStatusCancelling {

			msg := fmt.Sprintf("Initialization command failed with %s status for %s",
				status, instanceId)
			return errors.New(msg)
		}

		if status == ssm.CommandInvocationStatusSuccess {
			CL(p.ctx).Infof("Docker CA initialized for %s", instanceId)
			return nil
		}
	}
}
