package provisioner

import (
	"apollo/data"
	. "apollo/utils"
	"context"
	"github.com/sirupsen/logrus"
	"time"
)

type Provisioner struct {
	ctx    context.Context
	cancel context.CancelFunc

	locker *data.LockStore
	qs     *data.QueueStore
	ns     *data.NodeStore
}

func NewProvisioner(qs *data.QueueStore, ns *data.NodeStore,
	locker *data.LockStore) *Provisioner {

	ctx, cancel := context.WithCancel(context.Background())
	ctx = SaveLoggerToContext(ctx, logrus.StandardLogger())
	AddLoggerFields(ctx, logrus.Fields{"Provisioner": "1"})

	res := Provisioner{
		ctx:             ctx,
		cancel:          cancel,
		locker:          locker,
		qs:              qs,
		ns:              ns,
	}
	return &res
}

func (s *Provisioner) Cancel() {
	s.Cancel()
}

func (s *Provisioner) doProvisioning() {

}

func (s *Provisioner) RunProvisionerLoop() {
	CL(s.ctx).Infof("Starting the provisioner loop")

	ticker := time.NewTicker(10000 * time.Millisecond)
	defer ticker.Stop()

loop:
	for ; ; {
		select {
		case <-ticker.C:
		case <-s.ctx.Done():
			CL(s.ctx).Infof("Interrupt signal received, scheduler is stopping")
			break loop
		}

		s.doProvisioning()
	}
}
