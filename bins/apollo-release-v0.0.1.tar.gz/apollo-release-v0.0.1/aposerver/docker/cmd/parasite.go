package main

// This is a simple Golang program that continuously monitors the CPU and RAM
// statistics and prints them on the Stderr. Additionally it spawns a proxy
// server that muxes streams over the stdin/stdout pair so that the clients
// running on this Docker host can communicate with the server.
//
// It's fairly simple and guaranteed to be linked statically, so it can be
// directly imported into Docker.
import (
	. "apollo/aposerver/docker/parasite"
	"context"
	"golang.org/x/sys/unix"
	"io"
	"log"
	"net"
	"os"
	"os/signal"
	"strconv"
	"syscall"
	"time"
)

type ModeType int64
const RetroMode ModeType = 1
const StatsMode ModeType = 2

func usage() {
	log.Fatalf("Usage:\n" +
		"parasite retro <net-type> <listen-socket>\n" +
		"parasite stats <apoptosis-interval-seconds>")
}

func parseParams() (ModeType, int, net.Listener) {
	if len(os.Args) < 2 {
		usage()
	}

	if os.Args[1] == "retro" {
		if len(os.Args) != 4 {
			usage()
		}
		netType := os.Args[2]
		netAddr := os.Args[3]

		if netType == "unix" {
			_ = unix.Unlink(netAddr)
		}
		listener, err := net.Listen(netType, netAddr)
		if err != nil {
			log.Fatalf("Failed to listen on %s://%s", netType, netAddr)
		}
		return RetroMode, 0, listener
	}

	if os.Args[1] == "stats" {
		if len(os.Args) != 3 {
			usage()
		}
		apoptosisSec, err := strconv.Atoi(os.Args[2])
		if err != nil {
			log.Fatalf("Failed to parse apoptosis interval: %s", os.Args[2])
		}
		return StatsMode, apoptosisSec, nil
	}

	usage()
	panic("Unreachable")
}

func main() {
	log.SetOutput(os.Stderr)
	logger := log.New(os.Stderr, "", log.LstdFlags)

	// Die on signal
	var interrupt = make(chan os.Signal)
	signal.Notify(interrupt, syscall.SIGINT, syscall.SIGTERM)
	go func() {
		<-interrupt
		os.Exit(1)
	}()

	ctx, cancel := context.WithCancel(context.Background())

	mode, apoptosisSec, listener := parseParams()
	defer func() {
		if listener != nil {
			_ = listener.Close()
		}
	}()

	if mode == RetroMode {
		channel := MakeAcceptChannel(listener)
		communicator := NewStdIoReadwriter(os.Stdin, os.Stdout, ctx)
		connector := NewRetroConnector(ctx, logger, channel, communicator, 10*time.Second)
		err := connector.RunAcceptorSession()
		if err != io.EOF && err.Error() != "broken pipe" {
			log.Fatalf("Unexpected error: %s", err)
		} else {
			log.Printf("Acceptor session ended")
		}
	}
	if mode == StatsMode {
		go func() {
			// Print machine stats to stdout every several seconds
			RunStatsLoop(ctx, os.Stdout)
		}()
		// Run the apoptosis loop, it will terminate if stdin is closed
		RunApoptosisLoop(ctx, os.Stdin, time.Duration(apoptosisSec)*time.Second)
		cancel()
	}
}
