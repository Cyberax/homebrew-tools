package parasite

import (
	"context"
	"io"
	"log"
	"os"
	"sync"
	"time"
)

var Suicider = suicide

// Run a loop checking that we have received
func RunApoptosisLoop(ctx context.Context, in ConnectionLike, timeDelay time.Duration) {
	lastPingTime := time.Now()

	// Read from the input stream, updating the ping time on each read.
	exit := make(chan bool, 1)
	wg := sync.WaitGroup{}
	if timeDelay.Nanoseconds() != 0 {
		wg.Add(1)
		go func() {
			defer wg.Done()

			ticker := time.NewTicker(5 * time.Second)
			defer ticker.Stop()
		loop:
			for ; ; {
				select {
				case <-ticker.C:
				case <-ctx.Done():
					break loop
				case <-exit:
					break loop
				}

				if lastPingTime.Add(timeDelay).Before(time.Now()) {
					// Yup. Time to kill itself.
					log.Printf("Ping timeout expired, will shut down the machine now\n")
					time.Sleep(10 * time.Second)
					Suicider()
				}
			}
		}()
	}

	var buf = make([]byte, 1024)
	loop: for ;; {
		select {
		case <- ctx.Done():
			break loop
		default:
		}

		_, err := in.Read(buf)
		if err != nil {
			if err != io.EOF {
				log.Printf("Error reading from the keep-alive stream\n")
			}
			break
		}
		lastPingTime = time.Now()
	}
	close(exit)
	wg.Wait()
}

// Hard-stop the machine by just shutting down the kernel immediately.
// No orderly shutdown actions are done.
func suicide() {
	file, err := os.OpenFile("/proc/sysrq-trigger", os.O_WRONLY, 0)
	if err != nil {
		return
	}
	//noinspection GoUnhandledErrorResult
	defer file.Close()
	_, _ = file.WriteString("o\n")
}
