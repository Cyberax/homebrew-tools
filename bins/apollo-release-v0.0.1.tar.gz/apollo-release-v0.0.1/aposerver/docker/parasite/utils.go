package parasite

import (
	"context"
	"io"
	"net"
	"os"
	"sync"
	"time"
)

type AcceptedConnection struct {
	conn net.Conn
	err error
}

func MakeAcceptChannel(listener net.Listener) <- chan AcceptedConnection {
	res := make(chan AcceptedConnection)
	go func() {
		for ;; {
			conn, err := listener.Accept()
			res <- AcceptedConnection{conn, err}
			if err != nil {
				break
			}
		}
	}()
	return res
}

type ConnectionLike interface {
	io.ReadWriteCloser
	SetDeadline(t time.Time) error
}

type StdIoReadwriter struct {
	stdin, stdout ConnectionLike
	readMtx sync.Mutex
	writeMtx sync.Mutex

	ctx context.Context
	closeChannel chan bool
}

func NewStdIoReadwriter(stdin, stdout ConnectionLike,
		ctx context.Context) *StdIoReadwriter {

	closeChannel := make(chan bool, 1)
	go func() {
		select {
		case <- closeChannel:
		case <- ctx.Done():
		}
		_ = stdin.SetDeadline(time.Now())
		_ = stdout.SetDeadline(time.Now())
	}()
	return &StdIoReadwriter{stdin: stdin, stdout: stdout,
		ctx: ctx, closeChannel: closeChannel}
}

func (s *StdIoReadwriter) Read(p []byte) (n int, err error) {
	s.readMtx.Lock()
	defer s.readMtx.Unlock()
	i, err := s.stdin.Read(p)
	return i, s.decode(err)
}

func (s *StdIoReadwriter) Write(p []byte) (n int, err error) {
	s.writeMtx.Lock()
	defer s.writeMtx.Unlock()
	i, err := s.stdout.Write(p)
	return i, s.decode(err)
}

func (s *StdIoReadwriter) decode(e error) error {
	if e == nil {
		return nil
	}

	if os.IsTimeout(e) {
		return io.EOF
	}
	return e
}

func (s *StdIoReadwriter) Close() error {
	close(s.closeChannel)
	return nil
}
