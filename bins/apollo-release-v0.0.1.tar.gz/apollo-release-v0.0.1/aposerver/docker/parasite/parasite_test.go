package parasite

import (
	"context"
	"github.com/stretchr/testify/assert"
	"io"
	"os"
	"sync"
	"testing"
	"time"
)

// A stream that issues the cancel operation as soon as it
// encounters a EOF.
type cancellingStream struct {
	stdin *os.File

	mtx sync.Mutex
	canceller context.CancelFunc
}

func (c *cancellingStream) Read(p []byte) (n int, err error) {
	c.mtx.Lock()
	defer c.mtx.Unlock()
	i, err := c.stdin.Read(p)
	if os.IsTimeout(err) || err == io.EOF || err == io.ErrUnexpectedEOF {
		if c.canceller != nil {
			c.canceller()
			c.canceller = nil
		}
		return i, err
	}
	return i, err
}

func TestStdioWriterClosing(t *testing.T) {
	r, w, err := os.Pipe()
	defer func(){
		_ = r.Close()
		_ = w.Close()
	}()
	assert.NoError(t, err)

	ctx, cancel := context.WithCancel(context.Background())

	rwr := NewStdIoReadwriter(r, w, ctx)

	n, err := rwr.Write([]byte("Hello"))
	assert.NoError(t, err)
	assert.Equal(t, 5, n)

	buf := make([]byte, 10)
	n, err = rwr.Read(buf)
	assert.NoError(t, err)
	assert.Equal(t, 5, n)
	assert.Equal(t, "Hello", string(buf[0:5]))

	// Check that the reads will be interrupted
	wg := sync.WaitGroup{}
	wg.Add(1)
	go func() {
		_, e := rwr.Read(buf)
		assert.Equal(t, io.EOF, e)
		wg.Done()
	}()
	// TODO: this is fugly. How can I check that there's a waiting reader?
	time.Sleep(100*time.Millisecond)
	cancel()
	wg.Wait()

	// Further reads and writes immediately return errors
	_, e := rwr.Read(buf)
	assert.Equal(t, io.EOF, e)
	_, e = rwr.Write(buf)
	assert.Equal(t, io.EOF, e)
}
