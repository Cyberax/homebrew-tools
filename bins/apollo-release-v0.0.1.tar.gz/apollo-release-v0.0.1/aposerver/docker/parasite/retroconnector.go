package parasite

import (
	"context"
	"fmt"
	"github.com/xtaci/smux"
	"io"
	"log"
	"sync"
	"time"
)

const HandshakeChallenge = "Hello"
const HandshakeReply = "World"

type RetroConnector struct {
	context context.Context
	logger *log.Logger

	rw *StdIoReadwriter
	socketServer <-chan AcceptedConnection

	pingInterval time.Duration
}

func NewRetroConnector(ctx context.Context, logger *log.Logger,
	socketServer <-chan AcceptedConnection, rw *StdIoReadwriter,
	pingInterval time.Duration) *RetroConnector {

	return &RetroConnector{
		context: ctx,
		logger: logger,
		socketServer: socketServer,
		rw: rw,
		pingInterval: pingInterval,
	}
}

func handshakeStream(session *smux.Session) (*smux.Stream, error) {
	stream, err := session.OpenStream()
	if err != nil {
		return nil, err
	}
	_, err = stream.Write([]byte(HandshakeChallenge))
	if err != nil {
		return nil, err
	}

	buf := make([]byte, len(HandshakeReply))
	_, err = io.ReadFull(stream, buf)
	if err != nil {
		return nil, err
	}
	if string(buf) != HandshakeReply {
		return nil, io.ErrUnexpectedEOF
	}

	return stream, nil
}

// Run a simple multiplexed proxy server over the stdin/stdout stream pair.
func (r *RetroConnector) RunAcceptorSession() error {
	session, err := smux.Client(r.rw, nil)
	if err != nil {
		return err
	}

	defer func(){
		_ = session.Close()
	}()

	sentinel, err := handshakeStream(session)
	if err != nil {
		return err
	}
	//noinspection GoUnhandledErrorResult
	defer sentinel.Close()
	r.logger.Print("Established retro-connection")

	for ;; {
		var accepted AcceptedConnection
		select {
		case <-r.context.Done():
			return r.context.Err()
		case <-sentinel.GetDieCh():
			return fmt.Errorf("sentinel channel closed")
		case accepted = <-r.socketServer:
		}

		if accepted.err != nil {
			return err
		}

		// Get a new muxed stream
		stream, err := session.OpenStream()
		if err != nil {
			return err
		}

		wg := &sync.WaitGroup{}
		wg.Add(2)
		go closer(wg, accepted.conn, stream)
		go transmitter(stream, accepted.conn, wg)
		go transmitter(accepted.conn, stream, wg)
	}
}

func closer(wg *sync.WaitGroup, closers... io.Closer) {
	wg.Wait()
	for _, c := range closers {
		_ = c.Close()
	}
}

func transmitter(conn io.ReadCloser, stream io.WriteCloser, wg *sync.WaitGroup) {
	defer wg.Done()
	arr := make([]byte, 16384)
	for ;; {
		n, err := conn.Read(arr)
		if n == 0 {
			break
		}
		_, err2 := stream.Write(arr[:n])
		if err != nil {
			break
		}
		if err2 != nil {
			break
		}
	}
}
