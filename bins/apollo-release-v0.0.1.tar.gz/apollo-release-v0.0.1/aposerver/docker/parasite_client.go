package docker

import (
	"apollo/aposerver/docker/parasite"
	"apollo/proto/gen/models"
	. "apollo/utils"
	"bytes"
	"context"
	"crypto/sha1"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"github.com/docker/docker/api/types"
	"github.com/docker/docker/api/types/container"
	"github.com/docker/docker/api/types/mount"
	"github.com/docker/docker/api/types/volume"
	"github.com/docker/docker/client"
	"github.com/rakyll/statik/fs"
	"github.com/sirupsen/logrus"
	"github.com/xtaci/smux"
	"io"
	"net"
	"strconv"
	"strings"
	"sync"
	"time"
)

const ParasiteTag = "parasite.local/repo:0.3"
const ApolloPath = "/apo"
const VolumeName = "ApoParasite"
const ApoptosisSeconds = 120

// The server-side of the measurement parasite that is injected into the worker hosts.
// It is strictly one-time use, the Measurements channel closure indicates that the
// client has encountered an error and needs to be re-created.
//
// In addition to getting measurements it also multiplexes the smux-based multiplex
// protocol on top of the stdin-stdout pair. This is used to directly connect clients
// to the server (potentially behind the firewall).
type ParasiteClient struct {
	Client *client.Client
	ProxyTarget chan <- net.Conn
	Suffix string

	Measurements chan models.NodeInfo
	DeathChan chan bool

	wg sync.WaitGroup
	ctx context.Context
	cancel context.CancelFunc
	apoptosisSeconds int
	persistent bool
}

func NewParasiteClient(ctx context.Context, client *client.Client, measures chan models.NodeInfo,
	proxyTarget chan <- net.Conn, suffix string, persistent bool) *ParasiteClient {

	ourContext, cancel := context.WithCancel(ctx)

	res := &ParasiteClient{
		Client:      client,
		ProxyTarget: proxyTarget,
		Suffix:      suffix,

		Measurements: measures,
		DeathChan: make(chan bool),

		ctx:    ourContext,
		cancel: cancel,
		persistent: persistent,
	}
	if persistent {
		res.apoptosisSeconds = ApoptosisSeconds
	}
	return res
}

func (p *ParasiteClient) Close() {
	p.cancel()
	p.wg.Wait()
}

func (p *ParasiteClient) GetDeathChan() <-chan struct{} {
	return p.ctx.Done()
}

func GetParasiteFile(apolloClient bool) []byte {
	fileSystem, err := fs.New()
	if err != nil {
		panic(err)
	}

	var fileName string
	if apolloClient {
		fileName = "/client.tar"
	} else {
		fileName = "/parasite.tgz"
	}

	var buf bytes.Buffer
	file, err := fileSystem.Open(fileName)
	if err != nil {
		panic(err)
	}

	_, err = buf.ReadFrom(file)
	if err != nil {
		panic(err)
	}

	return buf.Bytes()
}

func (p *ParasiteClient) makeParasite(ctx context.Context) (string, error) {
	summaries, err := p.Client.ImageList(ctx, types.ImageListOptions{All: true})
	if err != nil {
		return "", err
	}

	file := GetParasiteFile(false)
	sum := sha1.Sum(file)
	checksum := hex.EncodeToString(sum[:])

	tag := ParasiteTag + "-" + checksum[:8]

	var id = ""
	for _, s := range summaries {
		for _, t := range s.RepoTags {
			if t == tag {
				return s.ID, nil
			}
		}
	}

	CL(ctx).Info("Collector parasite image is not found, importing it")
	imageImport, err := p.Client.ImageImport(context.Background(), types.ImageImportSource{
		Source: bytes.NewReader(file), SourceName: "-"}, tag,
		types.ImageImportOptions{})
	if err != nil {
		return "", err
	}
	//noinspection GoUnhandledErrorResult
	defer imageImport.Close()

	var importMsg bytes.Buffer
	_, err = importMsg.ReadFrom(imageImport)
	if err != nil {
		return "", err
	}

	res := make(map[string]interface{})
	err = json.Unmarshal(importMsg.Bytes(), &res)
	if err != nil {
		return "", err
	}
	idInt, ok := res["status"]
	if !ok {
		return "", fmt.Errorf("failed to upload the collector parasite image")
	}
	id = idInt.(string)
	CL(ctx).Infof("Uploaded the collector parasite image: %s", id[:20])
	return id, nil
}

func (p *ParasiteClient) recordStats(ctx context.Context, s string) bool {
	var ni = models.NodeInfo{}

	err := json.Unmarshal([]byte(s), &ni)
	if err != nil {
		CL(ctx).Errorf("Failed to decode stats: %s", s)
		return false
	}
	// Store the timestamp in epoch millis
	ni.Timestamp = time.Now().UnixNano() / 1000000

	// Try to write the measurement into the channel. If the channel
	// is full then try to consume a measurement from its head and
	// retry the write. This create a simplistic circular buffer.
	select {
	case p.Measurements <- ni:
	default:
		select {
		case <-p.Measurements:
		default:
			CL(ctx).Infof("Consuming a head update")
		}

		select {
		case p.Measurements <- ni:
		default:
			CL(ctx).Infof("Skipping an update, channel is full")
		}
	}
	return true
}

func (p *ParasiteClient) StartRetro(ctx context.Context, id string) (
	error, *HijackedReadWriterCloser) {

	err := p.MakeSocketVolume(ctx)
	if err != nil {
		return err, nil
	}

	CL(ctx).Infof("Starting the retro connector with image: %s", id[:20])

	resp, err := p.Client.ContainerCreate(ctx,
		&container.Config{
			Image: id,
			AttachStdout: true,
			AttachStderr: true,
			OpenStdin: true,
			AttachStdin: true,
			Tty: false,
			StdinOnce: true,
			Cmd: []string{"/parasite", "retro", "unix", "/apo/apollo-socket"},
		},
		&container.HostConfig{
			Mounts: []mount.Mount{{
				Type: mount.TypeVolume,
				Source: VolumeName+p.Suffix,
				Target: "/apo",
			}},
			OomScoreAdj: -1000,
			AutoRemove: true,
			Privileged: true, // This will allow the container to shutdown the instance
		},nil, "")
	if err != nil {
		return err, nil
	}

	CL(ctx).Infof("Attaching to the retroconnector")
	streams, err := p.Client.ContainerAttach(ctx, resp.ID, types.ContainerAttachOptions{
		Stderr: true, Stdin: true, Stdout: true, Stream: true, Logs: true})
	if err != nil {
		return err, nil
	}

	CL(ctx).Infof("Uploading Apollo client")
	err = p.uploadApollo(ctx, resp.ID)
	if err != nil {
		return err, nil
	}

	CL(ctx).Infof("Starting the retroconnector")
	err = p.Client.ContainerStart(ctx, resp.ID, types.ContainerStartOptions{})
	if err != nil {
		return err, nil
	}

	return nil, NewHijackedStreamDemuxer(streams, ctx)
}

func (p *ParasiteClient) MakeSocketVolume(ctx context.Context) error {
	_, err := p.Client.VolumeCreate(ctx, volume.VolumesCreateBody{
		Name:   VolumeName+p.Suffix,
		Driver: "local",
		Labels: map[string]string{"Apollo": "V1"},
	})
	if err != nil {
		return err
	}
	return nil
}

func (p *ParasiteClient) uploadApollo(ctx context.Context, containerId string) error {
	stat, err := p.Client.ContainerStatPath(ctx, containerId, ApolloPath+"/apollo")
	if err != nil &&
		strings.Index(err.Error(), "Error: request returned Not Found") != 0 {
		return err
	}
	if stat.Size > 0 {
		return nil
	}

	file := GetParasiteFile(true)

	// Copy the Apollo binary into the container
	return p.Client.CopyToContainer(ctx, containerId, ApolloPath,
		bytes.NewReader(file), types.CopyToContainerOptions{AllowOverwriteDirWithFile:true})
}

func (p *ParasiteClient) StartClient(ctx context.Context, id string) (error, types.HijackedResponse) {
	CL(ctx).Infof("Starting the collector parasite: %s", id[:20])

	resp, err := p.Client.ContainerCreate(ctx,
		&container.Config{
			Image: id,
			AttachStdin: true,
			AttachStdout: true,
			AttachStderr: true,
			OpenStdin: true,
			StdinOnce: !p.persistent,
			Cmd: []string{"/parasite", "stats", strconv.Itoa(p.apoptosisSeconds)},
		},
		&container.HostConfig{
			LogConfig: container.LogConfig{Type: "none"},
			OomScoreAdj: -1000,
			AutoRemove: true,
			Privileged: true, // This will allow the container to shutdown the instance
		},nil, "ApoParasite"+p.Suffix)

	var containerId string
	if err != nil {
		// Error response from daemon: Conflict. The container name "/ApoParasite"
		// is already in use by container "6552...cb3".
		// You have to remove (or rename) that container to be able to reuse that name.
		// TODO: whack the Docker developers with a stick to fix this!!!
		if strings.Index(err.Error(),"Error response from daemon: Conflict.") == 0 {
			parts := strings.Split(err.Error(), "\"")
			if len(parts) < 3 {
				return err, types.HijackedResponse{}
			}
			containerId = parts[3]
		} else {
			return err, types.HijackedResponse{}
		}
	} else {
		containerId = resp.ID
	}

	CL(ctx).Infof("Attaching to the collector parasite")

	statsStream, err := p.Client.ContainerAttach(ctx, containerId,
		types.ContainerAttachOptions{Stderr: true, Stdin: true, Stdout: true, Stream: true})
	if err != nil {
		return err, types.HijackedResponse{}
	}

	CL(ctx).Infof("Starting the container")

	err = p.Client.ContainerStart(ctx, containerId, types.ContainerStartOptions{})
	if err != nil {
		return err, types.HijackedResponse{}
	}

	return nil, statsStream
}

func (p *ParasiteClient) doTheHandshake(ctx context.Context, session *smux.Session) (
	*smux.Stream, error) {

	handshake, err := session.AcceptStream()
	if err != nil {
		return nil, err
	}
	CL(ctx).Info("Accepted a connection")

	exited := make(chan bool, 1)
	defer close(exited)
	go func() {
		select {
		case <- exited:
			return
		case <- ctx.Done():
			_ = handshake.SetDeadline(time.Now())
		}
	}()

	buf := make([]byte, len(parasite.HandshakeChallenge))
	_, err = io.ReadFull(handshake, buf)
	if err != nil || string(buf) != parasite.HandshakeChallenge {
		return handshake, err
	}

	_, err = handshake.Write([]byte(parasite.HandshakeReply))
	if err != nil {
		return handshake, err
	}
	return handshake, nil
}

func (p *ParasiteClient) RunLoops() error {
	CL(p.ctx).Infof("Starting the loops")

	parasiteImageId, err := p.makeParasite(p.ctx)
	if err != nil {
		return err
	}

	var statsReadyChan = make(chan bool, 1)
	var proxyReadyChan = make(chan bool, 1)
	childContext, cancel := context.WithCancel(p.ctx)

	p.wg.Add(1)
	go func() {
		defer cancel()
		defer p.wg.Done()
		statsCtx := DeriveNewLoggerContext(childContext)
		AddLoggerFields(statsCtx, logrus.Fields{"PC":"STATS"})
		err, response := p.StartClient(statsCtx, parasiteImageId)
		if err != nil {
			if err != context.Canceled {
				CL(statsCtx).Warnf("failed to start the stats client: %s", err)
			}
			return
		}
		defer response.Close()
		p.RunStatsLoop(statsCtx, statsReadyChan, response)
		CL(statsCtx).Infof("Stats loop finished")
	}()

	p.wg.Add(1)
	go func() {
		defer cancel()
		defer p.wg.Done()
		proxyConn := DeriveNewLoggerContext(childContext)
		AddLoggerFields(proxyConn, logrus.Fields{"PC":"PROXY"})
		err, streams := p.StartRetro(proxyConn, parasiteImageId)
		if err != nil {
			if err != context.Canceled {
				CL(proxyConn).Warnf("failed to start the retro client: %s", err)
			}
			return
		}
		defer func(){ _ = streams.Close()}()
		p.RunProxyLoop(proxyConn, proxyReadyChan, streams)
		CL(proxyConn).Infof("Proxy loop finished")
	}()

	for _, ch := range []chan bool{statsReadyChan, proxyReadyChan} {
		select {
		case <-ch:
		case <-childContext.Done():
			p.wg.Wait()
			close(p.DeathChan)
			return childContext.Err()
		case <-time.After(30 * time.Second):
			cancel()
			p.wg.Wait()
			close(p.DeathChan)
			return fmt.Errorf("timed out waiting for the collector " +
				"parasite process to start")
		}
	}

	go func() {
		p.wg.Wait()
		close(p.DeathChan)
	}()

	return nil
}

func (p *ParasiteClient) RunProxyLoop(ctx context.Context, readyChan chan bool,
	proxyStream *HijackedReadWriterCloser) {

	session, err := smux.Client(proxyStream, nil)
	if err != nil {
		CL(ctx).Warnf("Failed to connect to handshake: %s", err)
		return
	}
	//noinspection GoUnhandledErrorResult
	defer session.Close()

	exited := make(chan bool, 1)
	defer close(exited)
	go func() {
		select {
		case <- exited:
			return
		case <- ctx.Done():
			_ = session.Close()
		}
	}()

	// Do the handshake
	CL(ctx).Info("Handshaking the retroconnection")
	sentinel, err := p.doTheHandshake(ctx, session)
	if err != nil {
		CL(ctx).Warnf("Failed to connect to handshake: %s", err)
		return
	}
	//noinspection GoUnhandledErrorResult
	defer sentinel.Close()

	CL(ctx).Info("Ready to serve connections")
	close(readyChan)

	//noinspection GoUnhandledErrorResult
	for ;!session.IsClosed() && ctx.Err() == nil; {
		conn, err := session.AcceptStream()
		if err != nil {
			if err.Error() != "broken pipe" && err.Error() != "i/o timeout" {
				CL(ctx).Infof("Failed to accept a connection: %s", err)
			}
			return
		}
		p.ProxyTarget <- conn
	}
}

func (p *ParasiteClient) RunStatsLoop(ctx context.Context,
	readyChan chan bool, statsStream types.HijackedResponse) {
	exited := make(chan bool, 1)
	defer close(exited)
	go func() {
		select {
		case <- exited:
			return
		case <- ctx.Done():
			_ = statsStream.Conn.SetDeadline(time.Now())
		}
	}()

	maybeReadyChan := &readyChan

	for ;ctx.Err() == nil; {
		typ, str, err := readMuxedMessage(statsStream)
		if err != nil {
			if ctx.Err() == nil {
				CL(ctx).Warnf("Failed to read a message: %s", err.Error())
			}
			return
		}

		if typ {
			// Stdout stream
			if p.recordStats(ctx, str) {
				// Signal the starting thread that we're ready
				if maybeReadyChan != nil {
					close(*maybeReadyChan)
					maybeReadyChan = nil
				}
			}
			_, err := statsStream.Conn.Write([]byte("Ping\n"))
			if err != nil {
				if ctx.Err() == nil {
					CL(ctx).Warnf("Failed to write ping: %s", err.Error())
				}
				return
			}
		} else {
			// Stderr stream - just log it
			CL(ctx).Print(str)
		}
	}
}
