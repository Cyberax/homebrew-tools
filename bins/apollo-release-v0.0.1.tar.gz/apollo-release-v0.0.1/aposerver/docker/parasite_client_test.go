package docker

import (
	_ "apollo/aposerver/statik"
	"apollo/proto/gen/models"
	"apollo/utils"
	bytes2 "bytes"
	"context"
	"github.com/docker/docker/api/types"
	"github.com/docker/docker/api/types/container"
	"github.com/docker/docker/api/types/filters"
	"github.com/docker/docker/api/types/mount"
	"github.com/sirupsen/logrus"
	"github.com/stretchr/testify/assert"
	io2 "io"
	"net"
	"strings"
	"testing"
)

func TestNonPersistentClient(t *testing.T) {
	connector, e := NewConnector(ConnectionInfo{})
	assert.NoError(t, e)

	ctx, _ := context.WithCancel(context.Background())
	ctx = utils.SaveLoggerToContext(ctx, logrus.StandardLogger())
	streams := make(chan net.Conn, 10)
	nis := make(chan models.NodeInfo, 10)

	killRunningContainer(t, connector, "-npt", ctx)

	client := NewParasiteClient(ctx, connector.Client, nis,
		streams, "-npt", false)

	// The client is non-persistent and the container will exit on disconnect
	e = client.RunLoops()
	assert.NoError(t, e)
	// We should see the container now
	lst := findContainer(t, connector, "-npt", ctx)
	assert.Equal(t, 1, len(lst))
	contId := lst[0].ID

	// And after this statement finishes the container will die
	client.Close()
	<-client.DeathChan

	// Make sure the client has disappeared
	_, e = connector.Client.ContainerWait(ctx, contId)
	if e != nil && strings.Index(e.Error(), "No such container") == -1 {
		assert.Fail(t, "Failed waiting")
	}
}

func TestPersistentClient(t *testing.T) {
	connector, e := NewConnector(ConnectionInfo{})
	ctx, _ := context.WithCancel(context.Background())
	ctx = utils.SaveLoggerToContext(ctx, logrus.StandardLogger())
	streams := make(chan net.Conn, 10)
	nis := make(chan models.NodeInfo, 10)

	killRunningContainer(t, connector, "-pt", ctx)

	// The client is persistent and the container will NOT exit on disconnect
	client := NewParasiteClient(ctx, connector.Client, nis, streams, "-pt", true)
	client.apoptosisSeconds = 0 // Disable suicide
	e = client.RunLoops()
	assert.NoError(t, e)
	<- client.Measurements // Wait for measurements to come
	client.Close()

	// The container is still alive
	lst := findContainer(t, connector, "-pt", ctx)
	assert.Equal(t, 1, len(lst))

	// Reconnect to it
	client2 := NewParasiteClient(ctx, connector.Client, nis, streams, "-pt", true)
	client2.apoptosisSeconds = 0
	e = client2.RunLoops()
	assert.NoError(t, e)
	client2.Close()

	<-client2.DeathChan

	killRunningContainer(t, connector, "-pt", ctx)
}

func TestProxyLoop(t *testing.T) {
	connector, e := NewConnector(ConnectionInfo{})
	ctx, _ := context.WithCancel(context.Background())
	ctx = utils.SaveLoggerToContext(ctx, logrus.StandardLogger())
	streams := make(chan net.Conn, 10)
	nis := make(chan models.NodeInfo, 10)

	client := NewParasiteClient(ctx, connector.Client, nis, streams, "-plp",false)

	// Run the retroconnector client
	e = client.RunLoops()
	assert.NoError(t, e)

	io, e := connector.Client.ImagePull(ctx, "docker.io/library/alpine:3.7",
		types.ImagePullOptions{})
	assert.NoError(t, e)
	buf := bytes2.Buffer{}
	_, _ = io2.Copy(&buf, io)

	imageId, e := client.makeParasite(ctx)
	assert.NoError(t, e)

	// Run a simple container and use Apollo client to make a request
	resp, err := connector.Client.ContainerCreate(ctx,
		&container.Config{
			Image: imageId,
			AttachStdout: true,
			AttachStderr: true,
			OpenStdin: true,
			AttachStdin: true,
			StdinOnce: true,
			Cmd: []string{"/apo/apollo", "auth", "login", "-s", "/apo/apollo-socket"},
			Env: []string{"AWS_ACCESS_KEY_ID=aa","AWS_SECRET_ACCESS_KEY=bb"},
		},
		&container.HostConfig{
			Mounts: []mount.Mount{{
				Type: mount.TypeVolume,
				Source: "ApoParasite-plp",
				Target: "/apo",
			}},
			OomScoreAdj: -1000,
			AutoRemove: true,
			Privileged: true, // This will allow the container to shutdown the instance
		},nil, "")
	assert.NoError(t, err)

	_, e = connector.Client.ContainerAttach(ctx, resp.ID, types.ContainerAttachOptions{
		Stderr: true, Stdin: true, Stdout: true, Stream: true, Logs: true})
	assert.NoError(t, e)

	//go func() {
	//	for ;; {
	//		_, msg, err := readMuxedMessage(muxed)
	//		if err != nil {
	//			break
	//		}
	//		t.Log(msg)
	//	}
	//}()
	e = connector.Client.ContainerStart(ctx, resp.ID, types.ContainerStartOptions{})
	assert.NoError(t, e)

	// Now just wait for the connection to come through
	s := <- streams
	// This is TLS handshake, don't bother reading it, just check that something
	// can be read.
	bytes := make([]byte, 1)
	n, e := s.Read(bytes)
	assert.Equal(t, 1, n)

	_ = connector.Client.ContainerKill(ctx, resp.ID, "SIGKILL")
}

func killRunningContainer(t *testing.T, connector *Connector,
	suffix string, ctx context.Context) {

	lst := findContainer(t, connector, suffix, ctx)
	if len(lst) == 0 {
		return
	}
	_ = connector.Client.ContainerKill(ctx, lst[0].ID, "SIGKILL")
	_, _ = connector.Client.ContainerWait(ctx, lst[0].ID)
}

func findContainer(t *testing.T, connector *Connector, suffix string,
	ctx context.Context) []types.Container {

	args, _ := filters.ParseFlag("name=ApoParasite"+suffix, filters.NewArgs())
	lst, err := connector.Client.ContainerList(ctx, types.ContainerListOptions{
		Filters: args,
	})
	assert.NoError(t, err)
	return lst
}
