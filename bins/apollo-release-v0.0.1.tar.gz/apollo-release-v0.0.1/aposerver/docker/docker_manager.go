package docker

import (
	"apollo/proto/gen/models"
	. "apollo/utils"
	"bufio"
	"bytes"
	"context"
	"crypto/tls"
	"crypto/x509"
	"encoding/base64"
	"encoding/json"
	"encoding/pem"
	"fmt"
	"github.com/docker/distribution/reference"
	"github.com/docker/docker/api/types"
	"github.com/docker/docker/api/types/container"
	"github.com/docker/docker/api/types/filters"
	"github.com/docker/docker/api/types/mount"
	"github.com/docker/docker/client"
	"github.com/sirupsen/logrus"
	"io"
	"net/http"
	"net/url"
	"strings"
	"time"
)

type ConnectionInfo struct {
	DockerAddress string
	DockerLogin, DockerPassword, DockerRepository string
	ApoptosisEnabled bool

	Suffix                 string
	NodeCAKey, NodeCACert  string
}

type Connector struct {
	Client           *client.Client
	AuthTokensByRepo map[string]string

	Info ConnectionInfo

	ClientCert *tls.Certificate
	RootCAs *x509.CertPool
}

type ConnectorFacet interface {
	DoLogin(repo string, login string, pass string) error
	Close()

	InspectContainer(ctx context.Context, id string) (types.ContainerJSON, error)
	ListApolloContainers(ctx context.Context) (map[string]ContainerInfo, error)
	CreateUserTask(ctx context.Context, ti *models.TaskStruct, runtime string, subtaskName string,
		envPatch map[string]string, callback ProgressCallback) (string, error)
	StartUserTask(ctx context.Context, id string) error
	WaitForContainer(ctx context.Context, id string) (int64, error)
	CleanupContainer(ctx context.Context, containerId string)
	KillContainer(ctx context.Context, container string) error
	GetTaskStats(ctx context.Context, containerId string) (DockerStats, error)
	FindContainerByName(ctx context.Context, name string) (types.Container, error)
	KillContainerByName(ctx context.Context, name string) (string, error)
}

func NewConnector(info ConnectionInfo) (*Connector, error) {
	var cli *client.Client
	var e error

	if info.DockerAddress == "" {
		cli, e = client.NewEnvClient()
		if e != nil {
			return nil, e
		}
	} else {
		var clientCert tls.Certificate
		var rootCAs *x509.CertPool
		var err error

		caCert, err := tls.X509KeyPair([]byte(info.NodeCACert), []byte(info.NodeCAKey))
		if err != nil {
			return nil, fmt.Errorf("failed to read certificate: %+v", err)
		}
		clientCert = MakeClientCert(caCert)

		rootCAs = x509.NewCertPool()
		block, _ := pem.Decode([]byte(info.NodeCACert))
		if block == nil {
			return nil, fmt.Errorf("failed to read a certificate")
		}
		certificate, err := x509.ParseCertificate(block.Bytes)
		if err != nil {
			return nil, fmt.Errorf("failed to read certificate: %+v", err)
		}
		rootCAs.AddCert(certificate)

		tlsConfig := &tls.Config{
			Certificates: []tls.Certificate{clientCert},
			RootCAs: rootCAs,
		}

		httpClient := &http.Client{
			Transport: &http.Transport{
				TLSClientConfig: tlsConfig,
				MaxIdleConns:    1,
				IdleConnTimeout: 8 * time.Second,
			},
		}

		parsedAddr, e := url.Parse(info.DockerAddress)
		if e != nil {
			return nil, e
		}
		var addr = info.DockerAddress
		if parsedAddr.Port() == "" {
			addr += ":2376"
		}

		cli, e = client.NewClient(addr, "1.34", httpClient, make(map[string]string))
		if e != nil {
			return nil, e
		}
	}

	return &Connector{
		Client:           cli,
		Info:             info,
		AuthTokensByRepo: make(map[string]string),
	}, nil
}

func (d *Connector) DoLogin(repo string, login string, pass string) error {
	if _, ok := d.AuthTokensByRepo[repo+"#"+login]; ok {
		// There's an existing token for this repo, nothing to do
		return nil
	}

	logrus.Infof("Logging into %s", repo)
	ctx := context.Background()

	body, err := d.Client.RegistryLogin(ctx, types.AuthConfig{
		ServerAddress: repo,
		Username:      login,
		Password:      pass,
	})
	if err != nil {
		return err
	}

	if body.Status == "" {
		return fmt.Errorf("failed to get the token from the Docker repository")
	}
	d.AuthTokensByRepo[repo+"#"+login] = body.IdentityToken
	return nil
}

func (d *Connector) Close() {
	_ = d.Client.Close()
}

type ContainerInfo struct {
	Name string
	ID string
	State string
}

func (d *Connector) InspectContainer(ctx context.Context, id string) (types.ContainerJSON, error) {
	return d.Client.ContainerInspect(ctx, id)
}

// Find all the running Apollo containers. This method is run once during the startup
// to recover any possible state after a restart.
func (d *Connector) ListApolloContainers(ctx context.Context) (map[string]ContainerInfo, error) {
	filter := filters.NewArgs()
	filter.Add("label", "apollo-site=apo"+d.Info.Suffix)
	containers, err := d.Client.ContainerList(ctx, types.ContainerListOptions{
		All:     true,
		Filters: filter,
	})
	if err != nil {
		return nil, err
	}

	var res = make(map[string]ContainerInfo)
	for _, c := range containers {
		apolloId := c.Names[0]
		if apolloId[0] == '/' {
			apolloId = apolloId[1:]
		}
		res[apolloId] = ContainerInfo{
			Name: apolloId,
			State: c.State,
			ID: c.ID,
		}
	}

	return res, nil
}

type PullState struct {
	BytesToPull int64
	BytesPulled int64
}

type ProgressDetail struct {
	Current int64
	Total int64
}

type ProgressReport struct {
// {"status":"Downloading","progressDetail":{"current":523018,"total":51359708},"progress":"...","id":"f8efbffe7b95"}
	Status string
	ProgressDetail ProgressDetail
	Progress string
	ID string
}

type ProgressCallback func(state PullState)

func (d *Connector) pullImage(ctx context.Context, image string, callback ProgressCallback) error {
	CL(ctx).Infof("Retrieving image: %s", image)

	authConfig := types.AuthConfig{
		Username: d.Info.DockerLogin,
		Password: d.Info.DockerPassword,
		ServerAddress: d.Info.DockerRepository,
	}

	authBuf, err := json.Marshal(authConfig)
	if err != nil {
		return err
	}
	encodedAuth := base64.URLEncoding.EncodeToString(authBuf)
	if err != nil {
		return err
	}

	named, err := reference.ParseNormalizedNamed(image)
	if err != nil {
		return err
	}
	shortName := reference.FamiliarName(named)

	var options types.ImagePullOptions
	if !strings.Contains(shortName, ".") { // Only hub images don't have dots
		// This is an absolute reference, find its authorization
		// TODO: really need auth here
	} else {
		options = types.ImagePullOptions{
			RegistryAuth: encodedAuth,
		}
	}

	responseBody, err := d.Client.ImagePull(ctx, image, options)
	if err != nil {
		return err
	}
	//noinspection GoUnhandledErrorResult
	defer responseBody.Close()

	pulled := make(map[string]int64)
	totals := make(map[string]int64)
	progress := bufio.NewReader(responseBody)
	for ;; {
		// Look for status messages like this one:
		// {"status":"Downloading","progressDetail":{"current":523018,"total":51359708},"progress":"...","id":"f8efbffe7b95"}
		line, err := progress.ReadBytes('\n')
		if err == io.EOF {
			break
		}

		if err != nil {
			CL(ctx).Debugf("Skipping error from the status reader: %s", err.Error())
			continue
		}

		msg := ProgressReport{}
		err = json.Unmarshal(line, &msg)
		if err != nil {
			CL(ctx).Debugf("Skipping error from the status reader: %s", err.Error())
			continue
		}
		if msg.Status != "Downloading" {
			continue
		}

		pulled[msg.ID] = msg.ProgressDetail.Current
		totals[msg.ID] = msg.ProgressDetail.Total

		// Compute aggregates
		var totalPulled int64
		for _, v := range pulled {
			totalPulled += v
		}
		var totalTotals int64
		for _, v := range totals {
			totalTotals += v
		}

		// Report the progress of the pull operation
		callback(PullState{
			BytesToPull: totalTotals,
			BytesPulled: totalPulled,
		})
	}

	CL(ctx).Infof("Pulled image: %s", image)
	return nil
}

var DuplicateContainerError = fmt.Errorf("container with this ID already exists")
var NonCanonicalRepoError = fmt.Errorf("repository name must be canonical")
var UnauthorizedRepoError = fmt.Errorf("repository name must be canonical")
var ManifestNotFound = fmt.Errorf("manifest was not found")

func (d *Connector) getCurPath(env []string) string {
	for _, e := range env {
		if strings.HasPrefix(e, "PATH=") {
			return e
		}
	}
	return ""
}

// Run a user task!
func (d *Connector) CreateUserTask(ctx context.Context, ti *models.TaskStruct, runtime string,
	subtaskName string, envPatch map[string]string, callback ProgressCallback) (string, error) {

	trimmedRepo := strings.TrimRight(d.Info.DockerRepository, "/")
	split := strings.SplitN(trimmedRepo, "://", 2)
	var repo string
	if len(split) != 1 {
		repo = split[1]
	} else {
		repo = split[0]
	}

	// Resolve the image ID
	var imageId string
	if strings.Index(ti.DockerImageID, ":") > 0 {
		named, err := reference.ParseNormalizedNamed(ti.DockerImageID)
		if err != nil {
			return "", err
		}
		// The ID is fully-qualified repo:tag name
		imageId = named.Name()
	} else {
		// Prepend the queue's default ID
		imageId = repo + ":" + ti.DockerImageID
	}

	allTags := make(map[string]string)
	for k,v := range ti.Tags {
		allTags[k] = v
	}
	allTags["apollo"] = "true"
	allTags["apollo-site"] = "apo" + d.Info.Suffix

	var env []string
	if envPatch != nil {
		for k, v := range envPatch {
			env = append(env, k+"="+v)
		}
	}

	// Check the PATH environment variable and append the Apollo utils there
	imageInspectRes, _, err := d.Client.ImageInspectWithRaw(ctx, imageId)

	if err != nil && client.IsErrImageNotFound(err) {
		// Pull the image
		err = d.pullImage(ctx, imageId, callback)
		if err != nil {
			return "", TranslateDockerError(err)
		}

		imageInspectRes, _, err = d.Client.ImageInspectWithRaw(ctx, imageId)
		if err != nil {
			return "", TranslateDockerError(err)
		}
	}
	if err != nil {
		return "", err
	}

	// Patch our container's path with utilities
	path := d.getCurPath(imageInspectRes.Config.Env)
	if path != "" {
		env = append(env, path + ":/apo")
	}

	containerConfig := &container.Config{
		Image:      imageId,
		Cmd:        ti.Cmdline,
		WorkingDir: ti.Pwd,
		Labels:     allTags,
		Env:        env,
	}
	var t = true
	hostConfig := &container.HostConfig{
		Mounts: []mount.Mount{{
			Type: mount.TypeVolume,
			Source: "ApoParasite" + d.Info.Suffix,
			Target: "/apo",
		}},
		Resources:  container.Resources{Memory: ti.MaxRAMMb * 1024 * 1024},
		Runtime: runtime,
		Init: &t,
	}

	CL(ctx).Infof("Starting container: %s", subtaskName)

	resp, err := d.Client.ContainerCreate(ctx, containerConfig,
		hostConfig, nil, subtaskName)

	CL(ctx).Infof("Created a container: %s", CutStringTo(resp.ID, 20))

	return resp.ID, TranslateDockerError(err)
}

// Use string matching to translate errors. TODO: FIX THIS!!!!
func TranslateDockerError(err error) error {
	if err == nil {
		return nil
	}
	if err != nil && strings.Index(err.Error(), "Error response from daemon: manifest for ") == 0 {
		return ManifestNotFound
	}

	if strings.Index(err.Error(), "Error response from daemon: Conflict.") == 0 {
		return DuplicateContainerError
	}

	if strings.Index(err.Error(), "repository name must be canonical") == 0 {
		return NonCanonicalRepoError
	}

	if strings.HasSuffix(err.Error(), "unauthorized: incorrect username or password") {
		return UnauthorizedRepoError
	}
	return err
}

// Check if the error is permanent (i.e. retries won't help)
func IsPermanentDockerFailure(err error) bool {
	return err == NonCanonicalRepoError || err == ManifestNotFound ||
		err == UnauthorizedRepoError
}

func (d *Connector) StartUserTask(ctx context.Context, id string) error {
	return d.Client.ContainerStart(ctx, id, types.ContainerStartOptions{})
}

func (d *Connector) WaitForContainer(ctx context.Context, id string) (int64, error) {
	return d.Client.ContainerWait(ctx, id)
}

func (d *Connector) CleanupContainer(ctx context.Context, containerId string) {
	//noinspection GoUnhandledErrorResult
	d.Client.ContainerRemove(ctx, containerId, types.ContainerRemoveOptions{Force: true})
}

func (d *Connector) KillContainer(ctx context.Context, container string) error {
	CL(ctx).Infof("Killing container: %s", CutStringTo(container, 16))
	err := d.Client.ContainerKill(ctx, container, "SIGKILL")
	return err
}

type CpuUsage struct {
	TotalUsageNsec int64 `json:"total_usage"`
	PerCpuUsage []int64 `json:"percpu_usage"`
	UserModeUsage int64 `json:"usage_in_usermode"`
	KernelModeUsage int64 `json:"usage_in_kernelmode"`
}

//noinspection GoNameStartsWithPackageName
type DockerCpuStats struct {
	Usage CpuUsage `json:"cpu_usage"`

	OnlineCpus int64 `json:"online_cpus"`
	SystemCpuUsage float64 `json:"system_cpu_usage"`
}

//noinspection GoNameStartsWithPackageName
type DockerMemoryStats struct {
	UsageBytes int64 `json:"usage"`
	MaxUsageBytes int64 `json:"max_usage"`
	LimitBytes int64 `json:"limit"`
}

//noinspection GoNameStartsWithPackageName
type DockerStats struct {
	ReadTime string `json:"read"`

	Cpu DockerCpuStats `json:"cpu_stats"`
	Memory DockerMemoryStats `json:"memory_stats"`
}

func (d *Connector) GetTaskStats(ctx context.Context, containerId string) (DockerStats, error) {

	stats, err := d.Client.ContainerStats(ctx, containerId, false)
	if err != nil {
		return DockerStats{}, err
	}
	//noinspection GoUnhandledErrorResult
	defer stats.Body.Close()

	var buf bytes.Buffer
	_, err = buf.ReadFrom(stats.Body)
	if err != nil {
		return DockerStats{}, err
	}

	statStruct := DockerStats{}
	err = json.Unmarshal(buf.Bytes(), &statStruct)
	if err != nil {
		return DockerStats{}, err
	}

	return statStruct, nil
}

func (d *Connector) FindContainerByName(ctx context.Context, name string) (types.Container, error) {

	flt, err := filters.ParseFlag("name="+name, filters.NewArgs())
	if err != nil {
		return types.Container{}, err
	}

	res, err := d.Client.ContainerList(ctx, types.ContainerListOptions{Filters: flt, All:true})
	if err != nil {
		return types.Container{}, err
	}
	if len(res) == 0 {
		return types.Container{}, fmt.Errorf("container with name '%s' is not found", name)
	}

	contData := res[len(res)-1]
	return contData, nil
}

func (d *Connector) KillContainerByName(ctx context.Context, name string) (string, error) {
	contData, err := d.FindContainerByName(ctx, name)
	if err != nil {
		return "", err
	}

	return contData.ID, d.Client.ContainerKill(ctx, contData.ID, "SIGKILL")
}

// Check if we're reading stats from a dead container
func IsFullStats(curStats DockerStats) bool {
	return curStats.Memory.UsageBytes != 0 && curStats.Cpu.Usage.TotalUsageNsec != 0
}

func ComputeStats(lastStats, curStats DockerStats) (models.TaskPerfStatsEntry, error) {
	res := models.TaskPerfStatsEntry{}

	curTimestamp, err := time.Parse(time.RFC3339Nano, curStats.ReadTime)
	if err != nil {
		return res, err
	}
	res.TimestampEpochNanos = curTimestamp.UnixNano()

	lastTimestamp, err := time.Parse(time.RFC3339Nano, lastStats.ReadTime)
	if err != nil {
		return res, err
	}

	timeDiff := curTimestamp.UnixNano() - lastTimestamp.UnixNano()
	usageDiff := curStats.Cpu.Usage.TotalUsageNsec - lastStats.Cpu.Usage.TotalUsageNsec
	res.CPUUsePercent = float64(usageDiff) / float64(timeDiff) * 100.0

	roundToMb := func(i int64) int64 {
		val := i / (1024*1024)
		if i % (1024*1024) != 0 {
			val += 1
		}
		return val
	}
	res.MaxRAMUseMb = roundToMb(curStats.Memory.MaxUsageBytes)
	res.RAMUseMb = roundToMb(curStats.Memory.UsageBytes)

	return res, nil
}
