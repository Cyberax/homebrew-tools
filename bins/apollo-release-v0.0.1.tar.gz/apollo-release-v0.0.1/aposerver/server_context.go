package aposerver

import (
	"apollo/aposerver/herder"
	"apollo/aposerver/scheduler"
	"apollo/data"
	"apollo/proto/gen/restapi/operations"
	"apollo/proto/gen/restapi/operations/files"
	"apollo/proto/gen/restapi/operations/login"
	"apollo/proto/gen/restapi/operations/node"
	"apollo/proto/gen/restapi/operations/queue"
	"apollo/proto/gen/restapi/operations/task"
	"apollo/proto/sigv4sec"
	"crypto/rand"
	"fmt"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/aws/external"
	"github.com/aws/aws-sdk-go-v2/service/dynamodb"
	"github.com/go-openapi/runtime/middleware"
	"github.com/sirupsen/logrus"
	"github.com/spf13/viper"
	"net"
)

type ServerError struct {
}

type ServerContext struct {
	Verbose   bool
	AwsConfig aws.Config
	KvStore   data.KVStore
	Locks     *data.LockStore

	TlsManager   *HttpTlsManager
	TokenManager *data.TokenManager

	ConnectionChannel chan net.Conn

	// Dependency registry
	ConfigStore    *data.ConfigStore
	TaskStore      *data.TaskStore
	QueueStore     *data.QueueStore
	NodeStore      *data.NodeStore
	WhitelistStore *data.WhitelistStore

	SiteSuffix          string

	// Node talker
	Herder *herder.Herder

	// Transistor
	Transistor *scheduler.Transistor
	Scheduler *scheduler.Scheduler
}

func (ctx* ServerContext) InitRegistry(v *viper.Viper) error {
	logrus.Info("Initializing the registry")

	ctx.ConnectionChannel = make(chan net.Conn, 1)

	// Create the AWS context
	AwsConfig, err := external.LoadDefaultAWSConfig(
		external.WithSharedConfigProfile(v.GetString("aws.profile")),
		external.WithRegion(v.GetString("aws.region")),
	)
	if err != nil {
		return err
	}
	ctx.AwsConfig = AwsConfig

	// Create the database
	storeType := v.GetString("database.type")
	logrus.Infof("Using taskStore type: %s", storeType)
	switch storeType {
	case "ddb":
		ctx.KvStore = data.NewDynamoDbStore(
			dynamodb.New(ctx.AwsConfig), v.GetString("database.prefix"))
	case "mem":
		ctx.KvStore = data.NewFakeMemStore()
	case "redis":
		ctx.KvStore = data.NewRedisStore(v.GetString("database.prefix"),
			v.GetString("database.redis-addr"), v.GetString("database.redis-password"))
	default:
		return data.NewStoreError("Unknown taskStore type " + storeType, nil)
	}

	// Create schema
	logrus.Info("Initializing the schema")
	err = ctx.KvStore.InitSchema(map[string]int64 {
		data.ConfigStoreTable: 2,
		data.WhitelistTable:   1,
		data.TaskTable:        10,
		data.SubtaskTable:     10,
		data.QueueTable:       5,
		data.NodeTable:        5,
	})
	if err != nil {
		return err
	}

	ctx.Locks = data.NewLockStore()

	// Config
	ctx.ConfigStore = data.NewConfigStore(ctx.KvStore)
	// Whitelists
	ctx.WhitelistStore = data.NewWhitelistStore(ctx.KvStore)
	// Queue taskStore
	ctx.QueueStore = data.NewQueueStore(ctx.KvStore)
	// Node taskStore
	ctx.NodeStore = data.NewNodeStore(ctx.KvStore)
	// Task taskStore
	ctx.TaskStore = data.NewTaskStore(ctx.KvStore, ctx.NodeStore)

	err = ctx.HydrateStores()
	if err != nil {
		return err
	}

	// Whitelisted accounts
	for _, acct := range v.GetStringSlice("server.whitelisted-accounts") {
		if acct == "self" {
			logrus.Info("Resolving the 'self' account...")
			acct, err = sigv4sec.GetMyAccountId(ctx.AwsConfig)
			if err != nil {
				return err
			}
			logrus.Infof("...the 'self' account is: '%s'.", acct)
		}
		ctx.WhitelistStore.AddPreconfigured(acct)
	}

	// Site suffix
	suffix := v.GetString("server.site-suffix")
	if suffix == "" || suffix == "auto" {
		ctx.SiteSuffix, err = MakeAutoSiteSuffix(ctx.ConfigStore)
		if err != nil {
			return err
		}
	} else {
		logrus.Infof("Using the stored site suffix: %s", suffix)
		if suffix[0] != '-' {
			suffix = "-" + suffix
		}
		ctx.SiteSuffix = suffix
	}

	// Auth tokens
	ctx.TokenManager, err = MakeTokenManger(ctx.ConfigStore)
	if err != nil {
		return err
	}

	// Build the TLS manager
	ctx.TlsManager = NewTlsManager()
	err = ctx.TlsManager.Init(ctx.ConfigStore, v.GetString("listen.interface"),
		v.GetInt("listen.port"),
		v.GetString("listen.certfile"),
		v.GetString("listen.keyfile"),
		v.GetString("listen.probe-host"))
	if err != nil {
		return err
	}

	stores := data.Stores {
		QS: ctx.QueueStore,
		NS: ctx.NodeStore,
		TS: ctx.TaskStore,
		LS: ctx.Locks,
	}

	tmff := herder.NewTaskMinderFactory(ctx.SiteSuffix, stores, ctx.TokenManager,
		ctx.TlsManager.OurCert)

	ctx.Herder = herder.NewHerder(ctx.SiteSuffix, ctx.ConnectionChannel, stores, tmff)

	ctx.Transistor = scheduler.NewTransistor(ctx.TaskStore, ctx.Locks)

	ctx.Scheduler = scheduler.NewScheduler(stores)

	return nil
}

func MakeTokenManger(store *data.ConfigStore) (*data.TokenManager, error) {
	var tokenKey string
	err, gotIt := store.GetConfigByKey("server.token-key", &tokenKey)
	if err != nil {
		return nil, err
	}
	if !gotIt {
		tokenKey = data.NewAesKey()
		err := store.StoreConfig("server.token-key", tokenKey)
		logrus.Infof("Generated a new token encryption key")
		if err != nil {
			return nil, err
		}
	}
	manager, err := data.NewTokenManager(tokenKey)
	if err != nil {
		return nil, err
	}
	logrus.Infof("Using stored token encryption key")
	return manager, nil
}

func MakeAutoSiteSuffix(store *data.ConfigStore) (string, error) {
	var suffix string
	err, gotIt := store.GetConfigByKey("server.site-suffix", &suffix)
	if err != nil {
		return "", err
	}
	if gotIt {
		logrus.Infof("Using the stored suffix: %s", suffix)
		return suffix, nil
	}

	// Generate a random 6-character suffix
	var randBytes = make([]byte, 3)
	_, err = rand.Read(randBytes)
	if err != nil {
		return "", err
	}

	suffix = fmt.Sprintf("-%x%x%x", randBytes[0], randBytes[1], randBytes[2])
	err = store.StoreConfig("server.site-suffix", suffix)
	if err != nil {
		return "", err
	}
	logrus.Infof("Generated a new suffix: %s", suffix)

	return suffix, nil
}

func (ctx *ServerContext) HydrateStores() error {
	logrus.Info("Hydrating the in-memory stores:")
	sess := ctx.Locks.Session(nil)
	defer sess.UnlockAll()

	logrus.Info("- Config store...")
	err := ctx.ConfigStore.Hydrate()
	if err != nil {
		return err
	}
	logrus.Info("...done!")

	logrus.Info("- Whitelist store...")
	err = ctx.WhitelistStore.Hydrate()
	if err != nil {
		return err
	}
	logrus.Info("...done!")

	logrus.Info("- Task store...")
	err = ctx.TaskStore.Hydrate(sess)
	if err != nil {
		return err
	}
	logrus.Info("...done!")
	logrus.Info("- Node store...")
	err = ctx.NodeStore.Hydrate(ctx.TaskStore, sess)
	if err != nil {
		return err
	}
	logrus.Info("...done!")
	logrus.Info("- Queue store...")
	err = ctx.QueueStore.Hydrate(sess)
	if err != nil {
		return err
	}
	logrus.Info("...done!")
	logrus.Info("Stores are now hydrated")

	return nil
}

func (ctx *ServerContext) Close() {
}

func WireUpAuth(api *operations.ApolloAPI, ctx *ServerContext) {
	// Login
	api.LoginPostSigv4LoginHandler = login.PostSigv4LoginHandlerFunc(
		func(params login.PostSigv4LoginParams) middleware.Responder {
			sess := ctx.Locks.Session(params.HTTPRequest.Context())
			defer sess.UnlockAll()

			lp := LoginProcessor{
				sess:                sess,
				aws:                 ctx.AwsConfig,
				tokens:              ctx.TokenManager,
				serverCert:          ctx.TlsManager.OurCert,
				whitelisted:         ctx.WhitelistStore,
				params:              params,
			}
			return lp.Enact()
		})

	// Pingy-pongy!
	api.LoginGetPingHandler = login.GetPingHandlerFunc(
		func(params login.GetPingParams, principal interface{}) middleware.Responder {
			return login.NewGetPingOK()
		})

	// Whitelist manipulation
	api.LoginGetWhitelistHandler = login.GetWhitelistHandlerFunc(
		func(params login.GetWhitelistParams, principal interface{}) middleware.Responder {
			sess := ctx.Locks.Session(params.HTTPRequest.Context())
			defer sess.UnlockAll()

			lp := WhitelistGetProcessor{
				sess:                sess,
				whitelisted:         ctx.WhitelistStore,
				params:              params,
			}
			return lp.Enact()
		})

	api.LoginPutWhitelistEntryHandler = login.PutWhitelistEntryHandlerFunc(
		func(params login.PutWhitelistEntryParams, principal interface{}) middleware.Responder {
			sess := ctx.Locks.Session(params.HTTPRequest.Context())
			defer sess.UnlockAll()

			lp := WhitelistAddProcessor{
				sess:                sess,
				whitelisted:         ctx.WhitelistStore,
				params:              params,
				principal:           principal.(data.AuthToken),
			}
			return lp.Enact()
		})

	api.LoginDeleteWhitelistEntryHandler = login.DeleteWhitelistEntryHandlerFunc(
		func(params login.DeleteWhitelistEntryParams, principal interface{}) middleware.Responder {
			sess := ctx.Locks.Session(params.HTTPRequest.Context())
			defer sess.UnlockAll()

			lp := WhitelistDeleteProcessor{
				sess:                sess,
				whitelisted:         ctx.WhitelistStore,
				params:              params,
				principal:           principal.(data.AuthToken),
			}
			return lp.Enact()
		})
}

func WireUpTasks(ctx *ServerContext, api *operations.ApolloAPI) {
	api.TaskPutTaskHandler = task.PutTaskHandlerFunc(
		func(params task.PutTaskParams, principal interface{}) middleware.Responder {
			sess := ctx.Locks.Session(params.HTTPRequest.Context())
			defer sess.UnlockAll()

			tp := TaskSubmitProcessor{
				sess: sess,
				store: ctx.TaskStore,
				queueStore: ctx.QueueStore,
				kvStore: ctx.KvStore,
				principal: principal.(data.AuthToken),
				params: params,
			}
			return tp.Enact()
		})

	api.TaskGetTaskListHandler = task.GetTaskListHandlerFunc(
		func(params task.GetTaskListParams, principal interface{}) middleware.Responder {
			sess := ctx.Locks.Session(params.HTTPRequest.Context())
			defer sess.UnlockAll()

			lp := ListTasksProcessor{
				sess: sess,
				store: ctx.TaskStore,
				params: params,
			}
			return lp.Enact()
		})

	api.TaskPutTaskAssignmentHandler = task.PutTaskAssignmentHandlerFunc(
		func(params task.PutTaskAssignmentParams, principal interface{}) middleware.Responder {
			sess := ctx.Locks.Session(params.HTTPRequest.Context())
			defer sess.UnlockAll()

			lp := AssignTaskProcessor{
				sess:       sess,
				taskStore:  ctx.TaskStore,
				queueStore: ctx.QueueStore,
				nodeStore:  ctx.NodeStore,
				params:     params,
			}
			return lp.Enact()
		})

	api.TaskPutTaskCancellationHandler = task.PutTaskCancellationHandlerFunc(
		func(params task.PutTaskCancellationParams, principal interface{}) middleware.Responder {
			sess := ctx.Locks.Session(params.HTTPRequest.Context())
			defer sess.UnlockAll()

			lp := CancelTaskProcessor{
				sess:       sess,
				taskStore:  ctx.TaskStore,
				params:     params,
			}
			return lp.Enact()
		})

	api.TaskGetTaskWaitHandler = task.GetTaskWaitHandlerFunc(
		func(params task.GetTaskWaitParams, principal interface{}) middleware.Responder {
			sess := ctx.Locks.Session(params.HTTPRequest.Context())
			defer sess.UnlockAll()

			lp := WaitTaskProcessor{
				locker:     ctx.Locks,
				sess:       sess,
				taskStore:  ctx.TaskStore,
				params:     params,
			}
			return lp.Enact()
		})

	api.TaskGetSubtaskListHandler = task.GetSubtaskListHandlerFunc(
		func(params task.GetSubtaskListParams, principal interface{}) middleware.Responder {
			sess := ctx.Locks.Session(params.HTTPRequest.Context())
			defer sess.UnlockAll()

			lp := ListSubTasksProcessor{
				sess:       sess,
				store:      ctx.TaskStore,
				params:     params,
			}
			return lp.Enact()
		})

	api.TaskPostTaskLaunchHandler =task.PostTaskLaunchHandlerFunc(
		func(params task.PostTaskLaunchParams, principal interface{}) middleware.Responder {
			sess := ctx.Locks.Session(params.HTTPRequest.Context())
			defer sess.UnlockAll()

			lp := CompletedDownloadsTaskProcessor{
				sess:       sess,
				taskStore:  ctx.TaskStore,
				params:     params,
			}
			return lp.Enact()
		})
}

func WireUpNodes(ctx *ServerContext, api *operations.ApolloAPI) {
	api.NodePutUnmanagedNodeHandler = node.PutUnmanagedNodeHandlerFunc(
		func(params node.PutUnmanagedNodeParams, principal interface{}) middleware.Responder {
			sess := ctx.Locks.Session(params.HTTPRequest.Context())
			defer sess.UnlockAll()

			dq := PutUnmanagedNodeProcessor{
				sess: sess,
				store: ctx.NodeStore,
				queueStore: ctx.QueueStore,
				params: params,
				principal: principal.(data.AuthToken),
			}
			return dq.Enact()
		})

	api.NodePutEc2NodeHandler = node.PutEc2NodeHandlerFunc(
		func(params node.PutEc2NodeParams, principal interface{}) middleware.Responder {
			sess := ctx.Locks.Session(params.HTTPRequest.Context())
			defer sess.UnlockAll()

			dq := PutEc2NodeProcessor{
				sess: sess,
				awsConn: ctx.AwsConfig,
				store: ctx.NodeStore,
				queueStore: ctx.QueueStore,
				params: params,
				principal: principal.(data.AuthToken),
			}
			return dq.Enact()
		})

	api.NodeGetNodeListHandler = node.GetNodeListHandlerFunc(
		func(params node.GetNodeListParams, principal interface{}) middleware.Responder {
			sess := ctx.Locks.Session(params.HTTPRequest.Context())
			defer sess.UnlockAll()

			ln := ListNodesProcessor{
				sess: sess,
				store: ctx.NodeStore,
				params: params,
			}
			return ln.Enact()
		})

	api.NodePostCertificateHandler = node.PostCertificateHandlerFunc(
		func(params node.PostCertificateParams, principal interface{}) middleware.Responder {
			sess := ctx.Locks.Session(params.HTTPRequest.Context())
			defer sess.UnlockAll()

			lp := GetNodeCertProcessor{
				sess:   sess,
				store:  ctx.NodeStore,
				params: params,
			}
			return lp.Enact()
		})

	api.NodeGetDockerConnectionHandler = node.GetDockerConnectionHandlerFunc(
		func(params node.GetDockerConnectionParams, principal interface{}) middleware.Responder {
			sess := ctx.Locks.Session(params.HTTPRequest.Context())
			defer sess.UnlockAll()

			lp := GetNodeDockerConnProcessor{
				sess:   sess,
				store:  ctx.NodeStore,
				params: params,
			}
			return lp.Enact()
		})
}

func WireUpQueues(api *operations.ApolloAPI, ctx *ServerContext) {
	// Queues
	api.QueueGetQueueListHandler = queue.GetQueueListHandlerFunc(
		func(params queue.GetQueueListParams, principal interface{}) middleware.Responder {
			sess := ctx.Locks.Session(params.HTTPRequest.Context())
			defer sess.UnlockAll()

			lq := ListQueueProcessor{
				sess:      sess,
				store:     ctx.QueueStore,
				nodeStore: ctx.NodeStore,
				taskStore: ctx.TaskStore,
				params:    params,
			}
			return lq.Enact()
		})
	api.QueuePutQueueHandler = queue.PutQueueHandlerFunc(
		func(params queue.PutQueueParams, principal interface{}) middleware.Responder {
			sess := ctx.Locks.Session(params.HTTPRequest.Context())
			defer sess.UnlockAll()

			pq := PutQueueProcessor{
				aws: ctx.AwsConfig,
				sess:      sess,
				store:  ctx.QueueStore,
				params: params,
			}
			return pq.Enact()
		})

	api.QueueDeleteQueueHandler = queue.DeleteQueueHandlerFunc(
		func(params queue.DeleteQueueParams, principal interface{}) middleware.Responder {
			sess := ctx.Locks.Session(params.HTTPRequest.Context())
			defer sess.UnlockAll()

			dq := DeleteQueueProcessor{
				sess:      sess,
				store:     ctx.QueueStore,
				taskStore: ctx.TaskStore,
				params:    params,
			}
			return dq.Enact()
		})
}

func WireUpFiles(ctx *ServerContext, api *operations.ApolloAPI) {
	api.FilesPutFilesHandler = files.PutFilesHandlerFunc(
		func(params files.PutFilesParams, principal interface{}) middleware.Responder {
			sess := ctx.Locks.Session(params.HTTPRequest.Context())
			defer sess.UnlockAll()

			dq := PutFileProcessor{
				sess:       sess,
				aws:        ctx.AwsConfig,
				queueStore: ctx.QueueStore,
				store:      ctx.TaskStore,
				params:     params,
			}
			return dq.Enact()
		})

	api.FilesGetFilesListHandler = files.GetFilesListHandlerFunc(
		func(params files.GetFilesListParams, principal interface{}) middleware.Responder {
			sess := ctx.Locks.Session(params.HTTPRequest.Context())
			defer sess.UnlockAll()

			dq := ListFileProcessor{
				sess:       sess,
				aws:        ctx.AwsConfig,
				queueStore: ctx.QueueStore,
				store:      ctx.TaskStore,
				params:     params,
			}
			return dq.Enact()
		})

	api.FilesPutFilesExposureHandler = files.PutFilesExposureHandlerFunc(
		func(params files.PutFilesExposureParams, principal interface{}) middleware.Responder {
			sess := ctx.Locks.Session(params.HTTPRequest.Context())
			defer sess.UnlockAll()

			dq := ExposeFileProcessor{
				sess:       sess,
				aws:        ctx.AwsConfig,
				queueStore: ctx.QueueStore,
				store:      ctx.TaskStore,
				params:     params,
			}
			return dq.Enact()
		})

	api.FilesGetFilesHandler = files.GetFilesHandlerFunc(
		func(params files.GetFilesParams, principal interface{}) middleware.Responder {
			sess := ctx.Locks.Session(params.HTTPRequest.Context())
			defer sess.UnlockAll()

			dq := GetFileProcessor{
				sess:       sess,
				aws:        ctx.AwsConfig,
				queueStore: ctx.QueueStore,
				store:      ctx.TaskStore,
				params:     params,
			}
			return dq.Enact()
		})

	api.FilesDeleteFilesHandler = files.DeleteFilesHandlerFunc(
		func(params files.DeleteFilesParams, principal interface{}) middleware.Responder {
			sess := ctx.Locks.Session(params.HTTPRequest.Context())
			defer sess.UnlockAll()

			dq := DeleteFileProcessor{
				sess:       sess,
				aws:        ctx.AwsConfig,
				queueStore: ctx.QueueStore,
				store:      ctx.TaskStore,
				params:     params,
			}
			return dq.Enact()
		})
}

func WireUpHandlers(ctx *ServerContext, api *operations.ApolloAPI) {
	WireUpAuth(api, ctx)

	WireUpTasks(ctx, api)

	WireUpQueues(api, ctx)

	WireUpNodes(ctx, api)

	WireUpFiles(ctx, api)
}
