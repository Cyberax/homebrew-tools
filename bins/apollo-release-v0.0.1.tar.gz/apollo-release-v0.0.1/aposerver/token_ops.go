package aposerver

import (
	"apollo/data"
	"apollo/proto/gen/restapi/operations/login"
	"apollo/proto/sigv4sec"
	. "apollo/utils"
	"crypto/rand"
	"encoding/base64"
	"fmt"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/go-openapi/runtime/middleware"
	"github.com/go-openapi/strfmt"
	"golang.org/x/crypto/nacl/box"
	"net/http"
	"time"
)

const UserTokenValidDuration = 24 * time.Hour

type LoginProcessor struct {
	sess *data.Session
	aws aws.Config
	tokens *data.TokenManager
	serverCert string
	whitelisted *data.WhitelistStore
	params login.PostSigv4LoginParams
}

// Authorize the SigV4 signed request using and create the appropriate token.
// If the request is made from an instance profile we automatically create a
// node-linked token. TODO: don't actually do this?
func (l *LoginProcessor) Enact() middleware.Responder {
	l.sess.L().Infof("Invoking LoginProcessor")

	tokenBytes, err := base64.StdEncoding.DecodeString(l.params.Token)
	if err != nil {
		l.sess.L().Warnf("Failed to decode login box: %+v", err.Error())
		return SendErrorSCE(l.sess.Ctx(), http.StatusUnauthorized, err)
	}
	auth, err := sigv4sec.AuthenticateUser(tokenBytes, l.aws, l.whitelisted.IsWhitelisted)
	if err != nil {
		l.sess.L().Warnf("Failed to authenticate user: %+v", err.Error())
		return SendErrorSCE(l.sess.Ctx(), http.StatusUnauthorized, err)
	}
	l.sess.L().Infof("User %s authenticated successfully", auth.AccountId)

	validUntil := FromTime(time.Now().Add(UserTokenValidDuration))

	// Create a user or node token
	token := data.AuthToken {
		Expires: validUntil,
		Type:    data.UserToken,
		EntityKey: auth.AccountId,
		RequestedBy: "account/"+auth.AccountId,
		RequestedOn: FromTime(time.Now()),
	}

	tokenEnc := l.tokens.EncryptToken(token)

	senderPublicKey, senderPrivateKey, err := box.GenerateKey(rand.Reader)
	if err != nil {
		panic(err)
	}

	// Ok, the user is good. Let's use their pubkey to sign the welcome request!
	greeting := login.PostSigv4LoginOKBody{
		EncryptedAuthToken:   EncryptMessage(tokenEnc, auth.PublicKey, senderPrivateKey),
		EncryptedCertificate: EncryptMessage(l.serverCert, auth.PublicKey, senderPrivateKey),
		ServerPublicKey:      base64.StdEncoding.EncodeToString((*senderPublicKey)[:]),
		ValidUntil:           strfmt.DateTime(validUntil.ToTime()), // TODO: must be encrypted as well
	}
	return login.NewPostSigv4LoginOK().WithPayload(&greeting)
}

type WhitelistGetProcessor struct {
	sess *data.Session
	whitelisted *data.WhitelistStore
	params login.GetWhitelistParams
}

func (w *WhitelistGetProcessor) Enact() middleware.Responder {
	w.sess.L().Infof("Invoking WhitelistGetProcessor")
	return login.NewGetWhitelistOK().WithPayload(w.whitelisted.GetList())
}


type WhitelistAddProcessor struct {
	sess *data.Session
	whitelisted *data.WhitelistStore
	params login.PutWhitelistEntryParams
	principal data.AuthToken
}

func (w *WhitelistAddProcessor) Enact() middleware.Responder {
	w.sess.L().Infof("Invoking WhitelistAddProcessor")
	if !w.whitelisted.IsPreconfigured(w.principal.EntityKey) {
		err := "only preconfigured accounts can enroll new keys"
		w.sess.L().Warnf(err)
		return SendErrorSCE(w.sess.Ctx(), http.StatusBadRequest, fmt.Errorf(err))
	}

	w.whitelisted.AddWhitelist(w.params.AccountID)
	return login.NewPutWhitelistEntryOK()
}


type WhitelistDeleteProcessor struct {
	sess *data.Session
	whitelisted *data.WhitelistStore
	params login.DeleteWhitelistEntryParams
	principal data.AuthToken
}

func (w *WhitelistDeleteProcessor) Enact() middleware.Responder {
	w.sess.L().Infof("Invoking WhitelistDeleteProcessor")
	if !w.whitelisted.IsPreconfigured(w.principal.EntityKey) {
		err := "only preconfigured accounts can enroll new keys"
		w.sess.L().Warnf(err)
		return SendErrorSCE(w.sess.Ctx(), http.StatusBadRequest, fmt.Errorf(err))
	}

	err := w.whitelisted.DeleteWhitelist(w.params.AccountID)
	if err != nil {
		w.sess.L().Warnf("Failed to delete whitelist: %+v", err.Error())
		return SendErrorSCE(w.sess.Ctx(), http.StatusBadRequest, err)
	}
	return login.NewPutWhitelistEntryOK()
}
