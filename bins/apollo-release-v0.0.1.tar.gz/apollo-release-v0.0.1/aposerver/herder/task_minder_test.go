package herder

import (
	"apollo/aposerver/docker"
	_ "apollo/aposerver/statik"
	"apollo/data"
	"apollo/proto/gen/models"
	"apollo/utils"
	"context"
	"fmt"
	"github.com/docker/docker/api/types"
	"github.com/docker/docker/pkg/random"
	"github.com/sirupsen/logrus"
	"github.com/stretchr/testify/assert"
	"os"
	"sync/atomic"
	"testing"
	"time"
)

type DelayedDocker struct {
	delegate  docker.ConnectorFacet
	delayTime time.Duration
	count     int64
}

func (d *DelayedDocker) DoLogin(repo string, login string, pass string) error {
	return d.delegate.DoLogin(repo, login, pass)
}

func (d *DelayedDocker) Close() {
	d.delegate.Close()
}

func (d *DelayedDocker) InspectContainer(ctx context.Context, id string) (types.ContainerJSON, error) {
	return d.delegate.InspectContainer(ctx, id)
}

func (d *DelayedDocker) ListApolloContainers(ctx context.Context) (map[string]docker.ContainerInfo, error) {
	return d.delegate.ListApolloContainers(ctx)
}

func (d *DelayedDocker) CreateUserTask(ctx context.Context, ti *models.TaskStruct, runtime string,
	subtaskName string, envPatch map[string]string,
	callback docker.ProgressCallback) (string, error) {

	atomic.AddInt64(&d.count, 1)
	time.Sleep(d.delayTime)
	return d.delegate.CreateUserTask(ctx, ti, runtime, subtaskName, envPatch, callback)
}

func (d *DelayedDocker) StartUserTask(ctx context.Context, id string) error {
	return d.delegate.StartUserTask(ctx, id)
}

func (d *DelayedDocker) WaitForContainer(ctx context.Context, id string) (int64, error) {
	return d.delegate.WaitForContainer(ctx, id)
}

func (d *DelayedDocker) CleanupContainer(ctx context.Context, containerId string) {
	d.delegate.CleanupContainer(ctx, containerId)
}

func (d *DelayedDocker) KillContainer(ctx context.Context, container string) error {
	return d.delegate.KillContainer(ctx, container)
}

func (d *DelayedDocker) GetTaskStats(ctx context.Context, containerId string) (docker.DockerStats, error) {
	return d.delegate.GetTaskStats(ctx, containerId)
}

func (d *DelayedDocker) FindContainerByName(ctx context.Context, name string) (types.Container, error) {
	return d.delegate.FindContainerByName(ctx, name)
}

func (d *DelayedDocker) KillContainerByName(ctx context.Context, name string) (string, error) {
	return d.delegate.KillContainerByName(ctx, name)
}

func TestMain(m *testing.M) {
	//logrus.SetLevel(logrus.FatalLevel)
	os.Exit(m.Run())
}

type TestContext struct {
	context    context.Context
	Locker     *data.LockStore
	TaskStore  *data.TaskStore
	Stores     data.Stores
	Minder	   *TaskMinder
	Docker     *DelayedDocker
	TS         models.TaskStruct
	TID        string
	suffix     string
	cancel 	   context.CancelFunc
}

func (tc *TestContext) Cleanup() {
	tc.Minder.KillRunningTask()
}

func NewTestContext(maxTries int64, exitCode int64) *TestContext {
	tid := fmt.Sprintf("t-%d", random.Rand.Int31())
	return NewTestContextWithTaskId(tid, makeTestSuffix(), maxTries, exitCode)
}

func NewTestContextWithTaskId(tid string, suffix string,
	maxTries int64, exitCode int64) *TestContext {
	store := data.NewFakeMemStore()
	//noinspection GoUnhandledErrorResult
	store.InitSchema(map[string]int64{
		data.ConfigStoreTable: 5,
		data.TaskTable: 5,
		data.NodeTable: 5,
		data.SubtaskTable: 5,
	})
	nodeStore := data.NewNodeStore(store)
	queueStore := data.NewQueueStore(store)
	taskStore := data.NewTaskStore(store, nodeStore)
	locker := data.NewLockStore()

	ctx := context.Background()
	ctx = utils.SaveLoggerToContext(ctx, logrus.StandardLogger())
	ctx, cancel := context.WithCancel(ctx)
	sess := locker.Session(ctx)

	_ = nodeStore.StoreNode(&data.StoredNode{Key: "n-1"}, sess)

	cmdLine := []string{"/bin/sh", "-c",
		fmt.Sprintf("echo Hello; sleep 5; echo World; sleep 5; exit %d;", exitCode)}

	ts := models.TaskStruct{Queue: "test-queue", DockerImageID: "docker.io/library/alpine:3.7",
		Cmdline: cmdLine, ExpectedRAMMb: 10, MaxRAMMb: 12,
		Tags: map[string]string{"test-run": "true"},
		StartArrayIndex: 0, EndArrayIndex: 2, MaxTries: maxTries,}
	st := data.StoredTask{
		TaskStruct: ts,
		Key: tid,
	}

	_ = taskStore.StoreTask(&st, sess)

	stores := data.Stores {
		TS: taskStore,
		LS: locker,
		NS: nodeStore,
		QS: queueStore,
	}

	subtaskKey := data.SubtaskKey{ParentKey: tid, Index: 1}
	subtask := *taskStore.GetSubtask(subtaskKey, sess, data.LockModeFull)
	subtask.CurrentAssignment = &models.SubtaskAssignment{AssignedNode: "n-1"}
	subtask.Status = models.SubtaskStateEnumDispatched
	taskStore.UpdateSubtask(&subtask, sess)

	sess.UnlockAll()

	connector, e := docker.NewConnector(docker.ConnectionInfo{
		Suffix: suffix,
	})
	utils.PanicIf(e != nil, "Bad")

	dd := &DelayedDocker{delegate: connector}
	minder := NewTaskMinder(ctx, suffix,
		data.SubtaskKeyWithRetry{SKey: subtaskKey}, dd, nil, "", stores)

	return &TestContext{
		context:   ctx,
		Docker:    dd,
		Locker:    locker,
		TaskStore: taskStore,
		Stores:    stores,
		Minder:    minder.(*TaskMinder),
		cancel:    cancel,
		suffix:    suffix,
		TS:        ts,
		TID:       tid,
	}
}

func TestTaskMinder_DelayChan(t *testing.T) {
	t.Parallel()
	tst := NewTestContext(1, 0)
	defer tst.Cleanup()
	start := time.Now()

	delayChan := tst.Minder.DelayChan(0)
	<-delayChan
	assert.True(t, time.Now().Sub(start).Seconds() < 1)

	start = time.Now()
	delayChan = tst.Minder.DelayChan(1)
	<-delayChan
	assert.True(t, time.Now().Sub(start).Seconds() > 1)
}

func TestTaskPull(t *testing.T) {
	t.Parallel()
	tst := NewTestContext(1, 0)

	// Try to clean up the image
	assert.NoError(t, tst.Minder.doPullState(&tst.TS,"", nil))

	// Create a new test context with the new database and everything, it
	// still shares the same Docker connection so that it'll see the existing container
	// and pick it up.
	tstAnother := NewTestContextWithTaskId(tst.TID, tst.suffix, 1, 0)
	assert.NoError(t, tstAnother.Minder.doPullState(&tstAnother.TS, "",nil))
	assert.True(t, models.SubtaskStateEnumCreated == getSubtask(tstAnother).Status)

	// Test that the container is available
	ctx := context.Background()
	containers, err := tst.Docker.ListApolloContainers(ctx)
	assert.NoError(t, err)

	assert.Equal(t, "created",
		containers[GetTaskId(tst.suffix, tst.Minder.Key, tst.Minder.RetryNum)].State)

	// Clean it up
	tst.Minder.KillRunningTask()

	// The container is still here, but it's in the "exited" state
	containers, err = tst.Docker.ListApolloContainers(ctx)
	c, ok := containers[GetTaskId(tst.suffix, tst.Minder.Key, tst.Minder.RetryNum)]
	assert.True(t, ok)
	assert.Equal(t, "created", c.State)

	// Now clean it up
	tst.Docker.CleanupContainer(ctx, c.ID)
	// And it disappears
	containers, err = tst.Docker.ListApolloContainers(ctx)
	_, ok = containers[GetTaskId(tst.suffix, tst.Minder.Key, tst.Minder.RetryNum)]
	assert.False(t, ok)

	tst.Cleanup()
}

func getSubtask(tst *TestContext) *data.Subtask {
	sess := tst.Locker.Session(context.Background())
	subtask := tst.TaskStore.GetSubtask(tst.Minder.Key, sess, data.LockModeNone)
	return subtask
}

func TestTaskPullTimeouts(t *testing.T) {
	t.Parallel()
	tst := NewTestContext(1, 0)
	defer tst.Cleanup()
	tst.Docker.delayTime = 2 * time.Second

	// Test when the pull takes too long
	tst.Minder.MaxPullDuration = time.Second

	err := tst.Minder.doPullState(&tst.TS, "",nil)
	assert.True(t, err == context.DeadlineExceeded)
}

func TestTaskCancel(t *testing.T) {
	t.Parallel()
	tst := NewTestContext(1, 0)
	defer tst.Cleanup()

	tst.Docker.delayTime = 2 * time.Second
	var completed = make(chan error, 1)

	go func() {
		//noinspection GoUnhandledErrorResult
		completed <- tst.Minder.doPullState(&tst.TS, "",nil)
	}()
	for ;atomic.LoadInt64(&tst.Docker.count)==0; {
		time.Sleep(100 * time.Millisecond)
	}
	tst.cancel()
	assert.True(t, <-completed == context.Canceled)
}

func TestStartAndWait(t *testing.T) {
	t.Parallel()
	tst := NewTestContext(1,0 )
	defer tst.Cleanup()

	assert.NoError(t, tst.Minder.doPullState(&tst.TS, "",nil))

	// Start the container
	contId := getSubtask(tst).CurrentAssignment.ContainerID
	assert.NoError(t, tst.Minder.doStartState(contId))

	// Create a new test context with the new database and everything, it
	// still shares the same Docker connection so that it'll see the existing container
	// and pick it up.
	tstAnother := NewTestContextWithTaskId(tst.TID, tst.suffix, 1, 0)
	assert.NoError(t, tstAnother.Minder.doPullState(&tstAnother.TS, "",nil))
	assert.True(t, models.SubtaskStateEnumStarted == getSubtask(tstAnother).Status)

	done := make(chan bool, 1)
	go tst.Minder.doStatsLoop(contId, done)
	assert.NoError(t, tst.Minder.doWaitState(contId))

	stats := getSubtask(tst).PerfStats
	assert.True(t, stats.CurValues.MaxRAMUseMb > 0)

	tstFinished := NewTestContextWithTaskId(tst.TID, tst.suffix, 1, 0)
	assert.NoError(t, tstFinished.Minder.doPullState(&tstFinished.TS, "",nil))
	assert.NoError(t, tstFinished.Minder.doWaitState(contId))
	finished := getSubtask(tstFinished)
	assert.True(t, models.SubtaskStateEnumDone == finished.Status)
	assert.True(t, 0 == finished.PriorAssignments["0"].ExitCode)

	tstFull := NewTestContextWithTaskId(tst.TID, tst.suffix, 1, 0)
	tstFull.Minder.DoTransitions()
	tstFull.Minder.DoTransitions() // Idempotent
	fullCycleTask := getSubtask(tstFull)
	assert.True(t, models.SubtaskStateEnumDone == fullCycleTask.Status)
	assert.True(t, 0 == finished.PriorAssignments["0"].ExitCode)
}

func TestFullCycle(t *testing.T) {
	t.Parallel()
	tst := NewTestContext(1, 1)
	tst.Minder.DoTransitions()
	tst.Minder.DoTransitions() // Idempotent
	fullCycleTask := getSubtask(tst)
	// Retries are exhausted and the task is marked as done
	assert.True(t, models.SubtaskStateEnumFailed == fullCycleTask.Status)
	assert.True(t, 1 == fullCycleTask.PriorAssignments["0"].ExitCode)

	// Container is still lingering
	containers, _ := tst.Docker.ListApolloContainers(tst.context)
	_, ok := containers[GetTaskId(tst.suffix, tst.Minder.Key, tst.Minder.RetryNum)]
	assert.True(t, ok)

	// Now sweep up the containers - the threshold is large, so our container is not sweeped
	SweepDeadContainers(tst.context, "n-1", tst.Docker, tst.Stores,
		10000*time.Second)

	containers, _ = tst.Docker.ListApolloContainers(tst.context)
	_, ok = containers[GetTaskId(tst.suffix, tst.Minder.Key, tst.Minder.RetryNum)]
	assert.True(t, ok) // Yes, still here

	// The second sweep with 1 nanosecond threshold
	SweepDeadContainers(tst.context, "n-1", tst.Docker, tst.Stores, 1)

	// Container is now gone
	containers, _ = tst.Docker.ListApolloContainers(tst.context)
	_, ok = containers[GetTaskId(tst.suffix, tst.Minder.Key, tst.Minder.RetryNum)]
	assert.False(t, ok)
}

func TestRetryHandling(t *testing.T) {
	t.Parallel()
	tst := NewTestContext(2, 1)

	tst.Minder.DoTransitions()
	tst.Minder.DoTransitions() // Idempotent
	fullCycleTask := getSubtask(tst)

	// Task must be restarted with an empty node and an increased retry count
	assert.True(t, models.SubtaskStateEnumWaiting == fullCycleTask.Status)
	assert.Nil(t, fullCycleTask.CurrentAssignment)
	assert.Equal(t, int64(0), fullCycleTask.PriorAssignments["0"].ExitCode)
	assert.True(t, 1 == fullCycleTask.RetryNum)
}
