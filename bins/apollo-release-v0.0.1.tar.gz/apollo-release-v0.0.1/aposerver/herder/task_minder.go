package herder

import (
	"apollo/aposerver/docker"
	"apollo/data"
	"apollo/proto/gen/models"
	. "apollo/utils"
	"context"
	"fmt"
	"github.com/docker/docker/api/types"
	"github.com/sirupsen/logrus"
	"strings"
	"sync"
	"time"
)

const GpuRuntime = "nvidia"
const MaxPullDuration = 120 * time.Second
const MaxStartDuration = 10 * time.Second
const MaxConnLossDuration = 30 * time.Second

var TaskObsoletedError = fmt.Errorf("task was obsoleted")
var TaskRescheduledError = fmt.Errorf("task was rescheduled")
var NonzeroExitCodeError = fmt.Errorf("nonzero exit code")

type TaskMinder struct {
	Ctx          context.Context
	Key          data.SubtaskKey
	RetryNum     int64
	Docker	     docker.ConnectorFacet
	SiteSuffix   string

	stores       data.Stores
	tokenManager *data.TokenManager
	serverCert   string

// Max durations
	MaxPullDuration time.Duration
}

func NewTaskMinder(parentCtx context.Context, siteSuffix string,
	key data.SubtaskKeyWithRetry, docker docker.ConnectorFacet,
	tokenManager *data.TokenManager, serverCert string, stores data.Stores) TaskMinderFacet {

	ctx := DeriveNewLoggerContext(parentCtx)
	AddLoggerFields(ctx, logrus.Fields{"Subtask": key.SKey.String(), "RN": key.RetryNum})

	//TODO: add task-related fields
	return &TaskMinder{
		Key:          key.SKey,
		RetryNum:     key.RetryNum,
		Docker:       docker,
		Ctx:          ctx,
		SiteSuffix:   siteSuffix,
		tokenManager: tokenManager,
		stores:       stores,
		serverCert:   serverCert,

		MaxPullDuration: MaxPullDuration,
	}
}

// Do the subtask state transitions, possibly resuming from a saved state
func (tm *TaskMinder) DoTransitions() {
	defer func() {
		subtask := tm.stores.TS.GetSubtask(tm.Key, nil, data.LockModeNone)
		PanicIf(subtask.CurrentAssignment != nil &&
			subtask.RetryNum == tm.RetryNum, "Exiting TaskMinder with the node still attached")
	}()

	outer: for ;; {
		task := tm.stores.TS.GetTask(tm.Key.ParentKey, nil, data.LockModeNone)
		subtask := tm.stores.TS.GetSubtask(tm.Key, nil, data.LockModeNone)

		if task == nil || subtask == nil || subtask.RetryNum != tm.RetryNum {
			CL(tm.Ctx).Warnf("Task has been obsoleted even before transitions")
			break outer
		}

		var err error

		switch subtask.Status {
		case models.SubtaskStateEnumWaiting:
			err = fmt.Errorf("subtastk in unexpected waiting state: %s", subtask.Key)
		case "", models.SubtaskStateEnumDispatched, models.SubtaskStateEnumPulling:
			patch := tm.makeEnvPatch(task)
			runtime := tm.getRuntimeForTask(task)
			err = tm.doPullState(&task.TaskStruct, runtime, patch)
		case models.SubtaskStateEnumCreated:
			cntId := subtask.CurrentAssignment.ContainerID
			PanicIf(cntId == "", "We should have a container ID")
			err = tm.doStartState(cntId)
		case models.SubtaskStateEnumStarted:
			cntId := subtask.CurrentAssignment.ContainerID
			PanicIf(cntId == "", "We should have a container ID")
			proc := sync.WaitGroup{}
			proc.Add(1)
			done := make(chan bool, 1)
			go func(){
				defer proc.Done()
				tm.doStatsLoop(cntId, done)
			}()
			err = tm.doWaitState(cntId)
			done <- true
			proc.Wait()
			// If a task is exited with an error code - just bail out
		case models.SubtaskStateEnumDone, models.SubtaskStateEnumFailed:
			break outer
		}

		if err == TaskRescheduledError {
			break outer
		}
		if err != nil {
			tm.ProcessTaskRunError(err)
			break outer
		}
	}
}

func (tm *TaskMinder) makeEnvPatch(ts *data.StoredTask) map[string]string {
	res := make(map[string]string)

	if tm.tokenManager != nil {
		// Make a task Apollo token
		token := data.AuthToken{
			Expires:     data.NeverExpires,
			Type:        data.TaskToken,
			EntityKey:   ts.Key,
			RequestedBy: ts.SubmittedBy,
			RequestedOn: FromTime(time.Now()),
		}
		encryptedToken := tm.tokenManager.EncryptToken(token)

		// Make Apollo connection string
		connString := docker.ApolloPath + "/apollo-socket#" +
			encryptedToken + "#" + tm.serverCert

		res["APOLLO_CONNECTION"] = connString
	}

	res["TASK_ID"] = ts.Key
	res["SUBTASK_ID"] = tm.Key.String()
	res["SUBMITTED_BY"] = ts.SubmittedBy

	return res
}

// Do a three-step-dance to to lock the node and task for update, when you only
// have a task's ID
func (tm *TaskMinder) lockTaskAndNode(subtaskKey data.SubtaskKey, retryNum int64,
	sess *data.Session) (*data.StoredNode, *data.StoredTask, *data.Subtask) {

	subtask := tm.stores.TS.GetSubtask(subtaskKey, nil, data.LockModeNone)

	if subtask == nil || subtask.CurrentAssignment == nil ||
		subtask.CurrentAssignment.AssignedNode == "" || subtask.RetryNum != retryNum {

		return nil, nil, nil
	}

	curNodeKey := subtask.CurrentAssignment.AssignedNode
	node := tm.stores.NS.GetNode(curNodeKey, sess, data.LockModeFull)
	task := tm.stores.TS.GetTask(subtaskKey.ParentKey, sess, data.LockModeRead)
	subtask = tm.stores.TS.GetSubtask(subtaskKey, sess, data.LockModeFull)

	return node, task, subtask
}

// Mark the task as errored out and exit
func (tm *TaskMinder) ProcessTaskRunError(err error) {
	sess := tm.stores.LS.Session(tm.Ctx)
	defer sess.UnlockAll()

	//Need to lock the node to update the node indexes
	_, task, loaded := tm.lockTaskAndNode(tm.Key, tm.RetryNum, sess)

	if err != TaskObsoletedError {
		CL(tm.Ctx).Warnf("Failed to do task state transitions: %+v", err)
	}

	if task == nil || loaded == nil || loaded.RetryNum != tm.RetryNum {
		CL(tm.Ctx).Warn("Task completion raced with task assignment")
		return
	}

	updated := *loaded

	if tm.CanRetrySubtask(task, loaded) {
		// We can try once more!
		tm.rescheduleTask(&updated)
	} else {
		CL(tm.Ctx).Infof("Retries are exhausted, failing the subtask")

		updated.CurrentAssignment.Exited = true
		updated.CurrentAssignment.ExitError = err.Error()
		updated.CurrentAssignment.ExitTimestamp = FromTime(time.Now())

		updated.PushCurrentAssignmentToHistory()
		updated.CurrentAssignment = nil

		updated.StatusChangeTime = FromTime(time.Now())
		updated.Status = models.SubtaskStateEnumFailed
		// Kick the scheduler
		sess.AddNotify(data.NotifySubtaskFinished, tm.Key.String())
	}

	tm.stores.TS.UpdateSubtask(&updated, sess)

	return
}

func (tm *TaskMinder) rescheduleTask(updated *data.Subtask) {
	CL(tm.Ctx).Infof("Task retry is allowed, doing it")

	updated.PushCurrentAssignmentToHistory()
	updated.CurrentAssignment = nil

	updated.Status = models.SubtaskStateEnumWaiting
	updated.StatusChangeTime = FromTime(time.Now())

	updated.RetryNum++
}

func (tm *TaskMinder) ProcessTaskCompletion(exitCode int64) error {
	sess := tm.stores.LS.Session(tm.Ctx)
	defer sess.UnlockAll()

	//Need to lock the node to clear the assignment
	_, task, loaded := tm.lockTaskAndNode(tm.Key, tm.RetryNum, sess)

	if task == nil || loaded == nil || loaded.RetryNum != tm.RetryNum {
		CL(tm.Ctx).Warn("Task completion raced with task assignment")
		return TaskObsoletedError
	}

	updated := *loaded

	//TODO: handle OutOfMemory correctly - retry for displaced tasks and
	//fail for tasks over the allotted limit.
	if exitCode == 0 || !tm.CanRetrySubtask(task, loaded) {
		updated.CurrentAssignment.Exited = true
		updated.CurrentAssignment.ExitCode = exitCode
		updated.CurrentAssignment.ExitTimestamp = updated.StatusChangeTime

		updated.StatusChangeTime = FromTime(time.Now())
		if exitCode != 0 {
			updated.Status = models.SubtaskStateEnumFailed
			updated.CurrentAssignment.ExitError = NonzeroExitCodeError.Error()
		} else {
			updated.Status = models.SubtaskStateEnumDone
		}
		updated.PushCurrentAssignmentToHistory()
		updated.CurrentAssignment = nil
		CL(tm.Ctx).Infof("Subtask is finished with exit code: %d", exitCode)

		// Kick the scheduler
		sess.AddNotify(data.NotifySubtaskFinished, tm.Key.String())
		tm.stores.TS.UpdateSubtask(&updated, sess)
		return nil
	} else {
		CL(tm.Ctx).Infof("Subtask is failed with exit code: %d", exitCode)

		tm.rescheduleTask(&updated)
		tm.stores.TS.UpdateSubtask(&updated, sess)
		return TaskRescheduledError
	}
}

func (tm *TaskMinder) CanRetrySubtask(task *data.StoredTask, st *data.Subtask) bool {
	return st.RetryNum + 1 < task.MaxTries && !data.IsTaskFinished(task)
}

func (tm *TaskMinder) KillRunningTask() {
	// This is a fire-and-forget operation, as it's inherently
	// racy. Additionally, the reconciler thread will clean up all the
	// zombie tasks eventually anyway.
	CL(tm.Ctx).Infof("Cleaning up the task's container")

	//noinspection GoUnhandledErrorResult
	cnt, err := tm.Docker.KillContainerByName(tm.Ctx,
		GetTaskId(tm.SiteSuffix, tm.Key, tm.RetryNum))
	if err != nil && cnt == "" {
		return
	}
}

// A simple retry policy, for the zeroth iteration there's no delay
// after that it grows exponentially up to 16 seconds
func (tm *TaskMinder) DelayChan(iter int) <-chan time.Time {
	if iter <= 0 {
		var delayBi = make(chan time.Time, 1)
		delayBi <- time.Now()
		return delayBi
	}
	var seconds = 1 << uint64(iter-1)
	if seconds > 16 {
		seconds = 16
	}
	return time.After(time.Duration(seconds) * time.Second)
}

func (tm *TaskMinder) doPullState(ts *models.TaskStruct, runtime string,
	envPatch map[string]string) error {

	CL(tm.Ctx).Infof("Creating container for task: '%s'", tm.Key.String())

	deadline, _ := context.WithDeadline(tm.Ctx, time.Now().Add(tm.MaxPullDuration))
	for i:=0;;i++ {
		select {
		case <-deadline.Done():
			return deadline.Err()
		case <-tm.DelayChan(i):
		}

		containerId, err := tm.Docker.CreateUserTask(deadline, ts, runtime,
			GetTaskId(tm.SiteSuffix, tm.Key, tm.RetryNum), envPatch,
			func(ps docker.PullState) {
				tm.postPullProgress(deadline, tm.Key, tm.RetryNum, ps)
			})

		if err == nil {
			err = tm.tryUpdateTask(deadline, tm.Key, tm.RetryNum,
				func(subtask *data.Subtask) (*data.Subtask, error) {
					updated := *subtask
					updated.CurrentAssignment.ContainerID = containerId
					updated.Status = models.SubtaskStateEnumCreated
					updated.StatusChangeTime = FromTime(time.Now())
					return &updated, nil
				})
			if err != nil {
				// We have started the container but were not able to update it
				// in the database. We might leak it in this case but eventually it
				// will be killed in the reconciler thread.
				CL(deadline).Warnf("May be leaking a started container: %s", containerId)
				// Just do a best-effort cleanup
				tm.Docker.CleanupContainer(deadline, containerId)
			}
			return err
		}

		if err == docker.DuplicateContainerError {
			CL(deadline).Warnf("There's already a container with this name present")
			// Try to recover from a duplicate container error
			// First, find the container state and ID.
			var container types.Container
			container, err = tm.Docker.FindContainerByName(deadline,
				GetTaskId(tm.SiteSuffix, tm.Key, tm.RetryNum))
			if err == nil {
				CL(deadline).Infof("Existing container ID is %s", CutStringTo(container.ID, 20))
				return tm.recoverContainer(deadline, container)
			} else {
				// Allow it to fall through for a retry loop cycle
			}
		}

		if err == context.Canceled || err == context.DeadlineExceeded ||
			docker.IsPermanentDockerFailure(err) {
			return err
		}

		// Try the evasive action - retry the Docker operation until the
		// deadline expires.
		CL(deadline).Warnf("Failed to create the container, retrying Docker operation: %+v", err)
	}
}

func (tm *TaskMinder) recoverContainer(ctx context.Context, cnt types.Container) error {
	return tm.tryUpdateTask(ctx, tm.Key, tm.RetryNum,
		func(subtask *data.Subtask) (*data.Subtask, error) {
			updated := *subtask
			updated.CurrentAssignment.ContainerID = cnt.ID
			updated.StatusChangeTime = FromTime(time.Now())

			switch cnt.State {
			case "created":
				updated.Status = models.SubtaskStateEnumCreated
			case "restarting", "running", "paused":
				updated.Status = models.SubtaskStateEnumStarted
			case "exited", "dead":
				// Yes, still SubtaskStateEnumStarted - we need to get the
				// container's result and the best way is to call "wait" on it.
				updated.Status = models.SubtaskStateEnumStarted
			default:
				return nil, fmt.Errorf(
					"unknown container state %s for %s", cnt.State, CutStringTo(cnt.ID, 20))
			}
			return &updated, nil
		})
}

func (tm *TaskMinder) doStartState(containerId string) error {
	CL(tm.Ctx).Infof("Starting container '%s'", CutStringTo(containerId, 20))

	deadline, _ := context.WithDeadline(tm.Ctx, time.Now().Add(MaxStartDuration))
	for i:=0;;i++ {
		select {
		case <-deadline.Done():
			return deadline.Err()
		case <-tm.DelayChan(i):
		}

		// The container is created in the paused state, so start it now.
		err := tm.Docker.StartUserTask(tm.Ctx, containerId)
		if err == nil {
			err = tm.tryUpdateTask(deadline, tm.Key, tm.RetryNum,
				func(subtask *data.Subtask) (*data.Subtask, error) {
					updated := *subtask
					updated.Status = models.SubtaskStateEnumStarted
					updated.StatusChangeTime = FromTime(time.Now())
					return &updated, nil
				})
			if err != nil {
				// Just do a best-effort cleanup
				tm.KillRunningTask()
			}
			return err
		}

		// Houston, we have an error.
		if err == context.Canceled {
			return err
		}
		// Try the evasive action - retry the Docker operation until the
		// deadline expires.
		CL(deadline).Warnf("Failed to start the task, retrying. Err: %+v", err)
	}
}

func (tm *TaskMinder) doWaitState(containerId string) error {
	CL(tm.Ctx).Infof("Waiting for the container '%s' to stop", CutStringTo(containerId, 20))

	deadline, _ := context.WithDeadline(tm.Ctx, time.Now().Add(MaxConnLossDuration))
	for i:=0;; {
		select {
		case <-deadline.Done():
			return deadline.Err()
		case <-tm.DelayChan(i):
		}

		// Check if the task has been obsoleted. TODO: also add cancellation handling here
		task := tm.stores.TS.GetTask(tm.Key.ParentKey, nil, data.LockModeNone)
		st := tm.stores.TS.GetSubtask(tm.Key, nil, data.LockModeNone)
		if st == nil || st.RetryNum != tm.RetryNum || data.IsTaskFinished(task) {
			// Stop the container and error out
			tm.KillRunningTask()
			return TaskObsoletedError
		}

		// Run with a short deadline to be able to react to connectivity
		// issues that the regular TCP heartbeat will take too long to detect
		reqDeadline, _ := context.WithDeadline(deadline, time.Now().Add(5*time.Second))
		exit, err := tm.Docker.WaitForContainer(reqDeadline, containerId)

		if err == nil {
			err = tm.ProcessTaskCompletion(exit)
			return err
		}

		// TODO: add handling to the Docker call to avoid string matching
		if strings.Contains(err.Error(), "No such container:") {
			CL(deadline).Warnf("Container has disappeared unexpectedly: %+v", containerId)
			return err
		}

		if err == context.DeadlineExceeded {
			// Everything is fine, just recharge the main deadline timer and continue
			deadline, _ = context.WithDeadline(tm.Ctx, time.Now().Add(MaxConnLossDuration))
			i = 0 // Clear the retry count
			continue
		} else {
			i++ // Increment the number of failures for the exponential backoff
		}

		// Try the evasive action - retry the Docker operation until the
		// connection loss deadline expires.
		CL(deadline).Warnf("Error while waiting for the task to complete: %+v", err)
	}
}

func (tm *TaskMinder) doStatsLoop(containerId string, done <- chan bool) {
	ticker := time.NewTicker(1 * time.Second)
	defer ticker.Stop()

	var firstTime = make(chan bool, 1)
	firstTime <- true

	var i = 1
	var lastStats *docker.DockerStats

	CL(tm.Ctx).Infof("Starting the stats update loop")
	outer: for ;; {
		select {
		case <-tm.Ctx.Done():
			break outer
		case <-done:
			break outer
		case <-tm.DelayChan(i):
		case <-firstTime:
		}

		stats, err := tm.doGetTaskStats(containerId, lastStats)
		if err != nil {
			CL(tm.Ctx).Infof("Failed to update the task stats: %+v", err)
			i++
			continue
		}
		i = 1
		if stats == nil {
			break
		}
		if lastStats != nil {
			taskStats, err := docker.ComputeStats(*lastStats, *stats)
			if err != nil {
				CL(tm.Ctx).Infof("Failed to compute the task stats: %+v", err)
				continue
			}
			err = tm.tryUpdateTask(tm.Ctx, tm.Key,
				tm.RetryNum, func(subtask *data.Subtask) (*data.Subtask, error) {
					updated := *subtask
					if subtask.Status != models.SubtaskStateEnumStarted {
						// This can happen if the last update has arrived just after
						// the task has finished.
						return nil, TaskObsoletedError
					}
					updated.PerfStats.CurValues = taskStats
					return &updated, nil
				})
			if err == TaskObsoletedError {
				break
			}
		}

		if stats != nil {
			lastStats = stats
		}
	}

	CL(tm.Ctx).Infof("Finished the stats update loop")
}

func (tm *TaskMinder) doGetTaskStats(containerId string,
	lastDockerStats *docker.DockerStats) (*docker.DockerStats, error) {

	curDockerStats, err := tm.Docker.GetTaskStats(tm.Ctx, containerId)
	if err != nil {
		if strings.Index(err.Error(), "Error response from daemon: No such container") == 0 {
			return nil, nil
		}
		CL(tm.Ctx).Warnf("Failed to get container stats: %s", err.Error())
		return nil, err
	}
	if !docker.IsFullStats(curDockerStats) {
		return nil, nil
	}

	return &curDockerStats, nil
}

func (tm *TaskMinder) postPullProgress(context context.Context,
	key data.SubtaskKey, retryNum int64, state docker.PullState) {

	_ = tm.tryUpdateTask(context, key, retryNum,
		func(subtask *data.Subtask) (*data.Subtask, error) {
			updated := *subtask
			updated.PullState = models.DockerPullState{
				BytesToPull: state.BytesToPull,
				BytesPulled: state.BytesPulled,
			}
			return &updated, nil
		})
}

// Update the task state from a background process, this might race with other
// task updates so we do optimistic locking based on the retry number of the
// subtask.
func (tm *TaskMinder) tryUpdateTask(context context.Context,
	key data.SubtaskKey, retryNum int64,
	updater func(*data.Subtask) (*data.Subtask, error)) error {

	sess := tm.stores.LS.Session(context)
	defer sess.UnlockAll()

	task := tm.stores.TS.GetTask(key.ParentKey, sess, data.LockModeNone)
	loaded := tm.stores.TS.GetSubtask(key, sess, data.LockModeFull)

	if task == nil || loaded == nil || loaded.RetryNum != retryNum || data.IsTaskFinished(task) {
		return TaskObsoletedError
	}

	updated, err := updater(loaded)
	if err != nil {
		return err
	}
	if updated == nil {
		return nil // Nothing to do
	}

	if updated.Status != loaded.Status {
		CL(context).Infof("Changing container status from '%s' to '%s'",
			loaded.Status, updated.Status)
	}

	tm.stores.TS.UpdateSubtask(updated, sess)
	return nil
}

func (tm *TaskMinder) getRuntimeForTask(task *data.StoredTask) string {
	queue := tm.stores.QS.GetQueue(task.Queue, nil, data.LockModeNone)
	if queue == nil || !queue.GpuRuntime {
		return ""
	}
	return GpuRuntime
}

func GetTaskId(siteSuffix string, key data.SubtaskKey, retryNum int64) string {
	// TODO: add site-local prefix here
	return fmt.Sprintf("apo%s-%s_%d", siteSuffix, key.String(), retryNum)
}
