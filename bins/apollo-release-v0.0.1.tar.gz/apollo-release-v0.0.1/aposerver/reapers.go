package aposerver

import (
	"apollo/proto/gen/models"
	context2 "context"
	"github.com/sirupsen/logrus"
	"time"
)

var TaskInterval = 1000 * time.Second

func RunBackgroundTasks(ctx *ServerContext) chan bool {
	var done = make(chan bool)
	go func() {
		logrus.Infof("Starting the background reaper thread")
		ticker := time.NewTicker(TaskInterval)
		defer ticker.Stop()

		for {
			select {
			case <-ticker.C:
				logrus.Info("Running reapers")
				DoRunBackgroundTasks(ctx)
			case <-done:
				logrus.Info("Stopping the reaper thread")
				break
			}
		}
	}()

	return done
}

func DoRunBackgroundTasks(context *ServerContext) {
	session := context.Locks.Session(context2.Background())

	UpdateEcrQueues(context.AwsConfig, context.QueueStore, session)

	// Cleanup old tasks, nodes and queues - use a variation of Dijkstra's
	// tri-color GC algorithm for it to prevent concurrent issues.

	tasks := context.TaskStore.ListTasks(nil, false, nil)
	for _, t := range tasks {
		status := t.Task.OverallStatus
		if status != models.TaskStateEnumCreating && status != models.TaskStateEnumFailed &&
			status != models.TaskStateEnumSucceeded &&  status != models.TaskStateEnumZombie {
			continue
		}
		if status == models.TaskStateEnumZombie {
			// Check if there are any reverse deps for this task, if there are
			// no new dependencies then it's safe to delete the task.
			continue
		}
		// Check task's age and mark it for deletion if it's too old. This
		// corresponds to Dijkstra's initial marking stage.
	}

}
