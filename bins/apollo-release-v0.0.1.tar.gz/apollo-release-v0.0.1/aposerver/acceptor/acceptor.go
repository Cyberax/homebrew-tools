package acceptor

import (
	"apollo/aposerver/docker"
	. "apollo/utils"
	"context"
	"crypto/tls"
	apierrors "github.com/go-openapi/errors"
	"github.com/go-openapi/runtime"
	"github.com/sirupsen/logrus"
	"net"
	"net/http"
	"os"
	"os/signal"
	"sync"
	"sync/atomic"
	"syscall"
	"time"

	"apollo/proto/gen/restapi/operations"
)

// Server for the apollo API
type Server struct {
	ServerCtx context.Context

	TLSKey string
	TLSCert string

	ListenChan <- chan net.Conn

	api          *operations.ApolloAPI
	handler      http.Handler
	shutdown     chan struct{}
	shuttingDown int32
	interrupted  bool
	interrupt    chan os.Signal
	chanLock     sync.RWMutex
}


// NewServer creates a new api apollo server but does not configure it
func NewServer(ctx context.Context, api *operations.ApolloAPI,
	listenChan <- chan net.Conn, tlsCert string, tlsKey string) *Server {

	serverCtx := DeriveNewLoggerContext(ctx)
	AddLoggerFields(serverCtx, logrus.Fields{"APISERVER": "1"})

	s := &Server {
		ServerCtx: serverCtx,

		api: api,
		handler: api.Serve(func(handler http.Handler) http.Handler{return handler}),
		shutdown: make(chan struct{}),
		interrupt: make(chan os.Signal, 1),

		TLSKey: tlsKey,
		TLSCert: tlsCert,
		ListenChan: listenChan,
	}

	api.ServeError = apierrors.ServeError
	api.JSONConsumer = runtime.JSONConsumer()
	api.JSONProducer = runtime.JSONProducer()
	api.ServerShutdown = func() {}
	return s
}

func (s *Server) makeTlsContext() (*http.Server, error) {
	httpsServer := new(http.Server)
	httpsServer.MaxHeaderBytes = int(65536)
	httpsServer.SetKeepAlivesEnabled(true)
	httpsServer.IdleTimeout = 30 * time.Second

	httpsServer.Handler = s.handler

	// Inspired by https://blog.bracebin.com/achieving-perfect-ssl-labs-score-with-go
	httpsServer.TLSConfig = &tls.Config{
		// Causes servers to use Go's default ciphersuite preferences,
		// which are tuned to avoid attacks. Does nothing on clients.
		PreferServerCipherSuites: true,
		// Only use curves which have assembly implementations
		// https://github.com/golang/go/tree/master/src/crypto/elliptic
		CurvePreferences: []tls.CurveID{tls.CurveP256},
		// Use modern tls mode https://wiki.mozilla.org/Security/Server_Side_TLS#Modern_compatibility
		NextProtos: []string{"http/1.1", "h2"},
		// https://www.owasp.org/index.php/Transport_Layer_Protection_Cheat_Sheet#Rule_-_Only_Support_Strong_Protocols
		MinVersion: tls.VersionTLS12,
		// These ciphersuites support Forward Secrecy: https://en.wikipedia.org/wiki/Forward_secrecy
		CipherSuites: []uint16{
			tls.TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384,
			tls.TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384,
			tls.TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256,
			tls.TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256,
			tls.TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305,
			tls.TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305,
		},
	}

	// build standard config from server options
	certificate, err := tls.X509KeyPair([]byte(s.TLSCert), []byte(s.TLSKey))
	if err != nil {
		return nil, err
	}
	httpsServer.TLSConfig.Certificates = make([]tls.Certificate, 1)
	httpsServer.TLSConfig.Certificates[0] = certificate

	// must have at least one certificate or panics
	httpsServer.TLSConfig.BuildNameToCertificate()

	return httpsServer, nil
}

type ChannelListener struct {
	ListenChan <- chan net.Conn
}

func (c *ChannelListener) Accept() (net.Conn, error) {
	return <-c.ListenChan, nil
}

func (*ChannelListener) Close() error {
	return nil
}

func (*ChannelListener) Addr() net.Addr {
	return docker.SmuxSockAddr{}
}

// Serve the api
func (s *Server) Serve() error {
	wg := new(sync.WaitGroup)
	once := new(sync.Once)
	signalNotify(s.interrupt)
	go handleInterrupt(once, s)

	chanListener := &ChannelListener{ListenChan: s.ListenChan}

	server, err := s.makeTlsContext()
	if err != nil {
		return err
	}

	wg.Add(1)
	go s.handleShutdown(wg, server)

	wg.Add(1)
	CL(s.ServerCtx).Infof("Serving Apollo requests")
	go func(l net.Listener) {
		defer wg.Done()
		if err := server.Serve(l); err != nil && err != http.ErrServerClosed {
			CL(s.ServerCtx).Fatalf("Failed serving Apollo requests: %v", err)
		}
		CL(s.ServerCtx).Infof("Stopped serving Apollo requests")
	}(tls.NewListener(chanListener, server.TLSConfig))

	wg.Wait()
	return nil
}

// Shutdown server and clean up resources
func (s *Server) Shutdown() error {
	if atomic.CompareAndSwapInt32(&s.shuttingDown, 0, 1) {
		close(s.shutdown)
	}
	return nil
}

func (s *Server) handleShutdown(wg *sync.WaitGroup, server *http.Server) {
	// wg.Done must occur last, after s.api.ServerShutdown()
	// (to preserve old behaviour)
	defer wg.Done()

	<-s.shutdown

	ctx, cancel := context.WithTimeout(s.ServerCtx, 15*time.Second)
	defer cancel()

	shutdownChan := make(chan bool)
	go func() {
		var success bool
		defer func() {
			shutdownChan <- success
		}()
		if err := server.Shutdown(ctx); err != nil {
			// Error from closing listeners, or context timeout:
			CL(s.ServerCtx).Infof("HTTP server Shutdown: %v", err)
		} else {
			success = true
		}
	}()

	// Wait until all listeners have successfully shut down before calling ServerShutdown
	success := <-shutdownChan
	if success {
		s.api.ServerShutdown()
	}
}

func handleInterrupt(once *sync.Once, s *Server) {
	once.Do(func() {
		for range s.interrupt {
			if s.interrupted {
				CL(s.ServerCtx).Infof("Server already shutting down")
				continue
			}
			s.interrupted = true
			CL(s.ServerCtx).Infof("Shutting down... ")
			_ = s.Shutdown()
		}
	})
}

func signalNotify(interrupt chan<- os.Signal) {
	signal.Notify(interrupt, syscall.SIGINT, syscall.SIGTERM)
}
