package aposerver

import (
	"apollo/data"
	"apollo/utils"
	"bytes"
	"crypto/tls"
	"crypto/x509"
	"encoding/pem"
	"fmt"
	"github.com/sirupsen/logrus"
	"io"
	"io/ioutil"
	"strings"
)

type HttpTlsManager struct {
	store *data.ConfigStore

	TLSHost string
	TLSPort int

	OurCert string

	TLSData utils.TlsData
}

func NewTlsManager() *HttpTlsManager {
	return &HttpTlsManager{}
}

func (man *HttpTlsManager) probeHost(host string) (string, error) {
	var certs [][]byte
	errObtainedCert := fmt.Errorf("obtained certificate")

	conf := &tls.Config {
		InsecureSkipVerify: true,
		VerifyPeerCertificate: func(rawCerts [][]byte, verifiedChains [][]*x509.Certificate) error {
			certs = rawCerts
			return errObtainedCert
		},
	}

	_, err := tls.Dial("tcp", host, conf)
	if err != errObtainedCert {
		return "", err
	}
	if err == nil {
		panic("Unexpected connection success")
	}

	// Now parse the certificate chain to get the CA text
	certBytes := certs[len(certs)-1]
	var keyOut bytes.Buffer
	err = pem.Encode(io.Writer(&keyOut), &pem.Block{Type: "CERTIFICATE", Bytes: certBytes})
	if err != nil {
		return "", err
	}
	return getCertBody(keyOut.Bytes()), nil
}

func getCertBody(certBytes []byte) string {
	certStr := strings.Replace(string(certBytes), "-----BEGIN CERTIFICATE-----", "", 1)
	certStr = strings.Replace(certStr, "-----END CERTIFICATE-----", "", 1)
	certStr = strings.Replace(certStr, "\n", "", -1)
	return certStr
}

func (man *HttpTlsManager) Init(store *data.ConfigStore, TLSHost string, TLSPort int,
	TLSCert string, TLSKey string, hostToProbe string) error {
	man.TLSHost = TLSHost
	man.TLSPort = TLSPort
	logrus.Info("Setting up TLS infrastructure")

	var err error
	if hostToProbe != "self" {
		logrus.Infof("Probing host: %s for CA certificate", hostToProbe)
		man.OurCert, err = man.probeHost(hostToProbe)
		if err != nil {
			return err
		}
	}

	// If no automatic certificate management is desired, just don't do anything
	if TLSCert != "auto" && TLSKey != "auto" {
		logrus.Info("Using manually configured TLS certificate and key")

		cd, err := ioutil.ReadFile(TLSCert)
		if err != nil {
			return err
		}
		kd, err := ioutil.ReadFile(TLSKey)
		if err != nil {
			return err
		}

		man.TLSData = utils.TlsData{
			KeyData: string(kd),
			CertData: string(cd),
		}

		if hostToProbe == "self" {
			man.OurCert = getCertBody(cd)
		}
		return nil
	}

	var configData = utils.TlsData{}
	err, ok := store.GetConfigByKey("ServerCert", &configData)
	if err != nil {
		return err
	}

	if ok {
		logrus.Info("Using the stored TLS parameters")
		if hostToProbe == "self" {
			man.OurCert = getCertBody([]byte(configData.CertData))
		}
		man.TLSData = configData
		return nil
	}

	logrus.Info("Generating new TLS parameters")
	// New certificate is needed
	certData := utils.MakeCACert()
	man.TLSData = *certData

	err = store.StoreConfig("ServerCert", certData)
	logrus.Info("Saved the generated TLS parameters")
	if err != nil {
		return err
	}

	if hostToProbe == "self" {
		man.OurCert = getCertBody([]byte(certData.CertData))
	}

	return nil
}
