package aposerver

import (
	"apollo/aposerver/provisioner"
	"apollo/data"
	"apollo/proto/gen/models"
	"apollo/proto/gen/restapi/operations/node"
	. "apollo/utils"
	"crypto/tls"
	"fmt"
	. "github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/ec2"
	"github.com/go-openapi/runtime/middleware"
	"net"
	"net/http"
	"net/url"
	"strings"
	"time"
)

type PutUnmanagedNodeProcessor struct {
	sess *data.Session
	store *data.NodeStore
	queueStore *data.QueueStore
	params node.PutUnmanagedNodeParams
	principal data.AuthToken
}

func (l *PutUnmanagedNodeProcessor) Enact() middleware.Responder {
	defer l.sess.UnlockAll()

	queue := l.queueStore.GetQueue(l.params.Node.Queue, l.sess, data.LockModeFull)
	if queue == nil {
		return SendErrorSC(l.sess.Ctx(), http.StatusBadRequest,
			fmt.Sprintf("queue '%s' was not found", l.params.Node.Queue))
	}

	// Generate node ID
	nodeId, err := l.store.GenerateId()
	if err != nil {
		return SendError(l.sess.Ctx(), err)
	}

	now := FromTime(time.Now())
	newNode := data.StoredNode {
		Key:       nodeId,
		Managed:   false,
		State:     models.NodeStateEnumOffline,
		CreatedOn: now,
		LastTransitionTime: now,
		DockerAddress: l.params.Node.DockerAddress,
		Queue: l.params.Node.Queue,
	}

	// Create the CA cert for this node's Docker
	cert := MakeCACert()
	newNode.CACert = cert.CertData
	newNode.CAKey = cert.KeyData

	err = l.store.StoreNode(&newNode, l.sess)
	if err != nil {
		return SendError(l.sess.Ctx(), err)
	}

	//TODO: link into the queue indexes
	return &node.PutUnmanagedNodeOK{
		Payload: &node.PutUnmanagedNodeOKBody {
			NodeID: newNode.Key,
		},
	}
}


type PutEc2NodeProcessor struct {
	sess       *data.Session
	awsConn    Config
	store      *data.NodeStore
	queueStore *data.QueueStore
	params     node.PutEc2NodeParams
	principal  data.AuthToken
}

func (l *PutEc2NodeProcessor) Enact() middleware.Responder {
	queue := l.queueStore.GetQueue(l.params.Node.Queue, l.sess, data.LockModeFull)
	if queue == nil {
		return SendErrorSC(l.sess.Ctx(), http.StatusBadRequest,
			fmt.Sprintf("queue '%s' was not found", l.params.Node.Queue))
	}

	// Inspect the node
	ec2Conn := ec2.New(l.awsConn)
	var nodeId string
	var err error

	if strings.Index(l.params.Node.InstanceID, "sfr-") != 0 {
		instanceId := l.params.Node.InstanceID
		nodeId, err = l.enrollNode(instanceId)
	} else {
		// Describe the fleet and enroll its nodes
		output, err := ec2Conn.DescribeSpotFleetInstancesRequest(
			&ec2.DescribeSpotFleetInstancesInput{
				SpotFleetRequestId: String(l.params.Node.InstanceID),
				MaxResults:         Int64(1000),
		}).Send()
		if err != nil {
			return SendError(l.sess.Ctx(), err)
		}

		resChan := make(chan string, len(output.ActiveInstances))
		errChan := make(chan string, len(output.ActiveInstances))

		for _, ai := range output.ActiveInstances {
			go func(id string) {
				curNodeId, err := l.enrollNode(id)
				if err != nil {
					resChan <- err.Error()
				} else {
					resChan <- curNodeId
				}
			}(StringValue(ai.InstanceId))
		}

		for range output.ActiveInstances {
			select {
			case nodeId = <-resChan:
			case errStr := <-errChan:
				return SendErrorS(l.sess.Ctx(), errStr)
			}
		}
	}

	if err != nil {
		return SendError(l.sess.Ctx(), err)
	}

	//TODO: link into the queue indexes
	return &node.PutEc2NodeOK{
		Payload: &node.PutEc2NodeOKBody{
			NodeID: nodeId,
		},
	}
}

func (l *PutEc2NodeProcessor) enrollNode(instanceId string) (string, error) {
	ec2Conn := ec2.New(l.awsConn)

	output, err := ec2Conn.DescribeInstancesRequest(&ec2.DescribeInstancesInput{
		InstanceIds: []string{instanceId},
	}).Send()
	if err != nil {
		return "", err
	}
	if len(output.Reservations) != 1 {
		return "", fmt.Errorf("failed to find the instance")
	}

	instance := output.Reservations[0].Instances[0]
	if instance.State == nil || instance.State.Name != ec2.InstanceStateNameRunning {
		return "", fmt.Errorf("instance is not in the 'running' state")
	}

	var addr string
	if StringValue(instance.PublicIpAddress) != "" {
		addr = "tcp://" + *instance.PublicIpAddress + ":2376"
	} else if StringValue(instance.PrivateIpAddress) != "" {
		addr = "tcp://" + *instance.PrivateIpAddress + ":2376"
	} else {
		return "", fmt.Errorf("no private or public IP was found")
	}

	// Create the CA cert for this node's Docker
	caCert := MakeCACert()
	caTlsCert, err := tls.X509KeyPair([]byte(caCert.CertData), []byte(caCert.KeyData))
	PanicIfError(err)

	// Create node cert
	nodePrivateKey, nodeCSR := MakeKeyAndCSR()
	nodeCert, err := SignCertificateRequest(nodeCSR, caTlsCert,
		[]string{StringValue(instance.PrivateDnsName), StringValue(instance.PublicDnsName)},
		[]net.IP{net.ParseIP(StringValue(instance.PrivateIpAddress)),
			net.ParseIP(StringValue(instance.PublicIpAddress))})

	// Provision it
	CL(l.sess.Ctx()).Infof("Provisioning docker on %s", instanceId)

	p := provisioner.NewAmazonLinuxProvisioner(l.sess.Ctx(), l.awsConn)
	err = p.InjectDockerCA(instanceId, TlsData{KeyData: string(nodePrivateKey),
		CertData: string(nodeCert)}, caCert.CertData)
	if err != nil {
		return "", err
	}

	CL(l.sess.Ctx()).Infof("Succeeded provisioning docker on %s", instanceId)

	// Generate node ID
	nodeId, err := l.store.GenerateId()
	if err != nil {
		return "", err
	}

	now := FromTime(time.Now())
	newNode := data.StoredNode {
		Key:       nodeId,
		Managed:   false,
		State:     models.NodeStateEnumOffline,
		CreatedOn: now,
		LastTransitionTime: now,
		DockerAddress: addr,
		Queue: l.params.Node.Queue,
		CloudID: instanceId,
		CACert: caCert.CertData,
		CAKey: caCert.KeyData,
	}

	err = l.store.StoreNode(&newNode, l.sess)
	if err != nil {
		return "", err
	}
	return nodeId, nil
}


type ListNodesProcessor struct {
	sess *data.Session
	store *data.NodeStore
	params node.GetNodeListParams
}

func (l *ListNodesProcessor) Enact() middleware.Responder {
	nodes := l.store.ListNodes(l.params.NodeID, func(node *data.StoredNode) bool {
		if l.params.QueueName != nil && node.Queue != *l.params.QueueName {
			return false
		}
		return true
	}, l.sess)

	// Format Nodes
	var resArr []*node.GetNodeListOKBodyItems0
	for _, nd := range nodes {
		subtasks := l.store.GetNodeSubtasks(nd.Key)
		var assignedSubtasks []string
		for _, s := range subtasks {
			assignedSubtasks = append(assignedSubtasks, s.SKey.String())
		}

		resArr = append(resArr, &node.GetNodeListOKBodyItems0{
			NodeID:             nd.Key,
			QueueName:          nd.Queue,
			CloudInstanceID:    nd.CloudID,
			LastTransitionTime: nd.LastTransitionTime.ToTime().Unix(),
			ManagedNode:        nd.Managed,
			NodeState:          nd.State,
			NodeInfo:           nd.Info,
			DockerAddress:      nd.DockerAddress,
			AssignedSubtasks: 	assignedSubtasks,
		})
	}

	return &node.GetNodeListOK{Payload: resArr}
}


type GetNodeCertProcessor struct {
	sess *data.Session
	store *data.NodeStore
	params node.PostCertificateParams
}

func (l *GetNodeCertProcessor) Enact() middleware.Responder {
	l.sess.L().Infof("Invoking GetNodeCertProcessor")

	nd := l.store.GetNode(l.params.NodeID, l.sess, data.LockModeNone)
	if nd == nil {
		return SendErrorS(l.sess.Ctx(), "Failed to find node " + l.params.NodeID)
	}

	// Load the CA and sign the request
	keyPair, err := tls.X509KeyPair([]byte(nd.CACert), []byte(nd.CAKey))
	if err != nil {
		return SendErrorS(l.sess.Ctx(), "Failed to load the CA: " + err.Error())
	}

	// Get the Docker address for the generated certificate
	parsedUrl, err := url.Parse(nd.DockerAddress)
	if err != nil {
		return SendErrorS(l.sess.Ctx(), "Failed to parse Docker address: " + err.Error())
	}
	var dnsNames []string
	var ips []net.IP
	ip := net.ParseIP(parsedUrl.Hostname())
	if ip != nil {
		ips = []net.IP{ip}
		l.sess.L().Infof("Making a certificate for IP: %s", ip.String())
	} else {
		dnsNames = []string{parsedUrl.Hostname()}
		l.sess.L().Infof("Making a certificate for host: %s", parsedUrl.Host)
	}

	// Sign the request
	signed, err := SignCertificateRequest(
		[]byte(l.params.SigningRequest), keyPair, dnsNames, ips)
	if err != nil {
		return SendErrorS(l.sess.Ctx(), "Failed to sign the request: " + err.Error())
	}

	return node.NewPostCertificateOK().WithPayload(&node.PostCertificateOKBody{
		CaCert: nd.CACert,
		NodeCert: string(signed),
	})
}


type GetNodeDockerConnProcessor struct {
	sess *data.Session
	store *data.NodeStore
	params node.GetDockerConnectionParams
}

func (l *GetNodeDockerConnProcessor) Enact() middleware.Responder {
	l.sess.L().Infof("Invoking GetNodeDockerConnProcessor")

	nd := l.store.GetNode(l.params.NodeID, l.sess, data.LockModeNone)
	if nd == nil {
		return SendErrorS(l.sess.Ctx(), "Failed to find node " + l.params.NodeID)
	}

	// Load the CA and sign the request
	caKeyPair, err := tls.X509KeyPair([]byte(nd.CACert), []byte(nd.CAKey))
	if err != nil {
		return SendErrorS(l.sess.Ctx(), "Failed to load the CA: " + err.Error())
	}

	// Create a client certificate and sign it with node's CA
	key, csr := MakeKeyAndCSR()
	signedCert, err := SignCertificateRequest(csr, caKeyPair, []string{}, []net.IP{})
	PanicIf(err != nil, "Failed to sign CSR")

	return node.NewGetDockerConnectionOK().WithPayload(&node.GetDockerConnectionOKBody{
		DockerAddress: nd.DockerAddress,
		DockerCaCert: nd.CACert,
		DockerCert: string(signedCert),
		DockerClientKey: string(key),
	})
}
