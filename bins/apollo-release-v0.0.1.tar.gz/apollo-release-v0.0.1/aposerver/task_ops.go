package aposerver

import (
	"apollo/aposerver/scheduler"
	"apollo/data"
	"apollo/proto/gen/models"
	"apollo/proto/gen/restapi/operations/task"
	. "apollo/utils"
	"fmt"
	"github.com/go-openapi/runtime/middleware"
	"net/http"
	"strconv"
	"time"
)

type TaskSubmitProcessor struct {
	sess *data.Session
	store *data.TaskStore
	queueStore *data.QueueStore
	kvStore data.KVStore
	principal data.AuthToken
	params task.PutTaskParams
}

func (l *TaskSubmitProcessor) Enact() middleware.Responder {
	defer l.sess.UnlockAll()

	val, err := l.kvStore.GetCounter("TaskCounter")
	if err != nil {
		return SendErrorSC(l.sess.Ctx(), http.StatusInternalServerError, err.Error())
	}

	if l.params.Task.StartArrayIndex >= l.params.Task.EndArrayIndex {
		return SendErrorSC(l.sess.Ctx(), http.StatusBadRequest,
			"End index is not bigger than the start index")
	}

	if l.params.Task.ExpectedRAMMb > l.params.Task.MaxRAMMb {
		return SendErrorSC(l.sess.Ctx(), http.StatusBadRequest,
			"Expected RAM is bigger than max RAM")
	}

	// LockTable the queue so it won't go away while this method is running
	st := data.StoredTask {
		TaskStruct: l.params.Task,

		Key: "t-" + strconv.FormatInt(val, 10),
		SubmittedOn: FromTime(time.Now()),
		SubmittedBy: l.principal.RenderEntity(),
	}

	if st.IdempotencyToken == "" {
		st.IdempotencyToken = *GenerateRandIdSized(10)
	}

	if l.params.WillSendFiles {
		st.OverallStatus = models.TaskStateEnumCreating
	} else if len(st.SubtaskDependencies) == 0 && len(st.TaskDependencies) == 0 {
		st.OverallStatus = models.TaskStateEnumScheduled
	} else {
		st.OverallStatus = models.TaskStateEnumWaiting
	}

	queue := l.queueStore.GetQueue(l.params.Task.Queue, l.sess, data.LockModeRead)
	if queue == nil {
		return SendErrorSC(l.sess.Ctx(), http.StatusBadRequest,
			"Task queue is not found: " + l.params.Task.Queue)
	}

	err = l.store.StoreTask(&st, l.sess)
	if err == data.IdempotencyTokenAlreadyExistsError {
		// Get the task by its token
		existing := l.store.GetTaskByIdemToken(
			st.IdempotencyToken, nil, data.LockModeNone)
		if existing == nil {
			return SendErrorSC(l.sess.Ctx(), http.StatusBadRequest, "Task went away")
		}
		return task.NewPutTaskOK().WithPayload(&task.PutTaskOKBody{
			TaskID: existing.Key,
		})
	}

	if err == data.RowAlreadyExistsError {
		return SendErrorSC(l.sess.Ctx(), http.StatusBadRequest,
		"This task already exists. WTF?")
	}

	return task.NewPutTaskOK().WithPayload(&task.PutTaskOKBody{
		TaskID: st.Key,
	})
}


type ListTasksProcessor struct {
	sess *data.Session
	store *data.TaskStore
	params task.GetTaskListParams
}

func (l *ListTasksProcessor) Enact() middleware.Responder {
	tasks := l.store.ListTasks(l.params.ID, true,
		func(task *data.StoredTask, counts data.SubtaskCounts) bool {
		if l.params.Job != nil && task.Job.JobName != *l.params.Job {
			return false
		}
		if l.params.Queue != nil && task.Queue != *l.params.Queue {
			return false
		}
		return true
	})

	// Format tasks
	var resArr []*task.GetTaskListOKBodyItems0
	for _, t := range tasks {
		taskStruct := &(t.Task.TaskStruct)

		if l.params.WithEnv == nil || !*l.params.WithEnv {
			// We need to remove the environment from the task output
			tsCopy := *taskStruct
			tsCopy.TaskEnv = nil
			taskStruct = &tsCopy
		}

		var statusMap = make(map[string][]int64)
		// Group subtasks by status
		for idx, st := range t.Subtasks {
			curStatus := st.Status
			curList, ok := statusMap[string(curStatus)]
			if !ok {
				curList = make([]int64,0)
			}
			statusMap[string(curStatus)]  = append(curList, idx)
		}

		resArr = append(resArr, &task.GetTaskListOKBodyItems0{
			TaskID:     t.Task.Key,
			TaskStruct: *taskStruct,
			SubtasksByStatus: statusMap,
			State: t.Task.OverallStatus,
		})
	}

	return &task.GetTaskListOK{Payload: resArr}
}


type AssignTaskProcessor struct {
	sess       *data.Session
	taskStore  *data.TaskStore
	nodeStore  *data.NodeStore
	queueStore *data.QueueStore
	params     task.PutTaskAssignmentParams
}

// Assign a subtask to a node. Yeehaw.
func (a *AssignTaskProcessor) Enact() middleware.Responder {
	defer a.sess.UnlockAll()

	subtaskKey, fullySpecced, err := data.ParseSubtaskKey(a.params.Subtask)
	if err != nil {
		return SendErrorSCE(a.sess.Ctx(), http.StatusBadRequest, err)
	}

	// Read the subtask without getting a lock to get the current node ID
	subtask := a.taskStore.GetSubtask(subtaskKey, a.sess, data.LockModeNone)
	if subtask == nil {
		return SendErrorSC(a.sess.Ctx(), http.StatusBadRequest, "task not found")
	}
	initialNodeKey := ""
	if subtask.CurrentAssignment != nil {
		initialNodeKey = subtask.CurrentAssignment.AssignedNode
	}

	if initialNodeKey == a.params.Node {
		return SendErrorSC(a.sess.Ctx(), http.StatusBadRequest,
			"task is already assigned to this node")
	}

	// Lock nodes (both the old one and the new one first)
	newNodeVal := a.nodeStore.GetNodeRow(a.params.Node, a.sess)
	curNodeVal := a.nodeStore.GetNodeRow(initialNodeKey, a.sess)
	a.sess.LockItems(data.LockModeRead, newNodeVal.TableRow, curNodeVal.TableRow)
	newNode := newNodeVal.Load()

	if newNode == nil || newNode.State == models.NodeStateEnumDead {
		return SendError(a.sess.Ctx(), fmt.Errorf("can't find a live node %s", a.params.Node))
	}

	t := a.taskStore.GetTask(subtaskKey.ParentKey, a.sess, data.LockModeRead)
	if t == nil {
		return SendErrorSC(a.sess.Ctx(), http.StatusBadRequest, "task not found")
	}

	if !fullySpecced && t.EndArrayIndex - t.StartArrayIndex > 1 {
		return SendErrorSC(a.sess.Ctx(), http.StatusBadRequest,
			"you need to specify the subtask")
	}
	if subtaskKey.Index < t.StartArrayIndex || subtaskKey.Index >= t.EndArrayIndex {
		return SendErrorSC(a.sess.Ctx(), http.StatusBadRequest,
			"subtask index is out of range")
	}

	subtask = a.taskStore.GetSubtask(subtaskKey, a.sess, data.LockModeFull)
	if subtask == nil || subtask.CurrentAssignment.AssignedNode != initialNodeKey {
		return SendErrorSC(a.sess.Ctx(), http.StatusBadRequest,
			"Subtask update was raced: " + subtaskKey.String())
	}

	changed := *subtask

	if subtask.CurrentAssignment != nil {
		// Bump the retry count and push the assignment into history
		changed.PushCurrentAssignmentToHistory()
		changed.RetryNum++
	}

	changed.CurrentAssignment = &models.SubtaskAssignment{
		AssignedNode:   a.params.Node,
		AssignmentTime: FromTime(time.Now()),
	}
	changed.Status = models.SubtaskStateEnumDispatched

	a.taskStore.UpdateSubtask(&changed, a.sess)

	return &task.PutTaskAssignmentOK{}
}

type CancelTaskProcessor struct {
	sess       *data.Session
	taskStore  *data.TaskStore
	params     task.PutTaskCancellationParams
}

func (a *CancelTaskProcessor) Enact() middleware.Responder {
	CL(a.sess.Ctx()).Infof("Canceling task %s", a.params.Task)

	t := a.taskStore.GetTask(a.params.Task, a.sess, data.LockModeFull)
	if t == nil || data.IsTaskFinished(t) {
		return SendErrorSC(a.sess.Ctx(), http.StatusBadRequest,
			"Couldn't find an active task: " + t.Key)
	}

	scheduler.FailTask(a.taskStore, a.params.Task, data.TaskCancelledReason, a.sess)

	return &task.PutTaskAssignmentOK{}
}

type WaitTaskProcessor struct {
	sess       *data.Session
	locker     *data.LockStore
	taskStore  *data.TaskStore
	params     task.GetTaskWaitParams
}

func (a *WaitTaskProcessor) Enact() middleware.Responder {
	CL(a.sess.Ctx()).Infof("Waiting on a task %s", a.params.Task)

	subtaskKey, fullySpecced, err := data.ParseSubtaskKey(a.params.Task)
	if err != nil {
		return SendErrorSCE(a.sess.Ctx(), http.StatusBadRequest, err)
	}

	if !fullySpecced {
		// Wait on a task to finish
		return a.waitTask(subtaskKey.ParentKey)
	} else {
		return a.waitSubtask(subtaskKey)
	}
}

func (a *WaitTaskProcessor) waitSubtask(subtaskKey data.SubtaskKey) middleware.Responder {
	waiter := make(chan string, 1)
	a.locker.Subscribe(data.NotifySubtaskFinished, subtaskKey.String(),
		waiter, false)
	defer a.locker.Unsubscribe(data.NotifySubtaskFinished, subtaskKey.String(), waiter)

	ticker := time.NewTicker(2000 * time.Millisecond)
	defer ticker.Stop()
	for ;; {
		// Poll the subtask
		st := a.taskStore.GetSubtask(subtaskKey, a.sess, data.LockModeNone)
		if st == nil {
			return SendErrorSC(a.sess.Ctx(), http.StatusBadRequest,
				"Couldn't find a subtask: " + subtaskKey.String())
		}
		if st.Status == models.SubtaskStateEnumDone {
			return &task.GetTaskWaitOK{Payload: "0"}
		}
		if st.Status == models.SubtaskStateEnumFailed {
			return &task.GetTaskWaitOK{Payload: "1"}
		}

		select {
		case <-ticker.C:
		case <-waiter:
		case <-a.sess.Ctx().Done():
			return SendError(a.sess.Ctx(), a.sess.Ctx().Err())
		}
	}
}

func (a *WaitTaskProcessor) waitTask(taskKey string) middleware.Responder {
	waiter := make(chan string, 1)
	a.locker.Subscribe(data.NotifyTaskDone, taskKey,
		waiter, false)
	defer a.locker.Unsubscribe(data.NotifyTaskDone, taskKey, waiter)

	ticker := time.NewTicker(2000 * time.Millisecond)
	defer ticker.Stop()
	for ;; {
		// Poll the subtask
		st := a.taskStore.GetTask(taskKey, a.sess, data.LockModeNone)
		if st == nil {
			return SendErrorSC(a.sess.Ctx(), http.StatusBadRequest,
				"Couldn't find a task: " + taskKey)
		}
		if st.OverallStatus == models.TaskStateEnumSucceeded {
			return &task.GetTaskWaitOK{
				Payload: fmt.Sprintf("%d", 0),
			}
		}
		if st.OverallStatus == models.TaskStateEnumFailed {
			return &task.GetTaskWaitOK{
				Payload: fmt.Sprintf("%d", 1),
			}
		}

		select {
		case <-ticker.C:
		case <-waiter:
		case <-a.sess.Ctx().Done():
			return SendError(a.sess.Ctx(), a.sess.Ctx().Err())
		}
	}
}

type ListSubTasksProcessor struct {
	sess *data.Session
	store *data.TaskStore
	params task.GetSubtaskListParams
}

func (l *ListSubTasksProcessor) Enact() middleware.Responder {
	// Format tasks
	var resArr []*task.GetSubtaskListOKBodyItems0

	if l.params.TaskID != nil && *l.params.TaskID != "" {
		tasks := l.store.ListTasks([]string{*l.params.TaskID}, true, nil)
		for _, t := range tasks {
			for _, v := range t.Subtasks {
				resArr = append(resArr, &task.GetSubtaskListOKBodyItems0{
					Key: v.Key,
					RetryNum: v.RetryNum,
					Info: v.SubtaskInfo,
				})
			}
		}
	}

	for _, id := range l.params.ID {
		subtaskKey, _, err := data.ParseSubtaskKey(id)
		if err != nil {
			return SendErrorSC(l.sess.Ctx(), http.StatusBadRequest,
				"Failed to parse subtask id: "+id+", err=" + err.Error())
		}

		v := l.store.GetSubtask(subtaskKey, nil, data.LockModeNone)
		if v != nil {
			resArr = append(resArr, &task.GetSubtaskListOKBodyItems0{
				Key: v.Key,
				RetryNum: v.RetryNum,
				Info: v.SubtaskInfo,
			})
		}
	}

	return &task.GetSubtaskListOK{Payload: resArr}
}

type CompletedDownloadsTaskProcessor struct {
	sess       *data.Session
	taskStore  *data.TaskStore
	params     task.PostTaskLaunchParams
}

func (a *CompletedDownloadsTaskProcessor) Enact() middleware.Responder {
	CL(a.sess.Ctx()).Infof("Marking task as schedulable %s", a.params.TaskID)

	t := a.taskStore.GetTask(a.params.TaskID, a.sess, data.LockModeFull)
	if t == nil || t.OverallStatus != models.TaskStateEnumCreating {
		return SendErrorSC(a.sess.Ctx(), http.StatusBadRequest,
			"Couldn't find a task in the uploading status: " + t.Key)
	}

	// Mark the task as scheduled
	updated := *t
	updated.OverallStatus = models.TaskStateEnumScheduled
	a.taskStore.UpdateTask(&updated, a.sess)

	return &task.PostTaskLaunchOK{}
}
