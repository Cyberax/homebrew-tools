package apoclient

import (
	"apollo/proto/gen/models"
	"apollo/proto/gen/restcli"
	"apollo/proto/gen/restcli/queue"
	. "apollo/utils"
	"fmt"
	"github.com/olekukonko/tablewriter"
	"github.com/spf13/cobra"
	"io/ioutil"
	"os"
	"sort"
	"strings"
)

//noinspection GoUnhandledErrorResult
func MakePutEcrQueueCommand() *cobra.Command {
	var cmdPut = &cobra.Command{
		Use:          "create-ecr-queue",
		Aliases:      []string{"update-ecr-queue"},
		Short:        "Register a ECR-based queue",
		Long:         `Create a queue backed by Amazon ECR`,
		Args:         cobra.MinimumNArgs(0),

		SilenceUsage: true,
		SilenceErrors: true,
		RunE: func(cmd *cobra.Command, args []string) error {
			conn, err := ObtainConnection(cmd)
			if err != nil {
				return err
			}

			return DoPutEcrQueue(conn, cmd)
		},
	}
	cmdPut.Flags().SortFlags = false

	cmdPut.Flags().StringP("queue", "q", "", "Queue Name")
	cmdPut.Flags().StringP("launch-template-id", "e", "",
		"Launch Template ID")
	cmdPut.Flags().StringP("queue-region", "r", "", "Queue's AWS region")
	cmdPut.Flags().StringP("exchange-bucket", "b", "",
		"Exchange S3 bucket name")
	cmdPut.Flags().BoolP("gpu-runtime", "g", false,
		"Use GPU runtime for tasks")
	cmdPut.Flags().StringP("instance-types", "i", "",
		"Comma-separated instance types")

	cmdPut.Flags().StringP("ecr-url", "u", "",
		"ECR repository URL")

	cmdPut.MarkFlagRequired("queue")
	cmdPut.MarkFlagRequired("launch-template-id")
	cmdPut.MarkFlagRequired("instance-types")

	return cmdPut
}

func DoPutEcrQueue(cli *restcli.Apollo, cmd *cobra.Command) error {
	params := queue.NewPutQueueParams()

	params.WithQueue(models.Queue{
		Name: GetFlagS(cmd,"queue"),
		LaunchTemplateID: GetFlagS(cmd,"launch-template-id"),
		InstanceTypes: strings.Split(GetFlagS(cmd,"instance-types"), ","),
		DockerRepository: GetFlagS(cmd,"ecr-url"),

		QueueRegion: GetFlagS(cmd, "queue-region"),
		ExchangeBucket: GetFlagS(cmd, "exchange-bucket"),
		GpuRuntime: GetFlagB(cmd, "gpu-runtime"),

		DockerLogin: "AWS",
		DockerPassword: "PASS",
		IsAwsEcrRepo: true,
	})

	_, err := cli.Queue.PutQueue(params, nil)
	if err != nil {
		return err
	}

	fmt.Print("OK\t"+GetFlagS(cmd,"queue")+"\n")
	return nil
}


//noinspection GoUnhandledErrorResult
func MakePutQueueCommand() *cobra.Command {
	var cmdPut = &cobra.Command{
		Use:          "create-unmanaged",
		Aliases:      []string{"update-queue"},
		Short:        "Create or modify a queue",
		Long:         `Create or modify a queue`,
		Args:         cobra.MinimumNArgs(0),

		SilenceUsage: true,
		SilenceErrors: true,
		RunE: func(cmd *cobra.Command, args []string) error {
			conn, err := ObtainConnection(cmd)
			if err != nil {
				return err
			}

			return DoPutQueue(conn, cmd)
		},
	}
	cmdPut.Flags().SortFlags = false

	cmdPut.Flags().StringP("queue", "q", "", "Queue Name")
	cmdPut.Flags().StringP("launch-template-id", "e", "",
		"Launch Template ID")
	cmdPut.Flags().StringP("instance-types", "i", "",
		"Comma-separated instance types")
	cmdPut.Flags().StringP("docker-repository", "d", "",
		"Docker repository URL")
	cmdPut.Flags().StringP("docker-login", "l", "",
		"Docker repository login")
	cmdPut.Flags().StringP("docker-password", "p", "",
		"Docker repository password, use '-' to read it from stdin")

	cmdPut.Flags().StringP("queue-region", "r", "", "Queue's AWS region")
	cmdPut.Flags().StringP("exchange-bucket", "b", "",
		"Exchange S3 bucket name")
	cmdPut.Flags().BoolP("gpu-runtime", "g", false,
		"Use GPU runtime for tasks")

	cmdPut.MarkFlagRequired("queue")
	cmdPut.MarkFlagRequired("launch-template-id")
	cmdPut.MarkFlagRequired("instance-types")

	cmdPut.MarkFlagRequired("docker-repository")
	cmdPut.MarkFlagRequired("docker-login")
	cmdPut.MarkFlagRequired("docker-password")

	return cmdPut
}

func DoPutQueue(cli *restcli.Apollo, cmd *cobra.Command) error {
	params := queue.NewPutQueueParams()

	pass := GetFlagS(cmd,"docker-password")
	if pass == "-" {
		passBytes, err := ioutil.ReadAll(os.Stdin)
		if err != nil {
			return err
		}
		pass = strings.TrimSpace(string(passBytes))
	}

	params.WithQueue(models.Queue{
		Name: GetFlagS(cmd,"queue"),
		LaunchTemplateID: GetFlagS(cmd,"launch-template-id"),
		InstanceTypes: strings.Split(GetFlagS(cmd,"instance-types"), ","),
		DockerRepository: GetFlagS(cmd,"docker-repository"),
		DockerLogin: GetFlagS(cmd,"docker-login"),
		DockerPassword: pass,

		QueueRegion: GetFlagS(cmd, "queue-region"),
		ExchangeBucket: GetFlagS(cmd, "exchange-bucket"),
		GpuRuntime: GetFlagB(cmd, "gpu-runtime"),
	})

	_, err := cli.Queue.PutQueue(params, nil)
	if err != nil {
		return err
	}

	fmt.Print("OK\t"+GetFlagS(cmd,"queue")+"\n")
	return nil
}


func MakeQueueListCmd() *cobra.Command {
	var cmdList = &cobra.Command{
		Use:          "list",
		Short:        "List task queues",
		Long:         `list queues`,
		Args:         cobra.MinimumNArgs(0),
		SilenceUsage: true,
		SilenceErrors: true,
		RunE: func(cmd *cobra.Command, args []string) error {
			conn, err := ObtainConnection(cmd)
			if err != nil {
				return err
			}

			return DoListQueues(conn, GetFlagS(cmd,"queue"), GetFlagB(cmd,"json"))
		},
	}
	cmdList.Flags().StringP("queue", "q", "", "Queue Name")
	cmdList.Flags().Bool("json", false, "JSON output")
	return cmdList
}

func DoListQueues(cli *restcli.Apollo, queueName string, json bool) error {
	params := queue.NewGetQueueListParams()
	if queueName != "" {
		params.Queue = &queueName
	}

	queues, err := cli.Queue.GetQueueList(params, nil)
	if err != nil {
		return err
	}

	if json {
		for _, t := range queues.Payload {
			bytes, e := t.MarshalBinary()
			if e != nil {
				return e
			}
			fmt.Print(string(bytes)+"\n")
		}
		return nil
	}

	table := tablewriter.NewWriter(os.Stdout)
	table.SetHeader([]string{"Queue", "Launch\nTemplate ID", "Instance Types",
		"Docker Repo", "Docker\nLogin", "Host\nCount", "Message"})
	table.SetRowLine(true)         // Enable row line
	table.SetAutoWrapText(false)

	var data [][]string

	for _, q := range queues.Payload {
		data = append(data, []string{
			q.QueueInfo.Name,
			q.QueueInfo.LaunchTemplateID,
			strings.Join(q.QueueInfo.InstanceTypes, ", "),
			q.QueueInfo.DockerRepository,
			q.QueueInfo.DockerLogin,
			fmt.Sprintf("Tot: %d\nact: %d", q.HostCount, q.ActiveHostCount),
			q.DisabledMessage,
		})
	}

	sort.Slice(data, func(i, j int) bool {
		return strings.Compare(data[i][0], data[j][0]) < 0 ||
			strings.Compare(data[i][1], data[j][1]) < 0
	})

	table.AppendBulk(data)
	table.Render()

	return nil
}

//noinspection GoUnhandledErrorResult
func MakeDeleteQueueCommand() *cobra.Command {
	var cmdDelete = &cobra.Command{
		Use:          "delete",
		Short:        "Delete a queue",
		Long:         `Delete a queue, will fail if there are live tasks within this queue`,
		Args:         cobra.MinimumNArgs(0),
		SilenceUsage: true,
		SilenceErrors: true,
		RunE: func(cmd *cobra.Command, args []string) error {
			conn, err := ObtainConnection(cmd)
			if err != nil {
				return err
			}

			return DoDeleteQueue(conn, GetFlagS(cmd,"queue"))
		},
	}
	cmdDelete.Flags().SortFlags = false

	cmdDelete.Flags().StringP("queue", "q", "", "Queue Name")
	cmdDelete.MarkFlagRequired("queue")

	return cmdDelete
}

func DoDeleteQueue(cli *restcli.Apollo, queueName string) error {
	params := queue.NewDeleteQueueParams()
	params.Queue = queueName

	_, err := cli.Queue.DeleteQueue(params, nil)
	if err != nil {
		return err
	}
	fmt.Print("DELETED\t"+queueName+"\n")

	return nil
}
