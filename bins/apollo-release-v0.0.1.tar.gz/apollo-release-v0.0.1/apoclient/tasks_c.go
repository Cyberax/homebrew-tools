package apoclient

import (
	"apollo/data"
	"apollo/proto/gen/models"
	"apollo/proto/gen/restcli"
	"apollo/proto/gen/restcli/task"
	. "apollo/utils"
	"fmt"
	"github.com/olekukonko/tablewriter"
	"github.com/spf13/cobra"
	"os"
	"sort"
	"strconv"
	"strings"
)

func MakeListCmd() *cobra.Command {
	var cmdList = &cobra.Command{
		Use:          "list",
		Short:        "List tasks with optional filtering",
		Long:         `list tasks, applying optional filters`,
		Args:         cobra.MinimumNArgs(0),
		SilenceUsage: true,
		SilenceErrors: true,
		RunE: func(cmd *cobra.Command, args []string) error {
			conn, err := ObtainConnection(cmd)
			if err != nil {
				return err
			}

			return DoListTasks(conn, GetFlagS(cmd,"queue"),
				GetFlagS(cmd,"job"), GetFlagB(cmd,"json"))
		},
	}
	cmdList.Flags().SortFlags = false

	cmdList.Flags().StringP("queue", "q", "", "Queue Name")
	cmdList.Flags().StringP("job", "j", "", "Job Name")
	cmdList.Flags().Bool("json", false, "JSON output")
	return cmdList
}

func getCount(subtasks map[string][]int64, states ...models.SubtaskStateEnum) int {
	count := int(0)
	for _, state := range states {
		val, ok := subtasks[string(state)]
		if ok {
			count += len(val)
		}
	}

	return count
}

func DoListTasks(cli *restcli.Apollo, queue string, job string, json bool) error {
	params := task.NewGetTaskListParams()
	if queue != "" {
		params.Queue = &queue
	}
	if job != "" {
		params.Job = &job
	}

	tasks, err := cli.Task.GetTaskList(params, nil)
	if err != nil {
		return err
	}

	if json {
		for _, t := range tasks.Payload {
			bytes, e := t.MarshalBinary()
			if e != nil {
				return e
			}
			fmt.Print(string(bytes)+"\n")
		}
		return nil
	}

	table := tablewriter.NewWriter(os.Stdout)
	table.SetHeader([]string{"Queue", "ID", "Cmdline", "Image ID", "Job (+)",
		"Exp RAM", "Max RAM", "Scales?", "Progress (*)"})
	table.SetRowLine(true)         // Enable row line
	table.SetAutoWrapText(false)

	var data [][]string

	for _, t := range tasks.Payload {
		active := getCount(t.SubtasksByStatus, models.SubtaskStateEnumPulling,
			models.SubtaskStateEnumCreated, models.SubtaskStateEnumStarted,
			models.SubtaskStateEnumDispatched)
		done := getCount(t.SubtasksByStatus, models.SubtaskStateEnumDone,
			models.SubtaskStateEnumFailed)
		waiting := getCount(t.SubtasksByStatus, models.SubtaskStateEnumWaiting)

		progress := fmt.Sprintf("Status: %s\n", t.State)

		progress += fmt.Sprintf("W: %d A: %d D: %d", waiting, active, done)

		var job = ""
		if t.TaskStruct.Job.JobName != "" {
			job = t.TaskStruct.Job.JobName
			job += fmt.Sprintf("\nMF: %d, CF: %d", t.TaskStruct.Job.MaxFailedCount, 0)
		}

		var index = ""
		if t.TaskStruct.EndArrayIndex - t.TaskStruct.StartArrayIndex > 1 {
			index = fmt.Sprintf("\n$IDX: [%d to %d)", t.TaskStruct.StartArrayIndex,
				t.TaskStruct.EndArrayIndex)
		}

		var imageStr string
		if len(t.TaskStruct.DockerImageID) > 20 {
			imageStr = t.TaskStruct.DockerImageID[0:16]
		} else {
			imageStr = t.TaskStruct.DockerImageID
		}

		data = append(data, []string{
			t.TaskStruct.Queue,
			t.TaskID,
			renderCmdline(t.TaskStruct.Cmdline, 40) + index,
			imageStr,
			job,
			renderSize(t.TaskStruct.ExpectedRAMMb),
			renderSize(t.TaskStruct.MaxRAMMb),
			fmt.Sprintf("%v", t.TaskStruct.CanUseAllCpus),
			progress,
		})
	}

	sortStringArrayByFirstElement(data)

	table.AppendBulk(data)
	table.Render()
	fmt.Printf("$IDX - this task is an array task with these bounds\n")
	fmt.Printf("(+) MF: - maximum failed count, CF: currently failed\n")
	fmt.Printf("(*) W: - Number of waiting subtasks, A: - active, D: - done\n")

	return nil
}

func renderSize(mb int64) string {
	if mb < 10000 {
		return fmt.Sprintf("%d MB", mb)
	}
	return fmt.Sprintf("%d GB", mb/1024)
}

func renderCmdline(cmdline []string, maxSz int) string {
	res := ""
	for _, s := range cmdline {
		if res != "" {
			res += " "
		}
		if strings.ContainsAny(s, "' ") {
			res += "\"" + s + "\""
		} else {
			res += s
		}
	}
	if len(res) > maxSz {
		return res[0:maxSz] + "..."
	}
	return res
}

func MakeDescribeCommand() *cobra.Command {
	var cmdList = &cobra.Command{
		DisableFlagsInUseLine: true,
		Use:          "describe [flags] <task-id> [<task-id>, ...]",
		Short:        "Describe a task",
		Long:         `inspect the task details, including its environment`,
		Args:         cobra.MinimumNArgs(1),
		SilenceUsage: true,
		SilenceErrors: true,
		RunE: func(cmd *cobra.Command, args []string) error {
			conn, err := ObtainConnection(cmd)
			if err != nil {
				return err
			}

			return DoDescribeTasks(conn, args)
		},
	}
	return cmdList
}

func DoDescribeTasks(cli *restcli.Apollo, ids []string) error {
	params := task.NewGetTaskListParams()
	params.ID = ids
	var t = true
	params.WithEnv = &t

	tasks, err := cli.Task.GetTaskList(params, nil)
	if err != nil {
		return err
	}

	for _, t := range tasks.Payload {
		bytes, e := t.MarshalBinary()
		if e != nil {
			return e
		}
		fmt.Print(string(bytes)+"\n")
	}

	return nil
}

func MakeAssignCmd() *cobra.Command {
	var cmdAssign = &cobra.Command{
		Use:          "assign <task-id.subtask-index> <node-id>",
		Short:        "Assign a task to a node",
		Long:         `assign a task, manually bypassing the scheduler`,
		Args:         cobra.MinimumNArgs(2),
		SilenceUsage: true,
		SilenceErrors: true,
		RunE: func(cmd *cobra.Command, args []string) error {
			conn, err := ObtainConnection(cmd)
			if err != nil {
				return err
			}

			return DoAssignTask(conn, args[0], args[1])
		},
	}
	return cmdAssign
}

func DoAssignTask(apollo *restcli.Apollo, taskId string, nodeId string) error {
	params := task.NewPutTaskAssignmentParams()
	params.Node = nodeId
	params.Subtask = taskId

	_, err := apollo.Task.PutTaskAssignment(params, nil)
	if err != nil {
		return err
	}
	fmt.Printf("OK\n")
	return nil
}


func MakeCancelCmd() *cobra.Command {
	var cmdAssign = &cobra.Command{
		Use:          "cancel <task-id>",
		Short:        "Cancel a task",
		Long:         `cancel a task, terminating all the running subtasks`,
		Args:         cobra.MinimumNArgs(1),
		SilenceUsage: true,
		SilenceErrors: true,
		RunE: func(cmd *cobra.Command, args []string) error {
			conn, err := ObtainConnection(cmd)
			if err != nil {
				return err
			}

			return DoCancelTask(conn, args[0])
		},
	}
	return cmdAssign
}

func DoCancelTask(apollo *restcli.Apollo, taskId string) error {
	params := task.NewPutTaskCancellationParams()
	params.Task = taskId

	_, err := apollo.Task.PutTaskCancellation(params, nil)
	if err != nil {
		return err
	}
	fmt.Printf("OK\n")
	return nil
}


func MakeWaitCmd() *cobra.Command {
	var cmdAssign = &cobra.Command{
		Use:          "wait <task-id>",
		Short:        "Wait for a task or subtask to finish",
		Long:         `Wait for a specified task or subtask to complete`,
		Args:         cobra.MinimumNArgs(1),
		SilenceUsage: true,
		SilenceErrors: true,
		RunE: func(cmd *cobra.Command, args []string) error {
			conn, err := ObtainConnection(cmd)
			if err != nil {
				return err
			}

			return DoWaitTask(conn, args[0])
		},
	}
	return cmdAssign
}

func DoWaitTask(apollo *restcli.Apollo, taskId string) error {
	params := task.NewGetTaskWaitParams()
	params.Task = taskId

	r, err := apollo.Task.GetTaskWait(params, nil)
	if err != nil {
		return err
	}
	exitCode, err := strconv.Atoi(r.Payload)
	if err != nil {
		return err
	}
	if exitCode == 0 {
		fmt.Printf("OK\n")
	} else {
		fmt.Printf("FAILED\n")
	}
	os.Exit(exitCode)
	return nil
}


func MakeSubtaskListCmd() *cobra.Command {
	var cmdList = &cobra.Command{
		Use:          "subtasks [<subtask-id>, ...]",
		Short:        "List subtasks",
		Long:         `list subtasks by their parent task or by IDs`,
		Args:         cobra.MinimumNArgs(0),
		SilenceUsage: true,
		SilenceErrors: true,
		RunE: func(cmd *cobra.Command, args []string) error {
			conn, err := ObtainConnection(cmd)
			if err != nil {
				return err
			}

			return DoListSubTasks(conn,
				GetFlagS(cmd,"parent"), GetFlagB(cmd,"json"), args)
		},
	}
	cmdList.Flags().SortFlags = false

	cmdList.Flags().StringP("parent", "p", "", "Parent Task")
	cmdList.Flags().Bool("json", false, "JSON output")
	return cmdList
}

func DoListSubTasks(api *restcli.Apollo, parent string, json bool, ids []string) error {
	params := task.NewGetSubtaskListParams()
	params.TaskID = &parent
	params.ID = ids

	list, err := api.Task.GetSubtaskList(params, nil)
	if err != nil {
		return err
	}

	if json {
		for _, st := range list.Payload {
			// Print task information
			bytes, e := st.MarshalBinary()
			if e != nil {
				return e
			}
			fmt.Print(string(bytes)+"\n")
		}
		return nil
	}

	table := tablewriter.NewWriter(os.Stdout)
	table.SetHeader([]string{"ID", "Status", "Node", "Container ID", "Exit Code",
		"Error String"})
	table.SetRowLine(true)         // Enable row line
	table.SetAutoWrapText(false)

	var tableData [][]string

	for _, st := range list.Payload {
		ec := ""
		exitError := ""
		lastNode := ""
		cntId := ""
		if st.Info.Status == models.SubtaskStateEnumFailed ||
			st.Info.Status == models.SubtaskStateEnumDone{
			lastAssgn := st.Info.PriorAssignments[fmt.Sprintf("%d", st.RetryNum)]
			ec = fmt.Sprintf("%d", lastAssgn.ExitCode)
			exitError = lastAssgn.ExitError
			lastNode = lastAssgn.AssignedNode
			cntId = lastAssgn.ContainerID
		} else if st.Info.CurrentAssignment != nil {
			lastNode = st.Info.CurrentAssignment.AssignedNode
			cntId = st.Info.CurrentAssignment.ContainerID
		}
		ci := ""
		if cntId != "" {
			ci = cntId[:10]
		}
		tableData = append(tableData, []string{
			fmt.Sprintf("%s#%d", st.Key, st.RetryNum),
			string(st.Info.Status),
			lastNode,
			ci,
			ec,
			exitError,
		})
	}

	sortStringArrayByFirstElement(tableData)

	table.AppendBulk(tableData)
	table.Render()

	return nil
}

func sortStringArrayByFirstElement(data [][]string) {
	sort.Slice(data, func(i, j int) bool {
		return strings.Compare(data[i][0], data[j][0]) < 0 ||
			strings.Compare(data[i][1], data[j][1]) < 0
	})
}

func MakeTaskLogsCmd() *cobra.Command {
	var cmdLogs = &cobra.Command{
		Use:          "logs <subtask-id>",
		Short:        "Get subtask logs",
		Long:         `get the logs of the most recent subtask retry`,
		Args:         cobra.MinimumNArgs(1),
		SilenceUsage: true,
		SilenceErrors: true,
		RunE: func(cmd *cobra.Command, args []string) error {
			conn, err := ObtainConnection(cmd)
			if err != nil {
				return err
			}

			return DoTaskLogs(conn, GetFlagB(cmd,"follow"), args[0])
		},
	}
	cmdLogs.Flags().SortFlags = false
	cmdLogs.Flags().BoolP("follow", "f", false, "Follow logs")
	return cmdLogs
}

func DoTaskLogs(api *restcli.Apollo, follow bool, subtaskId string) error {
	key, fullySpecced, err := data.ParseSubtaskKey(subtaskId)
	if err != nil {
		return err
	}

	params := task.NewGetSubtaskListParams()
	if fullySpecced {
		params.ID = []string{key.String()}
	} else {
		params.TaskID = &key.ParentKey
	}

	list, err := api.Task.GetSubtaskList(params, nil)
	if err != nil {
		return err
	}
	if len(list.Payload) == 0 {
		return fmt.Errorf("can't find task %s", subtaskId)
	}
	if len(list.Payload) != 1 {
		return fmt.Errorf("ambiguous subtask reference, specify the subtask index")
	}
	subtaskInfo := list.Payload[0].Info

	assignment := FindLastAssignment(&subtaskInfo)
	if assignment == nil {
		return fmt.Errorf("subtask is in an ivalid state")
	}

	nodeKey := assignment.AssignedNode
	containerId := assignment.ContainerID
	if containerId == "" || nodeKey == "" {
		return fmt.Errorf("subtask is in an ivalid state")
	}

	// OK, do the docker command
	dockerArgs := []string{"logs"}
	if follow {
		dockerArgs = append(dockerArgs, "--follow")
	}
	dockerArgs = append(dockerArgs, containerId)
	_, err = DoRunDocker(api, nodeKey, dockerArgs)
	return err
}

func FindLastAssignment(info *models.SubtaskInfo) *models.SubtaskAssignment {
	if info.CurrentAssignment != nil {
		return info.CurrentAssignment
	}
	var maxRetry int64 = -1
	var res *models.SubtaskAssignment
	for k, v := range info.PriorAssignments {
		var curRetry int64 = -1
		_, err := fmt.Sscanf(k, "%d", &curRetry)
		PanicIf(err!=nil, "Can't parse: "+k)

		if curRetry > maxRetry {
			res = &v
			maxRetry = curRetry
		}
	}

	return res
}
