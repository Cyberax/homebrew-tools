package apoclient

import (
	"apollo/proto/gen/models"
	"apollo/proto/gen/restcli"
	"apollo/proto/gen/restcli/files"
	"apollo/proto/gen/restcli/task"
	"fmt"
	"github.com/spf13/cobra"
	"io"
	"log"
	"mime"
	"net/http"
	"os"
	"path"
	"sync"
)

func MakePutFileCommand() *cobra.Command {
	var cmdPut = &cobra.Command{
		Use:          "put <task-id> <filename> [<filename>]",
		Short:        "Upload files",
		Long:         `Upload files into the task's namespace`,
		Args:         cobra.MinimumNArgs(2),
		SilenceUsage: true,
		SilenceErrors: true,
		RunE: func(cmd *cobra.Command, args []string) error {
			conn, err := ObtainConnection(cmd)
			if err != nil {
				return err
			}
			return DoPutFiles(conn, args[0], args[1:])
		},
	}
	return cmdPut
}

func DoPutFiles(api *restcli.Apollo, taskId string, fileNames []string) error {
	params := files.NewPutFilesParams()
	params.TaskID = taskId
	lst := make([]models.FileInfoEntry, len(fileNames))
	params.FilesData = lst

	var nameSet = make(map[string]string)
	for i, nm := range fileNames {
		info, err := os.Stat(nm)
		if err != nil {
			return err
		}
		if info.IsDir() {
			return fmt.Errorf("file %s is a directory", nm)
		}
		_, fileLeaf := path.Split(nm)
		_, ok := nameSet[fileLeaf]
		if ok {
			return fmt.Errorf("at least two files have the same name %s", fileLeaf)
		}
		nameSet[fileLeaf] = ""
		lst[i] = models.FileInfoEntry{FileName: fileLeaf, FileSize: info.Size()}
	}

	filePlaces, err := api.Files.PutFiles(params, nil)
	if err != nil {
		return err
	}

	// Now that we have the list of file places - go and upload them!
	var mtx sync.Mutex
	var errors []error
	var wg sync.WaitGroup

	for i, url := range filePlaces.Payload {
		wg.Add(1)
		go func(i int) {
			defer wg.Done()
			fmt.Printf("Uploading %s\n", fileNames[i])
			err = putFile(fileNames[i], lst[i].FileSize, url)
			if err != nil {
				fmt.Printf("Error uploading %s=%s\n", fileNames[i], err)
				mtx.Lock()
				defer mtx.Unlock()
				errors = append(errors, err)
			} else {
				fmt.Printf("Done uploading %s\n", fileNames[i])
			}
		}(i)
	}
	wg.Wait()
	if errors != nil {
		return errors[0]
	}
	return nil
}

func putFile(name string, sz int64, url string) error {
	data, err := os.Open(name)
	if err != nil {
		return err
	}
	//noinspection GoUnhandledErrorResult
	defer data.Close()

	req, err := http.NewRequest("PUT", url, data)
	if err != nil {
		log.Fatal(err)
	}

	ext := path.Ext(name)
	var mt string
	if ext != "" {
		mt = mime.TypeByExtension(ext)
	}
	if mt == "" {
		mt = "text/plain"
	}
	req.Header.Set("Content-Type", mt)
	req.ContentLength = sz

	client := &http.Client{}
	res, err := client.Do(req)
	if err != nil {
		return err
	}
	_ = res.Body.Close()

	// Check server response
	if res.StatusCode != http.StatusOK {
		return fmt.Errorf("bad status: %s", res.Status)
	}

	return nil
}

func MakeFinishFilesUploadCommand() *cobra.Command {
	var cmdFinished = &cobra.Command{
		Use:          "done-uploading <task-id>",
		Short:        "Signal that uploading is finished",
		Long:         `Signal that uploading is finished`,
		Args:         cobra.MinimumNArgs(1),
		SilenceUsage: true,
		SilenceErrors: true,
		RunE: func(cmd *cobra.Command, args []string) error {
			conn, err := ObtainConnection(cmd)
			if err != nil {
				return err
			}
			return DoFinishUploading(conn, args[0])
		},
	}
	return cmdFinished
}

func DoFinishUploading(api *restcli.Apollo, taskId string) error {
	params := task.NewPostTaskLaunchParams()
	params.TaskID = taskId
	_, err := api.Task.PostTaskLaunch(params, nil)
	if err != nil {
		return err
	}
	return nil
}

func MakeListFilesCommand() *cobra.Command {
	var cmdList = &cobra.Command{
		Use:          "list <task-id>",
		Short:        "List the task files",
		Long:         `List the files associated with the task`,
		Args:         cobra.MinimumNArgs(1),
		SilenceUsage: true,
		SilenceErrors: true,
		RunE: func(cmd *cobra.Command, args []string) error {
			conn, err := ObtainConnection(cmd)
			if err != nil {
				return err
			}
			return DoListFiles(conn, args[0])
		},
	}
	return cmdList
}

func DoListFiles(api *restcli.Apollo, taskId string) error {
	params := files.NewGetFilesListParams()
	params.TaskID = taskId
	list, err := api.Files.GetFilesList(params, nil)
	if err != nil {
		return err
	}
	fmt.Printf("File Name\tFile Size\n")
	fmt.Printf("---------\t---------\n")
	for _, fe := range list.Payload {
		fmt.Printf("%s\t%d\n", fe.FileName, fe.FileSize)
	}
	return nil
}

func MakeExposeFileCommand() *cobra.Command {
	var cmdPut = &cobra.Command{
		Use:          "expose <task-id> <filename> [<filename>]",
		Short:        "Expose files via HTTPS",
		Args:         cobra.MinimumNArgs(2),
		SilenceUsage: true,
		SilenceErrors: true,
		RunE: func(cmd *cobra.Command, args []string) error {
			conn, err := ObtainConnection(cmd)
			if err != nil {
				return err
			}
			return DoExposeFiles(conn, args[0], args[1:])
		},
	}
	return cmdPut
}

func DoExposeFiles(api *restcli.Apollo, taskId string, fileNames []string) error {
	params := files.NewPutFilesExposureParams()
	params.TaskID = taskId
	params.Files = fileNames

	filePlaces, err := api.Files.PutFilesExposure(params, nil)
	if err != nil {
		return err
	}

	// Now that we have the list of file places - go and upload them!
	for i, url := range filePlaces.Payload {
		fmt.Printf("%s\t%s\n", fileNames[i], url)
	}

	return nil
}

func MakeGetFileCommand() *cobra.Command {
	var cmdPut = &cobra.Command{
		Use:          "get <task-id> <filename> [<filename>]",
		Short:        "Download files",
		Long:         `Download files from the task's namespace`,
		Args:         cobra.MinimumNArgs(2),
		SilenceUsage: true,
		SilenceErrors: true,
		RunE: func(cmd *cobra.Command, args []string) error {
			conn, err := ObtainConnection(cmd)
			if err != nil {
				return err
			}
			return DoGetFiles(conn, args[0], args[1:])
		},
	}
	return cmdPut
}

func DoGetFiles(api *restcli.Apollo, taskId string, fileNames []string) error {
	params := files.NewGetFilesParams()
	params.TaskID = taskId
	params.Files = fileNames

	filePlaces, err := api.Files.GetFiles(params, nil)
	if err != nil {
		return err
	}

	// Now that we have the list of file places - go and upload them!
	for i, url := range filePlaces.Payload {
		fmt.Printf("Downloading %s\n", fileNames[i])
		err = getFile(fileNames[i], url)
		if err != nil {
			return err
		}
		fmt.Printf("Done downloading %s\n", fileNames[i])
	}

	return nil
}

//noinspection GoUnhandledErrorResult
func getFile(name string, url string) error {
	// Create the file
	out, err := os.Create(name)
	if err != nil  {
		return err
	}
	defer out.Close()

	// Get the data
	resp, err := http.Get(url)
	if err != nil {
		return err
	}
	defer resp.Body.Close()

	// Check server response
	if resp.StatusCode != http.StatusOK {
		return fmt.Errorf("bad status: %s", resp.Status)
	}

	// Writer the body to file
	_, err = io.Copy(out, resp.Body)
	if err != nil  {
		return err
	}

	return nil
}

func MakeDeleteFileCommand() *cobra.Command {
	var cmdPut = &cobra.Command{
		Use:          "rm <task-id> <filename> [<filename>]",
		Short:        "Remote files via HTTPS",
		Args:         cobra.MinimumNArgs(2),
		SilenceUsage: true,
		SilenceErrors: true,
		RunE: func(cmd *cobra.Command, args []string) error {
			conn, err := ObtainConnection(cmd)
			if err != nil {
				return err
			}
			return DoDeleteFiles(conn, args[0], args[1:])
		},
	}
	return cmdPut
}

func DoDeleteFiles(api *restcli.Apollo, taskId string, fileNames []string) error {
	params := files.NewDeleteFilesParams()
	params.TaskID = taskId
	params.Files = fileNames

	_, err := api.Files.DeleteFiles(params, nil)
	return err
}
