package apoclient

import (
	"apollo/proto/gen/restcli"
	node2 "apollo/proto/gen/restcli/node"
	"fmt"
	"github.com/spf13/cobra"
	"io/ioutil"
	"os"
	"os/exec"
	"os/signal"
	"syscall"
)

func MakeDockerCommand() *cobra.Command {
	var getDocker = &cobra.Command{
		Use:          "docker <node-id> [docker-arguments]",
		Short:        "Run the Docker wrapper for the given node",
		Long:         `Get the arguments needed to connect to the node and run Docker CLI`,
		Args:         cobra.MinimumNArgs(1),
		DisableFlagParsing: true,
		SilenceUsage: true,
		SilenceErrors: true,
		RunE: func(cmd *cobra.Command, args []string) error {
			conn, err := ObtainConnection(cmd)
			if err != nil {
				return err
			}

			status, err := DoRunDocker(conn, args[0], args[1:])
			if err == nil {
				os.Exit(int(status))
			}
			return err
		},
	}

	return getDocker
}

func execDocker(dockerArgs []string, env []string) (syscall.WaitStatus, error) {
	binary, err := exec.LookPath("docker")
	if err != nil {
		return 1, err
	}

	cmd := exec.Command(binary, dockerArgs...)
	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr
	cmd.Stdin = os.Stdin
	cmd.Env = env

	if err := cmd.Start(); err != nil {
		return 1, err
	}

	// wait for the command to finish
	waitCh := make(chan error, 1)
	go func() {
		waitCh <- cmd.Wait()
		close(waitCh)
	}()

	sigChan := make(chan os.Signal, 10)
	signal.Notify(sigChan)

	// You need a for loop to handle multiple signals
	for {
		select {
		case sig := <-sigChan:
			_ = cmd.Process.Signal(sig)
		case err := <-waitCh:
			if err == nil {
				return 0, nil
			}

			// Subprocess exited. Get the return code, if we can
			var waitStatus syscall.WaitStatus
			exitError := err.(*exec.ExitError);
			waitStatus = exitError.Sys().(syscall.WaitStatus)
			return waitStatus, nil
		}
	}
}

//noinspection GoUnhandledErrorResult
func DoRunDocker(api *restcli.Apollo, node string, dockerArgs []string) (
	syscall.WaitStatus, error) {

	params := node2.NewGetDockerConnectionParams()
	params.NodeID = node

	dockerParams, err := api.Node.GetDockerConnection(params, nil)
	if err != nil {
		return 0, err
	}

	if dockerParams.Payload.DockerAddress == "" {
		return execDocker(dockerArgs, os.Environ())
	}

	// Create temporary files with the credentials
	caFile, err := ioutil.TempFile("", fmt.Sprintf("*-%s-ca.pem", node))
	if err != nil {
		return 0, err
	}
	_, err = caFile.WriteString(dockerParams.Payload.DockerCaCert)
	if err != nil {
		return 0, err
	}
	caFile.Close()
	defer os.Remove(caFile.Name())

	certFile, err := ioutil.TempFile("", fmt.Sprintf("*-%s-cert.pem", node))
	if err != nil {
		return 0, err
	}
	_, err = certFile.WriteString(dockerParams.Payload.DockerCert)
	if err != nil {
		return 0, err
	}
	certFile.Close()
	defer os.Remove(certFile.Name())

	keyFile, err := ioutil.TempFile("", fmt.Sprintf("*-%s-key.pem", node))
	if err != nil {
		return 0, err
	}
	_, err = keyFile.WriteString(dockerParams.Payload.DockerClientKey)
	if err != nil {
		return 0, err
	}
	keyFile.Close()
	defer os.Remove(keyFile.Name())

	dockerArgs = append([]string{"--tlsverify", "--tlscacert",
		caFile.Name(), "--tlscert", certFile.Name(), "--tlskey", keyFile.Name(),
		"--host", dockerParams.Payload.DockerAddress}, dockerArgs...)

	return execDocker(dockerArgs, os.Environ())
}
