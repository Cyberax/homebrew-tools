package data

import (
	"apollo/utils"
	"fmt"
	"sort"
)

const WhitelistTable = "whitelist"

type WhitelistStore struct {
	store     KVStore

	mtx utils.SessionedMutex
	whitelist map[string]string
	preconfigured map[string]string
}

type WhitelistEntry struct {
	Key string
}

func NewWhitelistStore(store KVStore) *WhitelistStore {
	return &WhitelistStore{
		store: store,
		whitelist: make(map[string]string),
		preconfigured: make(map[string]string),
	}
}

func (w *WhitelistStore) Hydrate() error {
	var data []WhitelistEntry
	err := w.store.LoadTable(WhitelistTable, &data)
	if err != nil {
		return err
	}
	for _, d := range data {
		w.AddWhitelist(d.Key)
	}
	return nil
}

func (w *WhitelistStore) AddPreconfigured(acct string) {
	s := w.mtx.Lock()
	defer s.Unlock()

	w.preconfigured[acct] = acct
	w.whitelist[acct] = acct
}

func (w *WhitelistStore) DeleteWhitelist(acct string) error {
	s := w.mtx.Lock()
	defer s.Unlock()

	_, ok := w.preconfigured[acct]
	if ok {
		return fmt.Errorf("can't delete a static whitelist entry")
	}

	w.store.DeleteValue(WhitelistTable, acct)
	delete(w.whitelist, acct)

	return nil
}

func (w *WhitelistStore) AddWhitelist(acct string) {
	s := w.mtx.Lock()
	defer s.Unlock()

	_, ok := w.whitelist[acct]
	if ok {
		return
	}

	w.whitelist[acct] = acct
	w.store.StoreValues(WhitelistTable, []WhitelistEntry{{Key: acct}})
}

func (w *WhitelistStore) GetList() []string{
	s := w.mtx.Lock()
	defer s.Unlock()

	var res []string
	for k := range w.whitelist {
		res = append(res, k)
	}
	sort.Strings(res)
	return res
}

func (w *WhitelistStore) IsWhitelisted(acct string) bool {
	s := w.mtx.Lock()
	defer s.Unlock()
	_, ok := w.whitelist[acct]
	return ok
}

func (w *WhitelistStore) IsPreconfigured(acctId string) bool {
	_, ok := w.preconfigured[acctId]
	return ok
}
