package data

import (
	. "apollo/utils"
	"context"
	"fmt"
	rbt "github.com/emirpasic/gods/trees/redblacktree"
	"github.com/emirpasic/gods/utils"
	"github.com/sirupsen/logrus"
	"runtime"
	"sort"
	"strconv"
	"strings"
	"sync"
)

type LockTarget int64
const LockQueue LockTarget = 0
const LockNode LockTarget = 1
const LockJob LockTarget = 2
const LockTask LockTarget = 3
const LockSubtask LockTarget = 4

type LockMode int64
const LockModeNone = 0
const LockModeRead = 1
const LockModeFull = 2

type NotifyTarget string
const NotifySubtaskScheduled NotifyTarget = "subtask-scheduled"
const NotifySubtaskFinished NotifyTarget = "subtask-finished"
const NotifyTaskDone NotifyTarget = "task-done"
const NotifyForAllKeys = "*"

var NotifyOrder = []NotifyTarget {NotifySubtaskScheduled, NotifySubtaskFinished, NotifyTaskDone}

var DefaultPanicker = func(err string){panic(err)}
var Panicker = DefaultPanicker

func (l LockTarget) String() string {
	switch l {
	case LockQueue:
		return "queue"
	case LockNode:
		return "node"
	case LockJob:
		return "job"
	case LockTask:
		return "task"
	case LockSubtask:
		return "subtask"
	default:
		panic("Unknown target " + fmt.Sprintf("%d", l))
	}
}

// The central store for lockable items, usable through the Session manipulation
// interface.
type LockStore struct {
	// Notify targets
	notifiersMtx   sync.Mutex
	notifyHandlers map[NotifyTarget]map[string]map[chan<-string]bool
	chanRefCount map[chan<-string]int64
}

type lockItemValue struct {
	row *TableRow
	count int
	fullLock bool
}

type lockItemKey struct {
	what LockTarget
	key string
}

func (l lockItemKey) String() string {
	return "{type: "+ l.what.String() + ", key: " + l.key + "}"
}

func compareLockItemKeys(a, b interface{}) int {
	k1, k2 := a.(lockItemKey), b.(lockItemKey)
	if k1.what != k2.what {
		return utils.IntComparator(int(k1.what), int(k2.what))
	}
	return utils.StringComparator(k1.key, k2.key)
}

// The main holder for the lock information associated with a request
// it provides a handy interface and enforces the correct lock order to
// prevent deadlocks. It's not threadsafe and must not be used from multiple
// threads without additional locking. Also doubles as a context carrier.
type Session struct {
	context          context.Context
	store            *LockStore
	lockedItems      *rbt.Tree // lockItemKey-to-*lockItemValue
	finalizerArmedAt []string

	notifies map[NotifyTarget][]string
}

func NewLockStore() *LockStore {
	res := &LockStore{
		notifyHandlers: make(map[NotifyTarget]map[string]map[chan<-string]bool),
		chanRefCount: make(map[chan<-string]int64),
	}
	for _, l := range NotifyOrder {
		res.notifyHandlers[l] = make(map[string]map[chan<-string]bool)
	}
	return res
}

func (ls *LockStore) Subscribe(target NotifyTarget, item string,
	channel chan<-string, guaranteedDelivery bool) {

	ls.notifiersMtx.Lock()
	defer ls.notifiersMtx.Unlock()
	items, ok := ls.notifyHandlers[target][item]
	if !ok {
		items = make(map[chan<-string]bool)
		ls.notifyHandlers[target][item] = items
		ls.chanRefCount[channel] = 1
	} else {
		ls.chanRefCount[channel] = ls.chanRefCount[channel] + 1
		if items[channel] != guaranteedDelivery {
			panic("Inconsistent delivery for the channel for the item: "+item)
		}
	}
	items[channel] = guaranteedDelivery
}

func (ls *LockStore) Unsubscribe(target NotifyTarget, item string, channel chan<-string) {
	ls.notifiersMtx.Lock()
	defer ls.notifiersMtx.Unlock()

	count, ok := ls.chanRefCount[channel]
	if !ok {
		return
	}
	if count--; count != 0 {
		ls.chanRefCount[channel] = count
		return
	}

	items := ls.notifyHandlers[target][item]
	delete(ls.chanRefCount, channel)
	delete(items, channel)
	if len(items) == 0 {
		delete(ls.notifyHandlers[target], item)
	}
	close(channel)
}

func (l *Session) L() *logrus.Entry {
	return CL(l.context)
}

func (l *Session) Ctx() context.Context {
	return l.context
}

func (ls *LockStore) Session(ctx context.Context) *Session {
	if ctx == nil {
		ctx = context.Background()
	}
	return NewSession(ls, ctx)
}

func NewSession(store *LockStore, context context.Context) *Session {
	return &Session{
		context: context,
		store: store,
		lockedItems: rbt.NewWith(compareLockItemKeys),
		notifies: make(map[NotifyTarget][]string),
	}
}

// Arm the finalizer to detect resource leaks in case we forget
// to unlock items
func (l *Session) armFinalizer() {
	if l.finalizerArmedAt == nil {
		_, file, line, _ := runtime.Caller(3)
		l.finalizerArmedAt = []string{file, strconv.Itoa(line)}
		runtime.SetFinalizer(l, func(s *Session) {
			bld := strings.Builder{}
			for _, i := range s.lockedItems.Values() {
				if bld.Len() != 0 {
					bld.WriteString(", ")
				}
				bld.WriteString(string(i.(*lockItemValue).row.String()))
			}
			s.Panic(fmt.Sprintf("There are still unlocked items left: %s. "+
				"At: %s, %s", bld.String(), s.finalizerArmedAt[0], s.finalizerArmedAt[1]))
		})
	}
}

func (l *Session) disarmFinalizer() {
	l.finalizerArmedAt = nil
	runtime.SetFinalizer(l, nil)
}

func (l *Session) Panic(args string) {
	l.disarmFinalizer()
	Panicker(args)
}

func (l *Session) sendOutNotifies() {
	notifies := l.notifies

	// Run notifications in a separate routine to make sure
	// that we won't obscure the error if we're sending notifies from a panic
	// handler.
	go func() {
		l.store.notifiersMtx.Lock()
		defer l.store.notifiersMtx.Unlock()

		for tgt, changed := range notifies {
			notifiers := l.store.notifyHandlers[tgt]
			for _, key := range changed {
				nt, ok := notifiers[key]
				if ok {
					l.doSendOutMessages(nt, key)
				}
				nt, ok = notifiers[NotifyForAllKeys]
				if ok {
					l.doSendOutMessages(nt, key)
				}
			}
		}
	}()

	// Now that notifies are sent, clear them out
	l.notifies = make(map[NotifyTarget][]string)
}

func (l *Session) doSendOutMessages(nt map[chan<- string]bool, keyThatWasChanged string) {
	for ntTgt, reliable := range nt {
		if reliable {
			// Blocking send
			ntTgt <- keyThatWasChanged
		} else {
			// Best-effort non-blocking send
			select {
			case ntTgt <- keyThatWasChanged:
			default:
			}
		}
	}
}

func (l *Session) AddNotify(what NotifyTarget, keys ...string) {
	val, ok := l.notifies[what]
	if !ok {
		l.notifies[what] = keys
	} else {
		l.notifies[what] = append(val, keys...)
	}

	// Immediately send out notify if there are no locks
	if l.lockedItems.Empty() {
		l.sendOutNotifies()
	}
}

func (l *Session) LockItem(item *TableRow, mode LockMode) {
	if mode == LockModeNone || item == nil {
		return
	}
	if l.lockedItems.Empty() {
		l.armFinalizer()
	}

	itemKey := lockItemKey{item.GetType(), item.GetKey()}

	value, ok := l.lockedItems.Get(itemKey)
	if ok {
		curLockedValue := value.(*lockItemValue)
		// We already have locked the item, check for inconsistent locks
		if mode == LockModeFull && !curLockedValue.fullLock {
			l.Panic(fmt.Sprintf("Trying to full-lock %s which was not full-locked before",
				item.String()))
		}
		// Everything is OK, just increase the lock count
		curLockedValue.count++
		return
	}

	// Ensure that we're not locking out of order
	if curMax := l.lockedItems.Right(); curMax != nil{
	 	if compareLockItemKeys(curMax.Key, itemKey) > 0 {
			l.Panic(fmt.Sprintf("Item %s is locked out of order, previous items is %s",
				item.String(), curMax.Key.(lockItemKey).String()))
		}
	}

	// Create the new lock item
	liv := &lockItemValue{
		row: item,
		fullLock: mode == LockModeFull,
		count:    1,
	}
	if mode == LockModeFull {
		item.GetLock().Lock()
	} else {
		item.GetLock().RLock()
	}

	l.lockedItems.Put(itemKey, liv)
}

// Register the lock for a newly created item in our lock list. This is one case
// where we don't check for lock priority as there's no chance that another
// thread is trying to lock this item
func (l *Session) RegisterNewItem(row *TableRow) {
	// Write-lock the row
	row.GetLock().Lock()
	itemKey := lockItemKey{row.GetType(), row.GetKey()}
	itemVal := &lockItemValue{
		row: row,
		fullLock: true,
		count: 1,
	}

	_, ok := l.lockedItems.Get(itemKey)
	if ok {
		l.Panic("Item is already present: " + row.String())
	}

	if l.lockedItems.Empty() {
		l.armFinalizer()
	}
	l.lockedItems.Put(itemKey, itemVal)
}

type byKey []*TableRow

func (s byKey) Len() int {
	return len(s)
}
func (s byKey) Swap(i, j int) {
	s[i], s[j] = s[j], s[i]
}
func (s byKey) Less(i, j int) bool {
	if t1, t2 := s[i].GetType(), s[j].GetType(); t1 != t2 {
		return t1 < t2
	}
	return s[i].GetKey() < s[j].GetKey()
}

// Lock multiple items (potentially of many types) in the correct order to avoid deadlocks
func (l *Session) LockItems(mode LockMode, itemsRaw ...*TableRow) {
	var itemsSorted = make(byKey, 0, len(itemsRaw))
	for _, v := range itemsRaw {
		if v == nil {
			continue
		}
		itemsSorted = append(itemsSorted, v)
	}

	sort.Sort(itemsSorted)
	for _, s := range itemsSorted {
		l.LockItem(s, mode)
	}
}

// Unlock an item, this is a fairly expensive method. Use UnlockAll for a
// much faster alternative
func (l *Session) UnlockRow(item *TableRow) {
	l.UnlockItem(item.GetType(), item.GetKey())
}

func (l *Session) UnlockItem(what LockTarget, key string) {
	itemKey := lockItemKey{what, key}
	value, found := l.lockedItems.Get(itemKey)
	if !found {
		l.Panic("Attempting to unlock item that was not locked: " + itemKey.String())
	}

	curLockEntry := value.(*lockItemValue)
	curLockEntry.count--
	if curLockEntry.count != 0 {
		return
	}

	// Unlock!
	if curLockEntry.fullLock {
		curLockEntry.row.GetLock().Unlock()
	} else {
		curLockEntry.row.GetLock().RUnlock()
	}

	// And remove the lock entry from our list
	l.lockedItems.Remove(itemKey)
	if l.lockedItems.Empty() {
		l.disarmFinalizer()
		l.sendOutNotifies()
	}
}

func (l *Session) UnlockAll() {
	if l.lockedItems.Empty() {
		return
	}

	for i := l.lockedItems.Iterator(); i.Next(); {
		val := i.Value().(*lockItemValue)
		if val.fullLock {
			val.row.GetLock().Unlock()
		} else {
			val.row.GetLock().RUnlock()
		}
	}
	l.lockedItems.Clear()
	l.disarmFinalizer()
	l.sendOutNotifies()
}

func (l *Session) CheckItemsLocked(what LockTarget, keys ...string) {
	for _, key := range keys {
		if key == "" {
			continue
		}
		_, ok := l.lockedItems.Get(lockItemKey{what, key})
		if !ok {
			l.Panic("Item with key " + key + " is not locked in " + string(what))
		}
	}
}

func (l *Session) EnsureAllUnlocked() {
	if !l.lockedItems.Empty() {
		l.Panic("Still have locked items")
	}
}
