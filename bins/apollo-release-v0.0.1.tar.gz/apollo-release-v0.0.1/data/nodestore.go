package data

import (
	"apollo/proto/gen/models"
	"apollo/utils"
	"fmt"
	"github.com/sirupsen/logrus"
	"sync/atomic"
)

const NodeTable = "node"

type QueueNodeCount struct {
	NumNodes       int64
	NumActiveNodes int64
}

type NodeStore struct {
	store KVStore

	mtx utils.SessionedMutex
	NodesByKey    map[string]NodeTableRow
	// Number of nodes for each queue
	CountsByQueue map[string]*QueueNodeCount // TODO: reap counts for dead queues

	// Tasks assigned for each node
	subtasksByNode map[string]*SubtaskWithRetryListValue
}

func NewNodeStore(store KVStore) *NodeStore {
	return &NodeStore{
		store:         store,
		NodesByKey:    make(map[string]NodeTableRow),
		CountsByQueue: make(map[string]*QueueNodeCount),
		subtasksByNode: make(map[string]*SubtaskWithRetryListValue),
	}
}

func (ns *NodeStore) GenerateId() (string, error) {
	nodeId, err := ns.store.GetCounter("node")
	if err != nil {
		return "", err
	}
	return fmt.Sprintf("n-%d", nodeId), nil
}

func (ns *NodeStore) Hydrate(taskStore *TaskStore, sess *Session) error {
	var data []*StoredNode
	err := ns.store.LoadTable(NodeTable, &data)
	if err != nil {
		return NewStoreError("failed hydrate the NodeStore", err)
	}

	for _, t := range data {
		row := NewNodeTableRow(t)
		ns.NodesByKey[t.Key] = row
		sess.RegisterNewItem(row.TableRow)

		if _, ok := ns.CountsByQueue[t.Queue]; !ok {
			ns.CountsByQueue[t.Queue] = &QueueNodeCount{}
		}
		ns.updateNodeCounts(t.Queue, "", t.State)

		stltv := &SubtaskWithRetryListValue{}
		stltv.Store([]SubtaskKeyWithRetry{})
		ns.subtasksByNode[t.Key] = stltv
	}

	// Link the subtasks
	for _, v := range taskStore.subtasks {
		sess.LockItem(v.TableRow, LockModeFull)
		subtask := v.Load()
		if subtask.CurrentAssignment != nil {
			ns.updateSubtask(nil, subtask, sess)
		}
		sess.UnlockRow(v.TableRow)
	}

	return nil
}

func (ns *NodeStore) GetQueueNodeCounts(queue string, sess *Session) (*QueueNodeCount, bool) {
	locked := ns.mtx.ReadLock()
	defer locked.Unlock()

	count, ok := ns.CountsByQueue[queue]
	return count, ok
}

func (ns *NodeStore) updateNodeCounts(queue string, oldState models.NodeStateEnum,
	newState models.NodeStateEnum) {

	//Must be run with locks held
	count, ok := ns.CountsByQueue[queue]
	if !ok {
		panic("Counter not found")
	}

	if newState == models.NodeStateEnumActive && oldState != models.NodeStateEnumActive {
		atomic.AddInt64(&count.NumActiveNodes, 1)
	}
	if newState != models.NodeStateEnumActive && oldState == models.NodeStateEnumActive {
		atomic.AddInt64(&count.NumActiveNodes, -1)
	}
	if oldState == "" && newState != "" {
		atomic.AddInt64(&count.NumNodes, 1)
	}
	if oldState != "" && newState == "" {
		atomic.AddInt64(&count.NumNodes, -1)
	}
}

func (ns *NodeStore) StoreNode(n *StoredNode, sess *Session) error {
	logrus.Infof("Storing new node: %s", n.StringNoPass())
	locked := ns.mtx.Lock()
	defer locked.Unlock()

	if _, ok := ns.NodesByKey[n.Key]; ok {
		return NewStoreError("Node with this key already exists"+n.String(), nil)
	}

	row := NewNodeTableRow(n)
	ns.NodesByKey[n.Key] = row

	if _, ok := ns.CountsByQueue[n.Queue]; !ok {
		ns.CountsByQueue[n.Queue] = &QueueNodeCount{}
	}
	ns.updateNodeCounts(n.Queue,"", n.State)

	list := &SubtaskWithRetryListValue{}
	list.Store([]SubtaskKeyWithRetry{})
	ns.subtasksByNode[n.Key] = list

	sess.RegisterNewItem(row.TableRow)
	locked.Unlock()

	ns.store.StoreValues(NodeTable, []StoredNode{*n})

	return nil
}

func (ns *NodeStore) UpdateNode(updatedNode *StoredNode, sess *Session) {
	key := updatedNode.Key
	sess.CheckItemsLocked(LockNode, key)

	locked := ns.mtx.ReadLock()
	defer locked.Unlock()

	node, ok := ns.NodesByKey[key]
	utils.PanicIf(!ok, "failed to find a node: "+key)

	curNode := node.Load()

	utils.PanicIf(updatedNode.Queue != curNode.Queue,"Bad queue")

	ns.updateNodeCounts(updatedNode.Queue, curNode.State, updatedNode.State)
	node.Store(updatedNode)

	locked.Unlock()
	ns.store.StoreValues(NodeTable, []StoredNode{*updatedNode})
}

func (ns *NodeStore) GetNodeSubtasks(nodeKey string) []SubtaskKeyWithRetry {
	locked := ns.mtx.ReadLock()
	defer locked.Unlock()

	value, ok := ns.subtasksByNode[nodeKey]
	if !ok {
		return nil
	}
	return value.Load()
}

func (ns *NodeStore) GetNodeRow(key string, sess *Session) NodeTableRow {
	if key == "" {
		return NodeTableRow{}
	}
	locked := ns.mtx.ReadLock()
	defer locked.Unlock()

	value, ok := ns.NodesByKey[key]
	if !ok {
		return NodeTableRow{}
	}
	locked.Unlock()
	return value
}

func (ns *NodeStore) GetNode(key string, sess *Session, mode LockMode) *StoredNode {
	value := ns.GetNodeRow(key, sess)
	if value.TableRow == nil {
		return nil
	}
	sess.LockItem(value.TableRow, mode)
	return value.Load()
}

func (ns *NodeStore) MustGetNode(key string, sess *Session, mode LockMode) *StoredNode {
	node := ns.GetNode(key, sess, mode)
	if node == nil {
		utils.CL(sess.Ctx()).Panicf("Node not found: %s", key)
	}
	return node
}

func (ns *NodeStore) ListNodes(IDs []string,
	filter func(node *StoredNode) bool, sess *Session) []*StoredNode {

	locked := ns.mtx.ReadLock()
	defer locked.Unlock()

	if IDs != nil && len(IDs) != 0 {
		var res = make([]*StoredNode, 0, len(IDs))
		for _, k := range IDs {
			node, ok := ns.NodesByKey[k]
			if !ok {
				continue
			}
			storedNode := node.Load()
			if storedNode == nil || (filter != nil && !filter(storedNode)) {
				continue
			}
			res = append(res, storedNode)
		}
		return res
	} else {
		var res = make([]*StoredNode, 0, len(ns.NodesByKey))
		for _, v := range ns.NodesByKey {
			storedNode := v.Load()
			if storedNode == nil || (filter != nil && !filter(storedNode)) {
				continue
			}
			res = append(res, storedNode)
		}
		return res
	}
}

func (ns *NodeStore) DeleteNodeUnlocked(key string, sess *Session) error {
	locked := ns.mtx.Lock()
	defer locked.Unlock()

	curNode, ok := ns.NodesByKey[key]
	if !ok {
		return nil
	}

	node := curNode.Load()
	delete(ns.NodesByKey, key)
	ns.updateNodeCounts(node.Queue, node.State, "")
	curNode.Deleted = true

	locked.Unlock()

	ns.store.DeleteValue(NodeTable, key)
	return nil
}

func (ns *NodeStore) updateSubtask(oldValue *Subtask, newValue *Subtask, sess *Session) {
	if (oldValue==nil || oldValue.CurrentAssignment == nil) &&
		(newValue == nil || newValue.CurrentAssignment == nil) {
		return
	}
	var oldNode, newNode string
	if oldValue != nil && oldValue.CurrentAssignment != nil {
		oldNode = oldValue.CurrentAssignment.AssignedNode
	}
	if newValue != nil && newValue.CurrentAssignment != nil {
		newNode = newValue.CurrentAssignment.AssignedNode
	}
	var oldRetries = int64(-1)
	if oldValue != nil {
		oldRetries = oldValue.RetryNum
	}
	var newRetries = int64(-1)
	if newValue != nil {
		newRetries = newValue.RetryNum
	}

	assignmentChanged := newNode != oldNode || newRetries != oldRetries

	locked := ns.mtx.ReadLock()
	defer locked.Unlock()

	if oldNode != "" && assignmentChanged {
		sess.CheckItemsLocked(LockNode, oldNode)
		sess.AddNotify(NotifySubtaskScheduled, oldNode)

		subtasks := ns.subtasksByNode[oldNode]
		items := subtasks.Load()

		oldKey := SubtaskKeyWithRetry{
			oldValue.GetSubtaskKey(), oldValue.RetryNum}
		// Create a copy of the subtask list without this subtask
		itemsCopy := make([]SubtaskKeyWithRetry, 0, len(items)-1)
		for _, i := range items {
			if i != oldKey {
				itemsCopy = append(itemsCopy, i)
			}
		}
		subtasks.Store(itemsCopy)
	}

	if newNode != "" && assignmentChanged {
		sess.CheckItemsLocked(LockNode, newNode)
		if oldNode != newNode {
			sess.AddNotify(NotifySubtaskScheduled, newNode)
		}

		subtasks := ns.subtasksByNode[newNode]
		items := subtasks.Load()
		itemsCopy := append([]SubtaskKeyWithRetry{}, items...)
		itemsCopy = append(itemsCopy, SubtaskKeyWithRetry{
			newValue.GetSubtaskKey(), newValue.RetryNum})
		subtasks.Store(itemsCopy)
	}
}
