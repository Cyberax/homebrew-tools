package data

import (
	"encoding/json"
	"sync"
)

const ConfigStoreTable = "config_store"

type ConfigData struct {
	Key string
	Value string
}

func (c *ConfigData) String() string {
	bytes, _ := json.Marshal(c)
	return string(bytes)
}

type ConfigStore struct {
	store KVStore
	mutex sync.RWMutex

	configsByKey map[string]ConfigData
}

func NewConfigStore(store KVStore) *ConfigStore {
	return &ConfigStore{
		store: store,
		configsByKey: make(map[string]ConfigData),
	}
}

func (ts *ConfigStore) StoreConfig(key string, value interface{}) error {
	var config = ConfigData{Key: key}
	valueStr, err := json.Marshal(value)
	if err != nil {
		return err
	}
	config.Value = string(valueStr)

	ts.store.StoreValues(ConfigStoreTable, []ConfigData{config})

	ts.mutex.Lock()
	defer ts.mutex.Unlock()
	ts.configsByKey[key] = config
	return nil
}

func (ts *ConfigStore) GetConfigByKey(key string, place interface{}) (error, bool) {
	ts.mutex.RLock()
	defer ts.mutex.RUnlock()
	config, ok := ts.configsByKey[key]
	if !ok {
		return nil, ok
	}
	return json.Unmarshal([]byte(config.Value), place), true
}

func (ts *ConfigStore) Hydrate() error {
	var data []ConfigData

	err := ts.store.LoadTable(ConfigStoreTable, &data)
	if err != nil {
		return NewStoreError("failed hydrate the ConfigStore", err)
	}

	ts.mutex.Lock()
	defer ts.mutex.Unlock()

	for _, t := range data {
		ts.configsByKey[t.Key] = t
	}

	return nil
}
