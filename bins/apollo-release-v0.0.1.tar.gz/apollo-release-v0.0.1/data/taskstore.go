package data

import (
	"apollo/proto/gen/models"
	"apollo/utils"
	"fmt"
	"sync/atomic"
)

const TaskTable = "task"
const SubtaskTable = "subtask"

const TaskCancelledReason = "TaskCancelled"
const SubtasksFailedReason = "MaxFailedCountExceeded"


type TaskStore struct {
	store     KVStore

	mtx utils.SessionedMutex

	tasksByKey map[string]TaskTableRow
	subtasks map[SubtaskKey]SubtaskTableRow
	subtasksByTask map[string]map[int64]SubtaskTableRow

	// Number of pending/active/done/failed subtasks for a task
	subtaskCounts map[string]*SubtaskCounts // key is task

	pendingReverseDeps map[SubtaskKey]WaitingTaskListValue
	tasksByState map[models.TaskStateEnum]map[string]bool

	tasksByIdemToken map[string]TaskTableRow

	nodeStore *NodeStore
}

type SubtaskCounts struct {
	Pending int64
	Active int64
	Done int64
	Failed int64
}

func (c *SubtaskCounts) AtomicCopy() SubtaskCounts {
	return SubtaskCounts{
		Pending: atomic.LoadInt64(&c.Pending),
		Active: atomic.LoadInt64(&c.Active),
		Done: atomic.LoadInt64(&c.Done),
		Failed: atomic.LoadInt64(&c.Failed),
	}
}

func (c *SubtaskCounts) IsFinished() bool {
	return c.Active == 0 && c.Pending == 0
}

type WaitingTask struct {
	TaskKey string
	NumPending int64
}

// A manual specialization of atomic Value for []*WaitingTask
type WaitingTaskListValue struct {
	atomic.Value
}

func (s *WaitingTaskListValue) Load() []*WaitingTask {
	return s.Value.Load().([]*WaitingTask)
}

func (s *WaitingTaskListValue) Store(v []*WaitingTask) {
	s.Value.Store(v)
}

func NewTaskStore(store KVStore, nodeStore *NodeStore) *TaskStore {
	return &TaskStore{
		store: store,
		tasksByKey: make(map[string]TaskTableRow),
		subtasks: make(map[SubtaskKey]SubtaskTableRow),
		subtasksByTask: make(map[string]map[int64]SubtaskTableRow),
		subtaskCounts: make(map[string]*SubtaskCounts),
		tasksByIdemToken: make(map[string]TaskTableRow),
		nodeStore: nodeStore,
	}
}

func (ts *TaskStore) Hydrate(sess *Session) error {
	var data []*StoredTask
	err := ts.store.LoadTable(TaskTable, &data)
	if err != nil {
		return NewStoreError("failed hydrate the TaskStore", err)
	}

	var subtasks []*Subtask
	err = ts.store.LoadTable(SubtaskTable, &subtasks)
	if err != nil {
		return NewStoreError("failed hydrate the SubTaskStore", err)
	}

	// Load the initial stored subtasks
	for _, t := range subtasks {
		key := MustParseSubtaskKey(t.Key)
		tVal := NewSubtaskTableRow(t)
		ts.subtasks[key] = tVal
		if _, ok := ts.subtasksByTask[key.ParentKey]; !ok {
			ts.subtasksByTask[key.ParentKey] = make(map[int64]SubtaskTableRow)
		}
		ts.subtasksByTask[key.ParentKey][key.Index] = tVal
	}

	for _, t := range data {
		tVal := NewTaskTableRow(t)
		ts.tasksByKey[t.Key] = tVal
		if t.IdempotencyToken != "" {
			ts.tasksByIdemToken[t.IdempotencyToken] = tVal
		}
		ts.fillInSubtasks(t, sess)
	}

	return nil
}

// Update the subtask pending and active counts
func (ts *TaskStore) updateTaskCounts(oldTask *Subtask, newTask *Subtask) {
	key := MustParseSubtaskKey(newTask.Key).ParentKey
	cnt, ok := ts.subtaskCounts[key]
	if !ok {
		cnt = &SubtaskCounts{}
		ts.subtaskCounts[key] = cnt
	}

	updater := func(task *Subtask, delta int64) int64 {
		switch task.Status {
		case models.SubtaskStateEnumWaiting:
			return atomic.AddInt64(&cnt.Pending, delta)
		case models.SubtaskStateEnumDispatched:
			return atomic.AddInt64(&cnt.Active, delta)
		case models.SubtaskStateEnumPulling:
			return atomic.AddInt64(&cnt.Active, delta)
		case models.SubtaskStateEnumCreated:
			return atomic.AddInt64(&cnt.Active, delta)
		case models.SubtaskStateEnumStarted:
			return atomic.AddInt64(&cnt.Active, delta)
		case models.SubtaskStateEnumDone:
			return atomic.AddInt64(&cnt.Done, delta)
		case models.SubtaskStateEnumFailed:
			return atomic.AddInt64(&cnt.Failed, delta)
		default:
			panic("Unknown state: " + task.Status)
		}
	}

	// Remove the old task from the counts
	if oldTask != nil {
		val := updater(oldTask, -1)
		utils.PanicIf(val < 0, fmt.Sprintf("Decreasing counter past zero for %s", key))
	}
	updater(newTask, 1)
}

func (ts *TaskStore) GetTaskCounts(taskKey string) SubtaskCounts {
	locked := ts.mtx.ReadLock()
	defer locked.Unlock()

	cnt := ts.subtaskCounts[taskKey]
	return cnt.AtomicCopy()
}

// Fill in the subtasks for the parent task. We don't store them in the
// database immediately, they are instead persisted on demand after the first
// change.
func (ts *TaskStore) fillInSubtasks(task *StoredTask, locker *Session) {
	// Must be invoked with the full task locks
	if _, ok := ts.subtasksByTask[task.Key]; !ok {
		ts.subtasksByTask[task.Key] = make(map[int64]SubtaskTableRow)
	}

	for i := task.StartArrayIndex; i < task.EndArrayIndex; i++ {
		subtaskKey := SubtaskKey{ParentKey: task.Key, Index: i}

		subtaskRow, ok := ts.subtasksByTask[task.Key][i]
		if !ok {
			newSubTask := NewSubtaskTableRow(&Subtask{
				Key: subtaskKey.String(),
				SubtaskInfo: models.SubtaskInfo{
					Status: models.SubtaskStateEnumWaiting,
					PriorAssignments: make(map[string]models.SubtaskAssignment),
				}})
			ts.subtasksByTask[task.Key][i] = newSubTask
			ts.subtasks[subtaskKey] = newSubTask
			subtaskRow = newSubTask
		}

		ts.updateTaskCounts(nil, subtaskRow.Load())
	}
}

// Store the new task. The database write is performed without holding
// any locks, so it's the responsibility of the caller to make
// sure that we can't store the task with a same ID twice.
func (ts *TaskStore) StoreTask(task *StoredTask, sess *Session) error {
	sess.L().Infof("Storing new task: %s", task.String())
	locked := ts.mtx.Lock()
	defer locked.Unlock()

	row := NewTaskTableRow(task)

	_, ok := ts.tasksByKey[task.Key]
	if ok {
		return RowAlreadyExistsError
	}
	if task.IdempotencyToken != "" {
		_, ok := ts.tasksByIdemToken[task.IdempotencyToken]
		if ok {
			return IdempotencyTokenAlreadyExistsError
		}
		ts.tasksByIdemToken[task.IdempotencyToken] = row
	}

	ts.tasksByKey[task.Key] = row
	sess.RegisterNewItem(row.TableRow)
	ts.fillInSubtasks(task, sess)

	locked.Unlock()

	ts.store.StoreValues(TaskTable, []StoredTask{*task})

	return nil
}

func (ts *TaskStore) GetSubtaskAndCheckRetry(key SubtaskKeyWithRetry,
	sess *Session, mode LockMode) *Subtask {
	subtask := ts.GetSubtask(key.SKey, sess, mode)
	if subtask.RetryNum != key.RetryNum {
		return nil
	}
	return subtask
}

func (ts *TaskStore) GetSubtask(key SubtaskKey, sess *Session, mode LockMode) *Subtask {
	locked := ts.mtx.ReadLock()
	defer locked.Unlock()

	value, ok := ts.subtasks[key]
	if !ok {
		return nil
	}
	locked.Unlock()

	sess.LockItem(value.TableRow, mode)
	return value.Load()
}

// This is a BYOL (bring-your-own-lock) method. The subtask must be locked
// externally.
func (ts *TaskStore) UpdateSubtask(subtask *Subtask, sess *Session) {
	sess.CheckItemsLocked(LockSubtask, subtask.Key)

	locked := ts.mtx.ReadLock()
	defer locked.Unlock()

	curValue := ts.subtasks[subtask.GetSubtaskKey()]
	subtaskValue := curValue.Load()
	if !subtaskValue.Exited()  && subtask.Exited() {
		sess.AddNotify(NotifySubtaskFinished, subtask.Key)
	}

	// Update the pending task counts
	ts.updateTaskCounts(subtaskValue, subtask)

	locked.Unlock()

	// Update indexes in the node store
	ts.nodeStore.updateSubtask(subtaskValue, subtask, sess)

	curValue.Store(subtask)
	ts.store.StoreValues(SubtaskTable, []*Subtask{subtask})
}

func (ts *TaskStore) UpdateTask(updated *StoredTask, sess *Session) {
	sess.CheckItemsLocked(LockTask, updated.Key)

	locked := ts.mtx.ReadLock()
	defer locked.Unlock()

	curValue := ts.tasksByKey[updated.Key]
	locked.Unlock()

	if curValue.Load().IdempotencyToken != updated.IdempotencyToken {
		panic("can't update the idempotency token, task="+updated.Key)
	}

	curValue.Store(updated)
	ts.store.StoreValues(TaskTable, []*StoredTask{updated})
}

type TaskResult struct {
	Task *StoredTask
	Subtasks map[int64]*Subtask
	Counts SubtaskCounts
}

func (ts *TaskStore) GetTaskWithSubtasks(ID string, locker *Session) *TaskResult {
	tasks := ts.ListTasks([]string{ID}, true, nil)
	if len(tasks) == 0 {
		return nil
	}
	return &tasks[0]
}

func (ts *TaskStore) GetTaskByIdemToken(token string, locker *Session, mode LockMode) *StoredTask {
	locked := ts.mtx.ReadLock()
	defer locked.Unlock()

	task, ok := ts.tasksByIdemToken[token]
	if !ok {
		return nil
	}
	locked.Unlock()

	locker.LockItem(task.TableRow, mode)
	return task.Load()
}

func (ts *TaskStore) GetTask(key string, locker *Session, mode LockMode) *StoredTask {
	locked := ts.mtx.ReadLock()
	defer locked.Unlock()

	task, ok := ts.tasksByKey[key]
	if !ok {
		return nil
	}
	locked.Unlock()

	locker.LockItem(task.TableRow, mode)
	return task.Load()
}

func (ts *TaskStore) getSubtasks(task *StoredTask, returnSubtasks bool) map[int64]*Subtask {
	// Must be invoked with overall read lock held
	if !returnSubtasks {
		return nil
	}

	subtasks := make(map[int64]*Subtask)
	for idx, v := range ts.subtasksByTask[task.Key] {
		val := v.Load()
		if val != nil {
			subtasks[idx] = val
		}
	}
	return subtasks
}

func (ts *TaskStore) ListTasks(IDs []string, returnSubtasks bool,
	filter func(*StoredTask, SubtaskCounts) bool) []TaskResult {

	locked := ts.mtx.ReadLock()
	defer locked.Unlock()

	if IDs != nil && len(IDs) != 0 {
		var res = make([]TaskResult, 0, len(IDs))
		for _, k := range IDs {
			task, ok := ts.tasksByKey[k]
			if !ok {
				continue
			}
			taskCur := task.Load()
			counts := ts.subtaskCounts[k].AtomicCopy()
			if taskCur != nil && (filter == nil || filter(taskCur, counts)) {
				res = append(res, TaskResult{
					Task:     taskCur,
					Subtasks: ts.getSubtasks(taskCur, returnSubtasks),
					Counts:   counts,
				})
			}
		}
		return res
	} else {
		var res = make([]TaskResult, 0, len(ts.tasksByKey))
		for _, v := range ts.tasksByKey {
			vCur := v.Load()
			counts := ts.subtaskCounts[v.Key].AtomicCopy()
			if vCur != nil && (filter == nil || filter(vCur, counts)) {
				res = append(res, TaskResult{
					Task: vCur,
					Subtasks: ts.getSubtasks(vCur, returnSubtasks),
					Counts: counts,
				})
			}
		}
		return res
	}
}

func IsTaskFinished(task *StoredTask) bool {
	return task.OverallStatus == models.TaskStateEnumSucceeded ||
		task.OverallStatus == models.TaskStateEnumFailed
}
