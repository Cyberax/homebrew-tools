package data

import (
	"apollo/utils"
	"github.com/sirupsen/logrus"
)

const QueueTable = "queue"

type QueueStore struct {
	store KVStore

	mtx utils.SessionedMutex
	queuesByName map[string]QueueTableRow
}

func NewQueueStore(store KVStore) *QueueStore {
	return &QueueStore{
		store: store,
		queuesByName: make(map[string]QueueTableRow),
	}
}

func (ts *QueueStore) Hydrate(locker *Session) error {
	var data []*StoredQueue
	err := ts.store.LoadTable(QueueTable, &data)
	if err != nil {
		return NewStoreError("failed hydrate the QueueStore", err)
	}

	for _, t := range data {
		ts.queuesByName[t.Key] = NewQueueTableRow(t)
	}

	return nil
}

func (ts *QueueStore) StoreNewQueue(q *StoredQueue, locker *Session) error {
	lock := ts.mtx.Lock()
	defer lock.Unlock()

	_, ok := ts.queuesByName[q.Key]
	if ok {
		return RowAlreadyExistsError
	}

	row := NewQueueTableRow(q)
	ts.queuesByName[q.Key] = row
	locker.RegisterNewItem(row.TableRow)

	lock.Unlock() // Allow map to be mutated, the item still remains locked

	logrus.Infof("Storing new queue: %s", q.StringNoPass())
	ts.store.StoreValues(QueueTable, []StoredQueue{*q})

	return nil
}

func (ts *QueueStore) UpdateQueue(q *StoredQueue, locker *Session) {
	locker.CheckItemsLocked(LockQueue, q.Key)

	locked := ts.mtx.Lock()
	defer locked.Unlock()

	row, ok := ts.queuesByName[q.Key]
	if !ok || row.Deleted {
		panic("Item went away")
	}

	row.Store(q)
	locked.Unlock()

	logrus.Infof("Updating queue: %s", q.StringNoPass())
	ts.store.StoreValues(QueueTable, []StoredQueue{*q})
}

func (ts *QueueStore) GetQueue(key string, sess *Session, lockMode LockMode) *StoredQueue {
	locked := ts.mtx.ReadLock()
	defer locked.Unlock()

	queue, ok := ts.queuesByName[key]
	if !ok {
		return nil
	}
	sess.LockItem(queue.TableRow, lockMode)
	return queue.Load()
}

func (ts *QueueStore) ListQueues(IDs []string, locker *Session) []*StoredQueue {
	locked := ts.mtx.ReadLock()
	defer locked.Unlock()

	if IDs != nil && len(IDs) != 0 {
		var res = make([]*StoredQueue, 0, len(IDs))
		for _, k := range IDs {
			queue, ok := ts.queuesByName[k]
			if !ok {
				continue
			}
			sq := queue.Load()
			if sq != nil {
				res = append(res, sq)
			}
		}
		return res
	} else {
		var res = make([]*StoredQueue, 0, len(ts.queuesByName))
		for _, v := range ts.queuesByName {
			sq := v.Load()
			if sq != nil {
				res = append(res, sq)
			}
		}
		return res
	}
}

func (ts *QueueStore) DeleteQueue(queue string, locker *Session) {
	locker.CheckItemsLocked(LockQueue, queue)

	locked := ts.mtx.Lock()
	defer locked.Unlock()

	row, ok := ts.queuesByName[queue]
	if !ok {
		panic("Item went away")
	}

	row.Deleted = true
	delete(ts.queuesByName, queue)

	locked.Unlock()

	ts.store.DeleteValue(QueueTable, queue)
}
