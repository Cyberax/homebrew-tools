package data

import (
	"apollo/proto/gen/models"
	"context"
	"github.com/stretchr/testify/assert"
	"reflect"
	"testing"
)

func makeTaskStore() (*TaskStore, *NodeStore, *LockStore) {
	store := NewFakeMemStore()

	//noinspection GoUnhandledErrorResult
	store.InitSchema(map[string]int64{
		ConfigStoreTable: 5,
		QueueTable:       5,
		NodeTable:        5,
		TaskTable:        5,
		SubtaskTable:     5,
	})
	locker := NewLockStore()
	nodeStore := NewNodeStore(store)
	taskStore := NewTaskStore(store, nodeStore)
	ctx := context.Background()
	sess := locker.Session(ctx)
	defer sess.UnlockAll()

	//noinspection GoUnhandledErrorResult
	nodeStore.StoreNode(&StoredNode{Key: "n-1", Queue: "q-1"}, sess)
	//noinspection GoUnhandledErrorResult
	nodeStore.StoreNode(&StoredNode{Key: "n-2", Queue: "q-1"}, sess)
	// Add the task and wait for it to start
	ts := models.TaskStruct{StartArrayIndex: 0, EndArrayIndex: 2,}
	st := StoredTask{TaskStruct: ts, Key: "t-1"}
	//noinspection GoUnhandledErrorResult
	taskStore.StoreTask(&st, sess)

	return taskStore, nodeStore, locker
}

func TestUpdateTaskCounts(t *testing.T) {
	taskStore, nodeStore, locker := makeTaskStore()

	// Check that the pending counts are good
	counts := taskStore.GetTaskCounts("t-1")
	assert.Equal(t, SubtaskCounts{2, 0,0,0}, counts)

	updater := func(key string, subUpdater func(subtask *Subtask)) {
		sess := locker.Session(context.Background())
		defer sess.UnlockAll()
		nodeStore.GetNode("n-1", sess, LockModeFull)
		st := taskStore.GetSubtask(MustParseSubtaskKey(key), sess, LockModeFull)
		updated := *st
		subUpdater(&updated)
		taskStore.UpdateSubtask(&updated, sess)
	}

	// Mark one subtask as active
	updater("t-1.1", func(subtask *Subtask) {
		subtask.Status = models.SubtaskStateEnumPulling
		subtask.CurrentAssignment = &models.SubtaskAssignment{AssignedNode: "n-1"}
	})

	counts = taskStore.GetTaskCounts("t-1")
	assert.Equal(t, SubtaskCounts{1, 1,0,0}, counts)

	updater("t-1.0", func(subtask *Subtask) {
		subtask.Status = models.SubtaskStateEnumFailed
	})

	counts = taskStore.GetTaskCounts("t-1")
	assert.Equal(t, SubtaskCounts{0, 1,0,1}, counts)

	updater("t-1.1", func(subtask *Subtask) {
		subtask.Status = models.SubtaskStateEnumDone
		subtask.CurrentAssignment.ExitError = ""
		subtask.CurrentAssignment.Exited = true
		subtask.PushCurrentAssignmentToHistory()
		subtask.CurrentAssignment = nil
	})
	counts = taskStore.GetTaskCounts("t-1")
	assert.Equal(t, SubtaskCounts{0, 0,1,1}, counts)

	updater("t-1.0", func(subtask *Subtask) {
		subtask.Status = models.SubtaskStateEnumWaiting
	})
	counts = taskStore.GetTaskCounts("t-1")
	assert.Equal(t, SubtaskCounts{1, 0,1,0}, counts)
}

func TestKeyParse(t *testing.T) {
	key, b, err := ParseSubtaskKey("subtask.123")
	assert.Equal(t, "subtask", key.ParentKey)
	assert.Equal(t,int64(123), key.Index)
	assert.True(t, b)
	assert.Nil(t, err)

	key, b, err = ParseSubtaskKey("subtask123")
	assert.Equal(t, "subtask123", key.ParentKey)
	assert.Equal(t,int64(0), key.Index)
	assert.False(t, b)
	assert.Nil(t, err)

	_, _, err = ParseSubtaskKey("subtask.badbad")
	assert.Error(t, err)
}


func TestWhitelist(t *testing.T) {
	store := NewFakeMemStore()

	//noinspection GoUnhandledErrorResult
	store.InitSchema(map[string]int64{
		WhitelistTable:   1,
	})

	whls := NewWhitelistStore(store)
	assert.NoError(t, whls.Hydrate())
	whls.AddPreconfigured("123")
	whls.AddWhitelist("345")
	whls.AddWhitelist("123")
	whls.AddWhitelist("781")
	assert.NoError(t, whls.DeleteWhitelist("781"))
	assert.Errorf(t, whls.DeleteWhitelist("123"),
		"can't delete a static whitelist entry")

	whls2 := NewWhitelistStore(store)
	assert.NoError(t, whls2.Hydrate())
	whls2.AddPreconfigured("123")
	assert.True(t, reflect.DeepEqual(whls.GetList(), whls2.GetList()))

	assert.True(t, whls.IsWhitelisted("123"))
	assert.True(t, whls.IsWhitelisted("345"))
	assert.False(t, whls.IsWhitelisted("781"))
}
