package data

import (
	"apollo/proto/gen/models"
	"context"
	"github.com/sirupsen/logrus"
	"github.com/stretchr/testify/assert"
	"runtime"
	"strings"
	"sync"
	"testing"
)

type DataTestContext struct {
	locker *LockStore
	queueStore *QueueStore
	nodeStore *NodeStore
	taskStore *TaskStore
}

func makeTestContext() *DataTestContext {
	store := NewFakeMemStore()
	//noinspection GoUnhandledErrorResult
	store.InitSchema(map[string]int64{
		ConfigStoreTable: 5,
		QueueTable:       5,
		NodeTable:        5,
		TaskTable:        5,
		SubtaskTable:     5,
	})

	locker := NewLockStore()
	queueStore := NewQueueStore(store)
	nodeStore := NewNodeStore(store)
	taskStore := NewTaskStore(store, nodeStore)
	ctx := context.Background()
	sess := locker.Session(ctx)
	defer sess.UnlockAll()

	_ = queueStore.StoreNewQueue(&StoredQueue{Key: "q-1"}, sess)

	//noinspection GoUnhandledErrorResult
	nodeStore.StoreNode(&StoredNode{Key: "n-1", Queue: "q-1"}, sess)
	//noinspection GoUnhandledErrorResult
	nodeStore.StoreNode(&StoredNode{Key: "n-2", Queue: "q-1"}, sess)

	// Add the task and wait for it to start
	cmdLine := []string{"/bin/sh", "-c", "echo Hello; sleep 5; echo World; sleep 5; exit 1;"}
	ts := models.TaskStruct{Queue: "test-queue", DockerImageID: "alpine:3.7",
		Cmdline: cmdLine, ExpectedRAMMb: 10, MaxRAMMb: 12,
		Tags: map[string]string{"test-run": "true"},
		StartArrayIndex: 0, EndArrayIndex: 2,}
	st := StoredTask{TaskStruct: ts, Key: "t-1",}
	//noinspection GoUnhandledErrorResult
	taskStore.StoreTask(&st, sess)

	return &DataTestContext{
		locker: locker,
		queueStore: queueStore,
		nodeStore: nodeStore,
		taskStore: taskStore,
	}
}

// Test that the subtasksByNode index is correctly updated when tasks are updated
// and that the messages are correctly sent out
func TestNodeStoreIndexes(t *testing.T) {
	tc := makeTestContext()
	// No subtasks are yet assigned
	assert.Equal(t, 0,len(tc.nodeStore.subtasksByNode["n-1"].Load()))

	ctx := context.Background()

	ch := make(chan string, 2)
	tc.locker.Subscribe(NotifySubtaskScheduled, "n-1", ch, false)
	tc.locker.Subscribe(NotifySubtaskScheduled, "n-2", ch, false)
	defer tc.locker.Unsubscribe(NotifySubtaskScheduled,"n-1", ch)
	defer tc.locker.Unsubscribe(NotifySubtaskScheduled,"n-2", ch)

	var withUpdate = func(updater func (subtask Subtask) Subtask) {
		sess := tc.locker.Session(ctx)
		defer sess.UnlockAll()

		tc.nodeStore.GetNode("n-1", sess, LockModeFull)
		tc.nodeStore.GetNode("n-2", sess, LockModeFull)
		subKey := MustParseSubtaskKey("t-1.1")
		st := tc.taskStore.GetSubtask(subKey, sess, LockModeFull)

		cpy := updater(*st)
		tc.taskStore.UpdateSubtask(&cpy, sess)
	}

	// The assigned node update causes index recalculation and sends out
	// messages
	withUpdate(func(subtask Subtask) Subtask {
		subtask.CurrentAssignment = &models.SubtaskAssignment{AssignedNode: "n-1"}
		return subtask
	})

	// The notification must have fired
	assert.Equal(t, <-ch, "n-1")
	// And we now have the subtask within the node store - the indexes are updated
	assert.Equal(t, SubtaskKeyWithRetry{MustParseSubtaskKey("t-1.1"),0},
		tc.nodeStore.subtasksByNode["n-1"].Load()[0])

	// Updating other fields does NOT cause index recomputation and messages
	withUpdate(func(subtask Subtask) Subtask {
		subtask.CurrentAssignment.ContainerID = "123"
		return subtask
	})
	select {
	case <-ch:
		t.Fatal("Unexpected message")
	default:
	}

	withUpdate(func(subtask Subtask) Subtask {
		subtask.RetryNum = 2
		return subtask
	})
	// Retry updates must cause index recomputation and events
	assert.Equal(t, <-ch, "n-1")
	assert.Equal(t, SubtaskKeyWithRetry{MustParseSubtaskKey("t-1.1"),2},
		tc.nodeStore.subtasksByNode["n-1"].Load()[0])

	// Check node assignment change
	withUpdate(func(subtask Subtask) Subtask {
		subtask.CurrentAssignment = &models.SubtaskAssignment{AssignedNode: "n-2"}
		return subtask
	})
	assert.Equal(t, <-ch, "n-1")
	assert.Equal(t, <-ch, "n-2")
	assert.Equal(t, SubtaskKeyWithRetry{MustParseSubtaskKey("t-1.1"),2},
		tc.nodeStore.subtasksByNode["n-2"].Load()[0])

	// And finally check de-assignment
	withUpdate(func(subtask Subtask) Subtask {
		subtask.CurrentAssignment = nil
		return subtask
	})
	assert.Equal(t, <-ch, "n-2")
	assert.Equal(t,len(tc.nodeStore.subtasksByNode["n-2"].Load()), 0)
}

func TestGoodLockUsage(t *testing.T) {
	locker := NewLockStore()

	// Subtask locked before the node
	sess := locker.Session(context.Background())

	row := NewQueueTableRow(&StoredQueue{Key: "q-1"}).TableRow
	row1 := NewQueueTableRow(&StoredQueue{Key: "q-9"}).TableRow
	row2 := NewQueueTableRow(&StoredQueue{Key: "q-10"}).TableRow

	sess.LockItems(LockModeFull, row2, row, row1)
	sess.LockItems(LockModeFull, row)

	assert.Equal(t, 3, sess.lockedItems.Size())

	sess.UnlockRow(row)
	sess.UnlockRow(row2)
	sess.UnlockItem(LockQueue, row1.Key)
	sess.UnlockRow(row)
	sess.EnsureAllUnlocked()
}

func TestBadLockUsage(t *testing.T) {
	locker := NewLockStore()
	sess := locker.Session(context.Background())

	// Disable error messages
	lvl := logrus.GetLevel()
	logrus.SetLevel(0)
	defer logrus.SetLevel(lvl)

	// Node locked before the queue - wrong order
	sess = locker.Session(context.Background())
	assert.Panics(t, func() {
		rowNode := NewNodeTableRow(&StoredNode{Key: "n-1"}).TableRow
		rowQueue := NewQueueTableRow(&StoredQueue{Key: "q-9"}).TableRow
		sess.LockItem(rowNode, LockModeRead)
		sess.LockItem(rowQueue, LockModeRead)
	})

	// Unlocks are not balanced
	sess = locker.Session(context.Background())
	assert.Panics(t, func() {
		rowNode := NewNodeTableRow(&StoredNode{Key: "n-1"}).TableRow
		rowQueue := NewQueueTableRow(&StoredQueue{Key: "q-9"}).TableRow
		sess.LockItem(rowNode, LockModeRead)
		sess.UnlockRow(rowQueue)
	})

	// Trying to upgrade a lock - this doesn't work
	sess = locker.Session(context.Background())
	assert.Panics(t, func() {
		rowNode := NewNodeTableRow(&StoredNode{Key: "n-1"}).TableRow
		sess.LockItem(rowNode, LockModeRead)
		sess.LockItem(rowNode, LockModeFull)
	})

	// Check forgotten unlocks
	sess = locker.Session(context.Background())
	assert.Panics(t, func() {
		rowNode := NewNodeTableRow(&StoredNode{Key: "n-1"}).TableRow
		sess.LockItem(rowNode, LockModeFull)
		sess.EnsureAllUnlocked() // Lingering locks
	})

	// Check forgotten unlocks - finalizer version
	func() {
		rowNode := NewNodeTableRow(&StoredNode{Key: "n-1"}).TableRow
		sess := locker.Session(context.Background())
		sess.LockItem(rowNode, LockModeFull)
		sess = nil
	}()
	errCh := make(chan string, 1)
	Panicker = func(err string) {
		errCh <- err
	}
	runtime.GC()
	runtime.Gosched() // Allow finalizers to run
	err := <-errCh
	assert.True(t, strings.Index(err, "There are still unlocked items left: {node, key=n-1, deleted=false}") == 0)
	Panicker = DefaultPanicker
}

func TestLockerNotifications(t *testing.T) {
	locker := NewLockStore()

	row := NewNodeTableRow(&StoredNode{Key: "n-1", Queue: "q-1"}).TableRow

	n1Chan := make(chan string, 2)
	locker.Subscribe(NotifySubtaskScheduled, "n-1", n1Chan, false)
	starChan := make(chan string, 10)
	locker.Subscribe(NotifySubtaskScheduled, NotifyForAllKeys, starChan, false)

	assert.Equal(t, 2, len(locker.notifyHandlers[NotifySubtaskScheduled]))

	sess := locker.Session(context.Background())
	sess.LockItem(row, LockModeFull)
	sess.AddNotify(NotifySubtaskScheduled, "n-1")
	sess.AddNotify(NotifySubtaskScheduled, "n-2")
	checkChanEmpty(n1Chan, t)
	checkChanEmpty(starChan, t)
	sess.UnlockAll() // Now notifies are send

	assert.Equal(t,"n-1", <-n1Chan)
	checkChanEmpty(n1Chan, t)
	assert.Equal(t, "n-1", <-starChan)
	assert.Equal(t, "n-2", <-starChan)
	checkChanEmpty(starChan, t)

	// No more messages after unsubscription
	locker.Unsubscribe(NotifySubtaskScheduled, "n-1", n1Chan)
	sess.LockItem(row, LockModeRead)
	sess.AddNotify(NotifySubtaskScheduled, "n-1")
	sess.AddNotify(NotifySubtaskScheduled, "n-2")
	sess.UnlockRow(row) // Now notifies are send
	checkChanEmpty(n1Chan, t)
}

func TestReliableMsgSend(t *testing.T) {
	locker := NewLockStore()

	row := NewNodeTableRow(&StoredNode{Key: "n-1", Queue: "q-1"}).TableRow

	// Unreliable delivery into a non-buffered channel never succeeds
	n1Chan := make(chan string)
	locker.Subscribe(NotifySubtaskScheduled, "n-1", n1Chan, false)

	sess := locker.Session(context.Background())
	sess.RegisterNewItem(row)
	sess.AddNotify(NotifySubtaskScheduled, "n-1")
	sess.AddNotify(NotifySubtaskScheduled, "n-2")
	sess.UnlockRow(row) // Now notifies are send
	checkChanEmpty(n1Chan, t) // Unreliable notifications are dropped

	// Now do the same with reliable notifies - the notifier will block until
	// everything is sent out.
	locker.Unsubscribe(NotifySubtaskScheduled, "n-1", n1Chan)

	n1Chan = make(chan string)
	locker.Subscribe(NotifySubtaskScheduled, "n-1", n1Chan, true)

	wg := sync.WaitGroup{}
	wg.Add(1)
	go func() {
		<-n1Chan
		wg.Done()
	}()

	sess.LockItem(row, LockModeRead)
	sess.AddNotify(NotifySubtaskScheduled, "n-1")
	sess.AddNotify(NotifySubtaskScheduled, "n-2")
	sess.UnlockAll()
	wg.Wait()
}

func checkChanEmpty(ch chan string, t *testing.T) {
	select {
	case d, ok := <-ch:
		if ok {
			t.Fatal("Unexpected data in channel: " + d)
		}
	default:
	}
}
