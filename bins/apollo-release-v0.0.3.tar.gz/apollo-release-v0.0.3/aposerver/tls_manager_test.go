package aposerver

import (
	"apollo/data"
	"apollo/utils"
	"crypto/tls"
	"github.com/sirupsen/logrus"
	"github.com/stretchr/testify/assert"
	"io/ioutil"
	"os"
	"testing"
)

func TestMain(m *testing.M) {
	logrus.SetLevel(logrus.FatalLevel)
	os.Exit(m.Run())
}

func TestTlsManager(t *testing.T) {
	store := data.NewFakeMemStore()
	_ = store.InitSchema(map[string]int64{
		data.ConfigStoreTable: 5,
	})

	configStore := data.NewConfigStore(store)

	manager := NewTlsManager()

	err := manager.Init(configStore, "somehost", 123, "auto",
		"auto", "self")
	assert.NoError(t, err)
	assert.True(t, manager.TLSData.KeyData != "")
	assert.True(t, manager.TLSData.CertData != "")

	// Now create a second TLS manager - it should re-use the stored certificate
	manager2 := NewTlsManager()
	err = manager2.Init(configStore, "somehost", 123, "auto",
		"","self")
	assert.NoError(t, err)

	_, err = tls.X509KeyPair([]byte(manager2.TLSData.CertData), []byte(manager2.TLSData.KeyData))
	assert.NoError(t, err)

	// The files must be equal
	assert.Equal(t, manager.TLSData.CertData, manager2.TLSData.CertData)
	assert.Equal(t, manager.TLSData.KeyData, manager2.TLSData.KeyData)

	// Make sure we handle errors correctly
	_ = configStore.StoreConfig("ServerCert", []utils.TlsData{{
		CertData: string("haha"), KeyData: string("bad")}})
	manager3 := NewTlsManager()
	err = manager3.Init(configStore, "somehost", 123, "auto",
		"", "self")
	assert.Error(t, err)
}

func TestUrlProbing(t *testing.T) {
	store := data.NewFakeMemStore()
	_ = store.InitSchema(map[string]int64{data.ConfigStoreTable: 5})

	configStore := data.NewConfigStore(store)

	manager := NewTlsManager()
	tlsData := utils.MakeCACert()

	cer, err := tls.X509KeyPair([]byte(tlsData.CertData), []byte(tlsData.KeyData))
	assert.NoError(t, err)

	config := &tls.Config{Certificates: []tls.Certificate{cer}}
	ln, err := tls.Listen("tcp", ":23413", config)
	assert.NoError(t, err)
	//noinspection GoUnhandledErrorResult
	defer ln.Close()

	go func() {
		conn, err := ln.Accept()
		assert.NoError(t, err)
		_, _ = conn.Write([]byte("Hello\n"))
		//noinspection GoUnhandledErrorResult
		defer conn.Close()
	}()

	err = manager.Init(configStore, "somehost", 123, "auto",
		"auto", "localhost:23413")
	assert.NoError(t, err)

	assert.Equal(t, getCertBody([]byte(tlsData.CertData)),
		manager.OurCert)
}

func TestTlsNonAuto(t *testing.T) {
	manager := NewTlsManager()
	tlsData := utils.MakeCACert()

	file, err := ioutil.TempFile("", "tlscert")
	assert.NoError(t, err)
	_ = file.Close()
	_ = ioutil.WriteFile(file.Name(), []byte(tlsData.CertData), 0600)
	//noinspection GoUnhandledErrorResult
	defer os.Remove(file.Name())

	keyFile, err := ioutil.TempFile("", "tlskey")
	assert.NoError(t, err)
	_ = keyFile.Close()
	_ = ioutil.WriteFile(keyFile.Name(), []byte(tlsData.KeyData), 0600)
	//noinspection GoUnhandledErrorResult
	defer os.Remove(keyFile.Name())

	err = manager.Init(nil, "somehost", 123, file.Name(),
		keyFile.Name(), "self")
	assert.NoError(t, err)

	assert.Equal(t, "somehost", manager.TLSHost)
	assert.Equal(t, 123, manager.TLSPort)
	assert.Equal(t, tlsData.CertData, manager.TLSData.CertData)
	assert.Equal(t, tlsData.KeyData, manager.TLSData.KeyData)

	assert.Equal(t, getCertBody([]byte(tlsData.CertData)),
		manager.OurCert)
}
