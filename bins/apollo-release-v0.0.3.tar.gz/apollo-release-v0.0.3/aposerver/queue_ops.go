package aposerver

import (
	"apollo/data"
	"apollo/proto/gen/restapi/operations/queue"
	"apollo/utils"
	"encoding/base64"
	"fmt"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/ecr"
	"github.com/aws/aws-sdk-go-v2/service/s3"
	"github.com/go-openapi/runtime/middleware"
	"github.com/go-openapi/strfmt"
	"net/url"
	"strings"
	"time"
)

type PutQueueProcessor struct {
	aws aws.Config
	sess *data.Session
	store *data.QueueStore
	principal string
	params queue.PutQueueParams
}


func (l *PutQueueProcessor) Enact() middleware.Responder {
	defer l.sess.UnlockAll()
	l.sess.L().Infof("Creating a queue %s", l.params.Queue.Name)

	st := data.StoredQueue {
		Key: l.params.Queue.Name,
		Queue: l.params.Queue,
		SubmittedOn: utils.FromTime(time.Now()),
		SubmittedBy: l.principal,

		DisabledMessage: "",
		Disabled: false,
	}

	if l.params.Queue.ExchangeBucket == "" || l.params.Queue.QueueRegion == "" {
		return SendErrorS(l.sess.Ctx(), "You haven't specified a correct S3 bucket and region")
	}

	err := l.ensureBucketExists()
	if err != nil {
		return SendError(l.sess.Ctx(), err)
	}

	if l.params.Queue.IsAwsEcrRepo {
		u, err := url.Parse(l.params.Queue.DockerRepository)
		if err != nil {
			return SendErrorS(l.sess.Ctx(), "Failed to parse the queue URL: " +
				err.Error())
		}
		if u.Path == "/" || u.Path == "" {
			return SendErrorS(l.sess.Ctx(), "AWS ECR repository URL include path")
		}

		login, pass, validUntil, err := tryEcrQueueLogin(l.aws,
			l.params.Queue.DockerRepository)
		if err != nil {
			l.sess.L().Infof("Failed to obtain the token for queue: %s, err %s",
				st.Key, err.Error())
			return SendErrorS(l.sess.Ctx(), "Failed to initialize the queue: " +
				err.Error())
		}

		l.sess.L().Info("Obtained token for queue: "+st.Key)
		st.EcrTokenValidUntil = strfmt.DateTime(validUntil)
		st.DockerLogin = login
		st.DockerPassword = pass
	}
	// TODO: moar validation?

	curQueue := l.store.GetQueue(st.Key, l.sess, data.LockModeFull)
	if curQueue == nil {
		if l.store.StoreNewQueue(&st, l.sess) == data.RowAlreadyExistsError {
			return SendErrorS(l.sess.Ctx(), "Raced queue creation, retry if needed")
		}
	} else {
		l.store.UpdateQueue(&st, l.sess)
	}

	return queue.NewPutQueueOK().WithPayload(&queue.PutQueueOKBody{
		QueueName: l.params.Queue.Name,
	})
}

func (l *PutQueueProcessor) ensureBucketExists() error {
	regionalClient := l.aws.Copy()
	regionalClient.Region = l.params.Queue.QueueRegion
	s3Conn := s3.New(l.aws)

	bucketUrl, err := url.Parse(l.params.Queue.ExchangeBucket)
	if err != nil {
		return err
	}

	output, err := s3Conn.GetBucketLocationRequest(&s3.GetBucketLocationInput{
		Bucket: aws.String(bucketUrl.Host),
	}).Send()
	if err != nil && err.(s3.RequestFailure).Code() != "NoSuchBucket"{
		return err
	}
	if output == nil {
		// No bucket, create it
		bucket := &s3.CreateBucketInput{
			Bucket: aws.String(bucketUrl.Host),
			CreateBucketConfiguration: &s3.CreateBucketConfiguration{
				LocationConstraint: s3.BucketLocationConstraint(l.params.Queue.QueueRegion),
			},
		}
		_, err = s3Conn.CreateBucketRequest(bucket).Send()
		if err != nil {
			return err
		}
		return nil
	}

	if string(output.LocationConstraint) != l.params.Queue.QueueRegion {
		return fmt.Errorf("bucket region differs from queue region")
	}

	_, _ = s3Conn.DeletePublicAccessBlockRequest(&s3.DeletePublicAccessBlockInput{
		Bucket: aws.String(bucketUrl.Host),
	}).Send()

	return nil
}


type ListQueueProcessor struct {
	sess *data.Session
	store *data.QueueStore
	taskStore *data.TaskStore
	nodeStore *data.NodeStore
	params queue.GetQueueListParams
}

func (l *ListQueueProcessor) Enact() middleware.Responder {
	var queues []*data.StoredQueue
	if l.params.Queue != nil {
		queues = l.store.ListQueues([]string{*l.params.Queue}, l.sess)
	} else {
		queues = l.store.ListQueues(nil, l.sess)
	}

	var resArr []*queue.GetQueueListOKBodyItems0
	for _, q := range queues {
		count, _ := l.nodeStore.GetQueueNodeCounts(q.Name, l.sess)
		if count == nil {
			count = &data.QueueNodeCount{}
		}

		resArr = append(resArr, &queue.GetQueueListOKBodyItems0{
			ActiveHostCount: count.NumActiveNodes,
			HostCount: count.NumNodes,
			QueueInfo: q.Queue,
			DisabledMessage: q.DisabledMessage,
		})
	}

	return queue.NewGetQueueListOK().WithPayload(resArr)
}


type DeleteQueueProcessor struct {
	sess *data.Session
	store *data.QueueStore
	taskStore *data.TaskStore
	params queue.DeleteQueueParams
}

func (l *DeleteQueueProcessor) Enact() middleware.Responder {
	l.sess.L().Infof("Deleting a queue %s", l.params.Queue)

	// LockTable the task taskStore to check that we don't have any tasks with this
	// queue name.
	q := l.store.GetQueue(l.params.Queue, l.sess, data.LockModeFull)
	if q == nil {
		return SendError(l.sess.Ctx(), fmt.Errorf("queue %s is missing", l.params.Queue))
	}

	tasks := l.taskStore.ListTasks(nil, false,
		func(task *data.StoredTask, counts data.SubtaskCounts) bool {
		return task.Queue == l.params.Queue
	})
	if len(tasks) != 0 {
		return SendError(l.sess.Ctx(), fmt.Errorf("queue %s is still in use", l.params.Queue))
	}

	// No new tasks can be created since we're holding the queue write lock
	l.store.DeleteQueue(l.params.Queue, l.sess)

	return queue.NewDeleteQueueOK()
}

func UpdateEcrQueues(aws aws.Config, queues *data.QueueStore, sess *data.Session) {
	sess.L().Info("Updating ECR queue credentials")

	for _, q := range queues.ListQueues([]string{}, sess) {
		if !q.IsAwsEcrRepo {
			continue
		}
		// Check if a queue needs token update
		validUntil := time.Time(q.EcrTokenValidUntil)
		if validUntil.After(time.Now().Add(1*time.Hour)) {
			continue
		}
		sess.L().Info("Renewing credentials for queue: "+q.Key)

		// Do the AWS call while we're not holding any locks
		login, pass, validUntil, err := tryEcrQueueLogin(aws, q.DockerRepository)
		if err != nil {
			sess.L().Infof("Failed to update queue: %s, it is disabled", q.Key)
		}
		// Now update the queue with this token
		tryUpdateQueueToken(q.Key, login, pass, validUntil, err, queues, sess)
		sess.L().Infof("Queue %s, is now authorized until %s", q.Key, validUntil)
	}
	sess.L().Info("Done updating ECR queue credentials")
}

func tryUpdateQueueToken(key string, login string, pass string, validUntil time.Time,
	errorMsg error, store *data.QueueStore, sess *data.Session) {

	oldQueue := store.GetQueue(key, sess, data.LockModeFull)
	if oldQueue == nil {
		return
	}
	defer sess.UnlockItem(data.LockQueue, key)

	updatedQueue := *oldQueue
	updatedQueue.IsAwsEcrRepo = true

	if errorMsg != nil {
		updatedQueue.Disabled = true
		updatedQueue.DisabledMessage = errorMsg.Error()
	} else {
		updatedQueue.Disabled = false
		updatedQueue.DisabledMessage = ""

		updatedQueue.DockerLogin = login
		updatedQueue.DockerPassword = pass
		updatedQueue.EcrTokenValidUntil = strfmt.DateTime(validUntil)
	}

	store.UpdateQueue(&updatedQueue, sess)
}

func tryEcrQueueLogin(aws aws.Config, queueUrl string) (string, string, time.Time, error) {
	regionalClient := aws.Copy()

	// Parse the queue URL to extract the ECR region name
	// Example: https://158005755667.dkr.ecr.us-west-2.amazonaws.com
	splits := strings.Split(queueUrl, ".")
	if len(splits) < 5 {
		return "", "", time.Time{}, fmt.Errorf("can't parse Amazon ECR URL: %s", queueUrl)
	}
	regionalClient.Region = splits[3]

	regId := strings.Replace(splits[0], "https://", "", 1)

	ecrClient := ecr.New(regionalClient)

	res, err := ecrClient.GetAuthorizationTokenRequest(&ecr.GetAuthorizationTokenInput{
		RegistryIds: []string{regId},
	}).Send()

	if err != nil {
		return "", "", time.Time{}, err
	}

	token := res.AuthorizationData[0]

	bytes, err := base64.StdEncoding.DecodeString(*token.AuthorizationToken)
	if err != nil {
		return "", "", time.Time{}, err
	}

	splits = strings.SplitN(string(bytes), ":", 2)
	if len(splits) != 2 {
		return "", "", time.Time{}, fmt.Errorf("bad token")
	}

	return splits[0], splits[1], *token.ExpiresAt, nil
}
