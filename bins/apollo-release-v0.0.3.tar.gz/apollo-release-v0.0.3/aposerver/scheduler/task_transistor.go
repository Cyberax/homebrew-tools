package scheduler

import (
	"apollo/data"
	"apollo/proto/gen/models"
	. "apollo/utils"
	"context"
	"github.com/sirupsen/logrus"
	"time"
)

type Transistor struct {
	ctx    context.Context
	cancel context.CancelFunc

	locker *data.LockStore
	ts     *data.TaskStore
}

func NewTransistor(ts *data.TaskStore, locker *data.LockStore) *Transistor {

	ctx, cancel := context.WithCancel(context.Background())
	ctx = SaveLoggerToContext(ctx, logrus.StandardLogger())
	AddLoggerFields(ctx, logrus.Fields{"Transistor": "1"})

	res := Transistor{
		ctx:             ctx,
		cancel:          cancel,
		locker:          locker,
		ts:              ts,
	}
	return &res
}

// Scan tasks during the startup for any possible tasks that still need
// state transitions.
func (s *Transistor) startupScanTasks() {
	sess := s.locker.Session(s.ctx)
	defer sess.UnlockAll()

	tasks := s.ts.ListTasks(nil, false, nil)
	for _, t := range tasks {
		s.checkTaskState(t.Task.Key, sess)
	}
}

func (s *Transistor) processSubtaskCompletion(subtaskKey data.SubtaskKey) {
	sess := s.locker.Session(s.ctx)
	defer sess.UnlockAll()
	s.checkTaskState(subtaskKey.ParentKey, sess)
}

func (s *Transistor) checkTaskState(taskKey string, sess *data.Session) {
	task := s.ts.GetTask(taskKey, sess, data.LockModeNone)

	if data.IsTaskFinished(task) {
		return
	}

	maxFail := task.Job.MaxFailedCount
	counts := s.ts.GetTaskCounts(task.Key)

	//TODO: add job-level counts
	if maxFail != -1 && counts.Failed > maxFail {
		// Fail the whole task
		CL(s.ctx).Infof("Failing task %s because the maximum number %d "+
			"of failed subtasks is exceeded", task.Key, maxFail)
		FailTask(s.ts, task.Key, data.SubtasksFailedReason, sess)
	} else if counts.IsFinished() {
		CL(s.ctx).Infof("Task is succeeded: %s", task.Key)
		s.succeedTask(task.Key, sess)
	}
}

func (s *Transistor) succeedTask(key string, sess *data.Session) {
	CL(s.ctx).Infof("Task %s has succeeded", key)

	task := *s.ts.GetTask(key, sess, data.LockModeFull)
	if data.IsTaskFinished(&task) {
		return
	}

	task.OverallStatus = models.TaskStateEnumSucceeded

	// TODO: update the overall performance stats

	sess.AddNotify(data.NotifyTaskDone, task.Key)
	s.ts.UpdateTask(&task, sess)
}

func (s *Transistor) Cancel() {
	s.cancel()
}

func (s *Transistor) RunTransistorLoop() {
	CL(s.ctx).Infof("Starting the task state transistor loop")

	// Check for any stragglers from the previous run
	s.startupScanTasks()

	subtaskNotify := make(chan string, 10)

	// Subscribe to messages now
	s.locker.Subscribe(data.NotifySubtaskFinished, data.NotifyForAllKeys,
		subtaskNotify, true)
	defer s.locker.Unsubscribe(data.NotifySubtaskFinished, data.NotifyForAllKeys, subtaskNotify)

	ticker := time.NewTicker(1000 * time.Millisecond)
	defer ticker.Stop()

loop:
	for ; ; {
		select {
		case key, ok := <-subtaskNotify:
			if !ok {
				CL(s.ctx).Infof("Subtask event channel is closed")
				break loop
			}
			subtaskKey := data.MustParseSubtaskKey(key)
			s.processSubtaskCompletion(subtaskKey)
		case <-ticker.C:
		case <-s.ctx.Done():
			CL(s.ctx).Infof("Interrupt signal received, transistor is stopping")
			break loop
		}
	}
}
