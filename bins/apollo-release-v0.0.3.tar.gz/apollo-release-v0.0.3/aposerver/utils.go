package aposerver

import (
	"apollo/proto/gen/models"
	"apollo/utils"
	"context"
	"github.com/go-openapi/runtime"
	"github.com/go-openapi/runtime/middleware"
	"net/http"
)

type errorResponder struct {
	err models.Error
}

func (e *errorResponder) WriteResponse(rw http.ResponseWriter, producer runtime.Producer) {
	rw.WriteHeader(int(e.err.Code))
	if err := producer.Produce(rw, &e.err); err != nil {
		panic(err) // let the recovery middleware deal with this
	}
}

func SendErrorS(ctx context.Context, error string) middleware.Responder {
	return &errorResponder{err: models.Error{
		Code: http.StatusInternalServerError, Message: error,
		RequestID: utils.GetReqIdFromContext(ctx)}}
}

func SendError(ctx context.Context, err error) middleware.Responder {
	return &errorResponder{err: models.Error{
			Code: http.StatusInternalServerError, Message: err.Error(),
			RequestID: utils.GetReqIdFromContext(ctx)}}
}

func SendErrorSC(ctx context.Context, code int64, error string) middleware.Responder {
	return &errorResponder{err: models.Error{
		Code: code, Message: error,
		RequestID: utils.GetReqIdFromContext(ctx)}}
}

func SendErrorSCE(ctx context.Context, code int64, err error) middleware.Responder {
	return &errorResponder{err: models.Error{
		Code: code, Message: err.Error(),
		RequestID: utils.GetReqIdFromContext(ctx)}}
}
