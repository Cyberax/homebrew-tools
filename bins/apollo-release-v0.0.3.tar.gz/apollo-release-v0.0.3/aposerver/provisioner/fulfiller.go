package provisioner

import (
	"apollo/data"
	"context"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/ec2"
	"github.com/pkg/errors"
)

type QueueFulfiller struct {
	ctx context.Context
	awsConn aws.Config

	queueKey string
	stores data.Stores
}

func (q *QueueFulfiller) CheckCurrentCapacity() {
	ec2Conn := ec2.New(q.awsConn)

	dir := ec2Conn.DescribeInstancesRequest(&ec2.DescribeInstancesInput{
		Filters: []ec2.Filter{
			{Name: aws.String("idempotency-token"),
				Values: []string{""}}},
	})
	_, _ = dir.Send()
}

func (q *QueueFulfiller) RunSpotInstance() error {
	sess := q.stores.LS.Session(q.ctx)
	defer sess.UnlockAll()

	qData := q.stores.QS.GetQueue(q.queueKey, sess, data.LockModeNone)
	if qData == nil {
		return errors.New("Queue was deleted")
	}

	overrides := make([]ec2.LaunchTemplateOverrides, len(qData.InstanceTypes))
	for i, qd := range qData.InstanceTypes {
		overrides[i] = ec2.LaunchTemplateOverrides{
			InstanceType: ec2.InstanceType(qd),
			WeightedCapacity: aws.Float64(1.0),
		}
	}

	ec2Conn := ec2.New(q.awsConn)

	req := ec2Conn.RequestSpotFleetRequest(&ec2.RequestSpotFleetInput{
		SpotFleetRequestConfig: &ec2.SpotFleetRequestConfigData {
			TargetCapacity: aws.Int64(1),
			LaunchTemplateConfigs: []ec2.LaunchTemplateConfig {{
				LaunchTemplateSpecification: &ec2.FleetLaunchTemplateSpecification{
					LaunchTemplateId: aws.String(qData.LaunchTemplateID),
				},
				Overrides: overrides,
			}},
			IamFleetRole: aws.String("arn:aws:iam::158005755667:role/aws-ec2-spot-fleet-tagging-role"),
			Type: ec2.FleetTypeInstant,
		},
	})
	output, err := req.Send()
	if err != nil {
		return err
	}
	println(output.SpotFleetRequestId)

	return nil
}
