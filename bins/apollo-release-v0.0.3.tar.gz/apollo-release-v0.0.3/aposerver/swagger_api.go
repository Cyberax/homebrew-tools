package aposerver

//noinspection GoInvalidPackageImport
import (
	"apollo/aposerver/acceptor"
	"apollo/aposerver/statik"
	"apollo/data"
	"context"
	"net"
	"strconv"
	"sync"

	// The squashed Swagger UI
	_ "apollo/aposerver/statik"
	"apollo/proto/gen/restapi"
	"apollo/proto/gen/restapi/operations"
	. "apollo/utils"
	"github.com/go-openapi/errors"
	"github.com/go-openapi/loads"
	"github.com/go-openapi/runtime/middleware"
	"github.com/rakyll/statik/fs"
	"github.com/sirupsen/logrus"
	"log"
	"net/http"
	"strings"
	"time"
)

type PrefixedFS struct {
	Prefix string
	Delegate http.FileSystem
}

func (p *PrefixedFS) Open(name string) (http.File, error) {
	return p.Delegate.Open(p.Prefix + "/" + name)
}

func uiMiddleware(ctx *ServerContext, handler http.Handler) http.Handler {
	statikFS, err := fs.New()
	if err != nil {
		log.Fatal(err)
	}
	uiRoot := &PrefixedFS{Prefix: "/swagger-ui", Delegate: statikFS}
	staticFiles := http.StripPrefix("/public", http.FileServer(uiRoot))

	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		// Shortcut helpers for swagger-ui
		if r.URL.Path == "/" || r.URL.Path == "" {
			http.Redirect(w, r, "/public/", http.StatusMovedPermanently);
			return
		}
		if r.URL.Path == "/public/" || r.URL.Path == "/public/index.html" {
			http.ServeContent(w, r, "index.html", time.Now(),
				strings.NewReader(statik.ApplicationIndex))
			return
		}
		if strings.Index(r.URL.Path, "/public") == 0 {
			staticFiles.ServeHTTP(w, r)
			return
		}

		// Add the logger to the request
		r = prepareContext(r)
		// Keep track of the request ID
		reqId := r.Header.Get("X-Request-Id")
		if reqId != "" {
			w.Header().Add("X-Request-Id", reqId)
		}
		// Delegate to the next handler
		handler.ServeHTTP(w, r)
	})
}

// Create a contextual logger with the request ID field set
func prepareContext(r *http.Request) *http.Request {
	reqId := r.Header.Get("X-Request-Id")
	context := SaveLoggerToContext(r.Context(), logrus.StandardLogger())
	if reqId != "" {
		AddLoggerFields(context, logrus.Fields{"RequestID": reqId})
	}
	context = SaveReqIdToContext(context, reqId)
	return r.WithContext(context)
}

func serverError(request *http.Request, e error, writer http.ResponseWriter) {
	CL(request.Context()).Infof("Failed to run operation: %s", e.Error())
	errors.ServeError(writer, request, e)
}

func makeAPI(ctx *ServerContext) *operations.ApolloAPI {
	// load embedded swagger file
	swaggerSpec, err := loads.Analyzed(restapi.SwaggerJSON, "")
	if err != nil {
		log.Fatalln(err)
	}

	// create new service API
	api := operations.NewApolloAPI(swaggerSpec)

	// Wire up handlers
	WireUpHandlers(ctx, api)

	// Hook up error response handler. TODO: add metrics
	api.ServeError = func(writer http.ResponseWriter, request *http.Request, e error) {
		serverError(request, e, writer)
	}

	// Set up the middleware (Swagger UI, auth, web interface routing)
	api.Middleware = func(builder middleware.Builder) http.Handler {
		return uiMiddleware(ctx, api.Context().APIHandler(builder))
	}

	api.APIKeyAuthAuth = func(token string) (interface{}, error) {
		// Authenticate the request
		authToken, err := ctx.TokenManager.DecryptToken(token)
		if err != nil {
			return nil, err
		}
		if authToken.Expires != data.NeverExpires && authToken.Expires.ToTime().Before(time.Now()) {
			return nil, errors.Unauthenticated("https")
		}
		return *authToken, nil
	}

	return api
}

func makeServer(sc *ServerContext, api *operations.ApolloAPI) *acceptor.Server {
	ctx := context.Background()
	ctx = SaveLoggerToContext(ctx, logrus.StandardLogger())

	return acceptor.NewServer(ctx, api, sc.ConnectionChannel, sc.TlsManager.TLSData.CertData,
		sc.TlsManager.TLSData.KeyData)
}

func makeListener(sc *ServerContext) (net.Listener, error) {
	addr := net.JoinHostPort(sc.TlsManager.TLSHost, strconv.Itoa(sc.TlsManager.TLSPort))
	listener, e := net.Listen("tcp", addr)
	return listener, e
}

func RunServer(ctx *ServerContext) error {
	wg := sync.WaitGroup{}
	defer wg.Wait()

	api := makeAPI(ctx)

	server := makeServer(ctx, api)
	defer func() {
		_ = server.Shutdown()
	}()

	listener, err := makeListener(ctx)
	if err != nil {
		return err
	}
	//noinspection GoUnhandledErrorResult
	defer listener.Close()
	exitChan := make(chan bool)
	defer close(exitChan)
	go func() {
		for ;; {
			conn, e := listener.Accept()
			if e != nil {
				CL(server.ServerCtx).Errorf("Failed to accept a connection: %v", err)
				return
			}
			select {
			case <-exitChan:
				return
			case ctx.ConnectionChannel <- conn:
			}
		}
	}()

	// Run the background tasks once
	DoRunBackgroundTasks(ctx)

	// Start the background reapers
	wg.Add(1)
	stopChannel := RunBackgroundTasks(ctx)
	defer func() {
		defer wg.Done()
		stopChannel <- true
	}()

	// Run the node minder
	wg.Add(1)
	go func() {
		defer wg.Done()
		ctx.Herder.RunLoop()
		logrus.Info("Heder completed")
	}()
	defer func() {
		ctx.Herder.Cancel()
	}()

	// Run the task transistor
	wg.Add(1)
	go func() {
		defer wg.Done()
		ctx.Transistor.RunTransistorLoop()
		logrus.Info("Transistor completed")
	}()
	defer func() {
		ctx.Transistor.Cancel()
	}()

	// Run the task scheduler
	wg.Add(1)
	go func() {
		defer wg.Done()
		ctx.Scheduler.RunSchedulerLoop()
		logrus.Info("Scheduled completed")

	}()
	defer func() {
		ctx.Scheduler.Cancel()
	}()

	// serve API
	if err := server.Serve(); err != nil {
		logrus.Info("Server returned error")
		return err
	}
	logrus.Info("Server completed")
	return nil
}
