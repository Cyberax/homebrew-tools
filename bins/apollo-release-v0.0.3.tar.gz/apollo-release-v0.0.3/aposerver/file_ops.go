package aposerver

import (
	"apollo/data"
	"apollo/proto/gen/models"
	"apollo/proto/gen/restapi/operations/files"
	"fmt"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/s3"
	"github.com/go-openapi/runtime/middleware"
	"net/url"
	"path"
	"strings"
	"sync"
	"time"
)

type PutFileProcessor struct {
	aws aws.Config
	sess *data.Session
	store *data.TaskStore
	queueStore *data.QueueStore
	params files.PutFilesParams
}

func (l *PutFileProcessor) Enact() middleware.Responder {
	defer l.sess.UnlockAll()
	l.sess.L().Infof("Saving files %v", l.params.FilesData)

	parsedUrl, region, err := getTaskS3Path(l.params.TaskID, l.store, l.queueStore)
	if err != nil {
		return SendError(l.sess.Ctx(), err)
	}

	config := l.aws.Copy()
	config.Region = region
	s3Conn := s3.New(config)

	var urls []string
	var errors []error
	var mtx sync.Mutex
	var wg sync.WaitGroup

	for _, fileData := range l.params.FilesData {
		//fileData.FileName
		// Make a pre-signed S3 url for the file
		if strings.Index(fileData.FileName, "/") != -1 {
			return SendErrorS(l.sess.Ctx(), "File name is invalid: "+fileData.FileName)
		}

		wg.Add(1)
		go func(fileData models.FileInfoEntry) {
			defer wg.Done()
			presigned, err := s3Conn.PutObjectRequest(&s3.PutObjectInput{
				Bucket: aws.String(parsedUrl.Host),
				Key:    aws.String(parsedUrl.Path + fileData.FileName),
			}).Presign(1 * time.Hour)

			mtx.Lock()
			defer mtx.Unlock()
			if err != nil {
				errors = append(errors, err)
			} else {
				urls = append(urls, presigned)
			}
		}(fileData)
	}

	wg.Wait()
	if errors != nil {
		return SendError(l.sess.Ctx(), errors[0])
	}

	return files.NewPutFilesOK().WithPayload(urls)
}

func getTaskS3Path(taskId string, store *data.TaskStore,
	queueStore *data.QueueStore) (*url.URL, string, error) {

	task := store.GetTask(taskId, nil, data.LockModeNone)
	if task.IdempotencyToken == "" {
		return nil, "", fmt.Errorf("task's token is empty")
	}
	queue := queueStore.GetQueue(task.Queue, nil, data.LockModeNone)
	if queue == nil {
		return nil, "", fmt.Errorf("queue has disappeared")
	}

	parsedUrl, err := url.Parse(queue.ExchangeBucket)
	if err != nil {
		return nil, "", err
	}
	if !strings.HasSuffix(parsedUrl.Path, "/") && parsedUrl.Path != "" {
		parsedUrl.Path += "/"
	}
	parsedUrl.Path += task.IdempotencyToken + "/"

	if parsedUrl.Path[0] == '/' {
		parsedUrl.Path = parsedUrl.Path[1:]
	}

	return parsedUrl, queue.QueueRegion, nil
}

type ListFileProcessor struct {
	aws aws.Config
	sess *data.Session
	store *data.TaskStore
	queueStore *data.QueueStore
	params files.GetFilesListParams
}

func (l *ListFileProcessor) Enact() middleware.Responder {
	defer l.sess.UnlockAll()
	l.sess.L().Infof("Listing files for %s", l.params.TaskID)

	parsedUrl, region, err := getTaskS3Path(l.params.TaskID, l.store, l.queueStore)
	if err != nil {
		return SendError(l.sess.Ctx(), err)
	}

	config := l.aws.Copy()
	config.Region = region
	s3Conn := s3.New(config)

	var urls models.FileInfoList
	var token *string
	for ;; {
		output, err := s3Conn.ListObjectsV2Request(&s3.ListObjectsV2Input{
			Bucket:            aws.String(parsedUrl.Host),
			Delimiter:         aws.String("/"),
			Prefix:            aws.String(parsedUrl.Path),
			ContinuationToken: token,
		}).Send()
		if err != nil {
			return SendError(l.sess.Ctx(), err)
		}

		for _, obj := range output.Contents {
			_, fileName := path.Split(*obj.Key)
			urls = append(urls, models.FileInfoEntry{FileName: fileName, FileSize: *obj.Size})
		}

		token = output.ContinuationToken
		if token == nil {
			break
		}
	}

	return files.NewGetFilesListOK().WithPayload(urls)
}

type ExposeFileProcessor struct {
	aws aws.Config
	sess *data.Session
	store *data.TaskStore
	queueStore *data.QueueStore
	params files.PutFilesExposureParams
}

func (l *ExposeFileProcessor) Enact() middleware.Responder {
	defer l.sess.UnlockAll()
	l.sess.L().Infof("Exposing files for %s", l.params.TaskID)

	parsedUrl, region, err := getTaskS3Path(l.params.TaskID, l.store, l.queueStore)
	if err != nil {
		return SendError(l.sess.Ctx(), err)
	}

	config := l.aws.Copy()
	config.Region = region
	s3Conn := s3.New(config)

	var urls []string
	for _, fl := range l.params.Files {
		req := &s3.PutObjectAclInput{
			Bucket: aws.String(parsedUrl.Host),
			Key:    aws.String(parsedUrl.Path + fl),
			ACL:    s3.ObjectCannedACLPublicRead,
		}
		_, err := s3Conn.PutObjectAclRequest(req).Send()
		if err != nil {
			return SendError(l.sess.Ctx(), err)
		}
		entry := fmt.Sprintf("https://s3-%s.amazonaws.com/%s/%s",
			region, parsedUrl.Host, parsedUrl.Path+fl)
		urls = append(urls, entry)
	}

	return files.NewPutFilesExposureOK().WithPayload(urls)
}

type GetFileProcessor struct {
	aws aws.Config
	sess *data.Session
	store *data.TaskStore
	queueStore *data.QueueStore
	params files.GetFilesParams
}

func (l *GetFileProcessor) Enact() middleware.Responder {
	defer l.sess.UnlockAll()
	l.sess.L().Infof("Reading files from %s", l.params.TaskID)

	parsedUrl, region, err := getTaskS3Path(l.params.TaskID, l.store, l.queueStore)
	if err != nil {
		return SendError(l.sess.Ctx(), err)
	}

	config := l.aws.Copy()
	config.Region = region
	s3Conn := s3.New(config)

	var urls []string
	var errors []error
	var mtx sync.Mutex
	var wg sync.WaitGroup

	for _, fileName := range l.params.Files {
		// Make a pre-signed S3 url for the file
		if strings.Index(fileName, "/") != -1 {
			return SendErrorS(l.sess.Ctx(), "File name is invalid: "+fileName)
		}

		wg.Add(1)
		go func(fileName string) {
			defer wg.Done()
			presigned, err := s3Conn.GetObjectRequest(&s3.GetObjectInput{
				Bucket: aws.String(parsedUrl.Host),
				Key:    aws.String(parsedUrl.Path + fileName),
			}).Presign(1 * time.Hour)

			mtx.Lock()
			defer mtx.Unlock()
			if err != nil {
				errors = append(errors, err)
			} else {
				urls = append(urls, presigned)
			}
		}(fileName)
	}

	wg.Wait()
	if errors != nil {
		return SendError(l.sess.Ctx(), errors[0])
	}

	return files.NewGetFilesOK().WithPayload(urls)
}

type DeleteFileProcessor struct {
	aws aws.Config
	sess *data.Session
	store *data.TaskStore
	queueStore *data.QueueStore
	params files.DeleteFilesParams
}

func (l *DeleteFileProcessor) Enact() middleware.Responder {
	defer l.sess.UnlockAll()
	l.sess.L().Infof("Delete files for %s", l.params.TaskID)

	parsedUrl, region, err := getTaskS3Path(l.params.TaskID, l.store, l.queueStore)
	if err != nil {
		return SendError(l.sess.Ctx(), err)
	}

	config := l.aws.Copy()
	config.Region = region
	s3Conn := s3.New(config)

	for _, fl := range l.params.Files {
		_, err := s3Conn.DeleteObjectRequest(&s3.DeleteObjectInput{
			Bucket: aws.String(parsedUrl.Host),
			Key:    aws.String(parsedUrl.Path + fl),
		}).Send()
		if err != nil {
			return SendError(l.sess.Ctx(), err)
		}
	}

	return files.NewPutFilesExposureOK()
}
