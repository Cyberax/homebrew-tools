package parasite

import (
	"apollo/proto/gen/models"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"io/ioutil"
	"log"
	"strconv"
	"strings"
	"time"
)

const PollTime = 5 * time.Second

type CpuLoad struct {
	notFirstTime bool
	user, niced, system, idle float64
}

var lastLoad CpuLoad

func RunStatsLoop(ctx context.Context, writer io.Writer) {
	ticker := time.NewTicker(PollTime)
	defer ticker.Stop()

	var firstRun = make(chan bool, 1)
	firstRun <- true

	for ;; {
		select {
		case <- ctx.Done():
			return
		case <- ticker.C:
			break
		case <- firstRun:
			break
		}
		var err error

		ni := models.NodeInfo{}
		ni.UptimeSeconds, ni.UptimeSecondsIDLE, err = readUptime()
		if err != nil {
			printErr(err)
			continue
		}

		ni.CPU, err = readCPU()
		if err != nil {
			printErr(err)
			continue
		}

		ni.RAM, err = readRAM()
		if err != nil {
			printErr(err)
			continue
		}

		bytes, err := json.Marshal(&ni)
		if err != nil {
			printErr(err)
			continue
		}

		_, _ = writer.Write([]byte(string(bytes)+"\n"))
	}

}

func readUptime() (int64, int64, error) {
	bytes, err := ioutil.ReadFile("/proc/uptime")
	if err != nil {
		return 0,0,err
	}
	var totalSec, idleSec float64
	_, _ = fmt.Sscanf(string(bytes), "%f %f", &totalSec, &idleSec)
	return int64(totalSec),int64(idleSec),nil
}

func readCPU() (models.NodeInfoCPU, error) {
	res := models.NodeInfoCPU{}

	bytes, err := ioutil.ReadFile("/proc/stat")
	if err != nil {
		return res, err
	}
	var curLoad = CpuLoad{notFirstTime: true}
	var cpuNum string
	_, _ = fmt.Sscanf(string(bytes), "%s %f %f %f %f", &cpuNum, &curLoad.user,
		&curLoad.niced, &curLoad.system, &curLoad.idle)

	if lastLoad.notFirstTime {
		res.AggregateCPULoad = ((curLoad.user + curLoad.niced + curLoad.system) -
			(lastLoad.user + lastLoad.niced + lastLoad.system)) /
			((curLoad.user + curLoad.niced + curLoad.system + curLoad.idle) -
				(lastLoad.user + lastLoad.niced + lastLoad.system + lastLoad.idle))
	} else {
		res.AggregateCPULoad = 0.0001
	}
	lastLoad = curLoad

	bytes, err = ioutil.ReadFile("/proc/cpuinfo")
	if err != nil {
		return res, err
	}

	res.CPUCount = int64(strings.Count(string(bytes), "processor	:"))

	return res, nil
}

func readRAM() (models.NodeInfoRAM, error) {
	res := models.NodeInfoRAM{}
	bytes, err := ioutil.ReadFile("/proc/meminfo")
	if err != nil {
		return res, err
	}

	var memValues = make(map[string]int64)
	for _, val := range strings.Split(string(bytes), "\n") {
		splits := strings.Fields(val)
		if len(splits) >= 2 {
			memValues[splits[0]], _ = strconv.ParseInt(splits[1], 10, 64)
		}
	}

	// Now just fill out the interesting values
	res.RAMTotalMb = memValues["MemTotal:"] / 1024
	res.RAMFreeMb = memValues["MemAvailable:"] / 1024
	res.RAMCacheMb = (memValues["Cached:"] + memValues["Buffers:"]) / 1024

	res.SwapTotalMb = memValues["SwapTotal:"] / 1024
	res.SwapFreeMb = memValues["SwapFree:"] / 1024

	return res, nil
}

func printErr(err error) {
	log.Println(err.Error())
}
