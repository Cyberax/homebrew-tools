package docker

import (
	. "apollo/utils"
	"context"
	"fmt"
	"github.com/docker/docker/api/types"
	"io"
	"net"
	"strings"
)

type HijackedReadWriterCloser struct {
	response types.HijackedResponse
	stderrLogContext context.Context
	pushback []byte
}

func NewHijackedStreamDemuxer(stream types.HijackedResponse,
	stderrLogContext context.Context) *HijackedReadWriterCloser {

	return &HijackedReadWriterCloser{
		response: stream,
		stderrLogContext: stderrLogContext,
	}
}

type SmuxSockAddr struct {}

func (SmuxSockAddr) Network() string {
	return "smux"
}

func (SmuxSockAddr) String() string {
	return "local"
}

func (h *HijackedReadWriterCloser) RemoteAddr() net.Addr {
	return SmuxSockAddr{}
}

func (h *HijackedReadWriterCloser) LocalAddr() net.Addr {
	return SmuxSockAddr{}
}

func (h *HijackedReadWriterCloser) Read(p []byte) (n int, err error) {
	// Check if we have anything in the pushback buffer
	if h.pushback != nil && len(h.pushback) != 0 {
		ln := copy(p, h.pushback)
		h.pushback = h.pushback[ln:]
		return ln, nil
	}
	// Read with demuxing
	for ;; {
		stdout, msg, err := readMuxedMessage(h.response)
		if err != nil {
			_ = h.Close()
			return 0, err
		}
		if !stdout {
			CL(h.stderrLogContext).Print(strings.TrimRight(msg, "\r\n"))
			continue
		}
		// We have a message!
		ln := copy(p, msg)
		h.pushback = []byte(msg)[ln:]
		return ln, nil
	}
}

func (h *HijackedReadWriterCloser) Write(p []byte) (n int, err error) {
	return h.response.Conn.Write(p)
}

func (h *HijackedReadWriterCloser) Close() error {
	return h.response.Conn.Close()
}

// Read a message from the hijacked stream, returns a triple:
// is-stdout-flag, message, error
func readMuxedMessage(stream types.HijackedResponse) (bool, string, error) {
	header := make([]byte, 8)

	_, err := io.ReadFull(stream.Reader, header)
	if err != nil {
		return false, "", err
	}

	size := (uint32(header[4]) * 1<<24) + (uint32(header[5]) * 1<<16) +
		(uint32(header[6]) * 1<<8) + uint32(header[7])
	message := make([]byte, size)
	_, err = io.ReadFull(stream.Reader, message)
	if err != nil {
		return false, "", err
	}

	if header[0] == 1 {
		// Stdout
		return true, string(message), nil
	}
	if header[0] == 2 {
		//Stderr
		return false, string(message), nil
	}

	return false, "", fmt.Errorf("unknown message type: %d", header[0])
}
