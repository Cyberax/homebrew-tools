package herder

import (
	"apollo/aposerver/docker"
	"apollo/data"
	"apollo/proto/gen/models"
	. "apollo/utils"
	"context"
	"github.com/sirupsen/logrus"
	"net"
	"sync"
	"time"
)

const OfflineTimeout = 120 * time.Second
const ThresholdForReaping = 3600 * time.Second

type NodeMinder struct {
	Key        string
	Context    context.Context
	SiteSuffix string
	ProxyTarget chan net.Conn

	TaskMinderFactory TaskMinderFactoryFacet
	Stores            data.Stores

	// Mutable state
	Docker    docker.ConnectorFacet
	Parasite  *docker.ParasiteClient

	MeasurementsChan chan models.NodeInfo
	LastCommSuccess time.Time
	State           models.NodeStateEnum

	LastReapingTime time.Time

	SubtaskMtx sync.Mutex
	Subtasks   map[data.SubtaskKeyWithRetry]TaskMinderFacet
	Processes  sync.WaitGroup
}

var (
	controlLoopPeriod = 10*time.Second
)

func NewNodeMinder(parentCtx context.Context, siteSuffix string, proxyTarget chan net.Conn,
	key string, tmff TaskMinderFactoryFacet, stores data.Stores) *NodeMinder {

	ctx := DeriveNewLoggerContext(parentCtx)
	AddLoggerFields(ctx, logrus.Fields{"Node": key})

	return &NodeMinder{
		Key:     key,
		Context: ctx,
		SiteSuffix: siteSuffix,
		ProxyTarget: proxyTarget,

		TaskMinderFactory: tmff,
		Stores: stores,

		MeasurementsChan: make(chan models.NodeInfo, 3),
		LastCommSuccess: time.Now(),
		Subtasks: make(map[data.SubtaskKeyWithRetry]TaskMinderFacet),
	}
}

func MakeConnectionInfo(nodeKey string, siteSuffix string,
	stores data.Stores, ctx context.Context) docker.ConnectionInfo {

	sess := stores.LS.Session(ctx)
	defer sess.UnlockAll()

	node := stores.NS.MustGetNode(nodeKey, sess, data.LockModeRead)
	PanicIf(node == nil, "node disappeared: %s")

	queue := stores.QS.GetQueue(node.Queue, sess, data.LockModeNone)
	return docker.ConnectionInfo {
		DockerAddress:    node.DockerAddress,
		DockerRepository: queue.DockerRepository,
		DockerLogin:      queue.DockerLogin,
		DockerPassword:   queue.DockerPassword,
		Suffix:           siteSuffix,

		NodeCACert: node.CACert,
		NodeCAKey:  node.CAKey,
	}
}

func (nm *NodeMinder) tryDockerConnection(managed bool) {
	if nm.Parasite != nil {
		return
	}

	info := MakeConnectionInfo(nm.Key, nm.SiteSuffix, nm.Stores, nm.Context)
	connector, e := docker.NewConnector(info)
	if e != nil {
		CL(nm.Context).Warnf("Failed to create a Docker connection: %s", e)
		return
	}

	pc := docker.NewParasiteClient(nm.Context, connector.Client, nm.MeasurementsChan,
		nm.ProxyTarget, nm.SiteSuffix, managed)
	e = pc.RunLoops()
	if e != nil {
		CL(nm.Context).Warnf("Failed to run the parasite: %s", e)
		connector.Close()
		return
	}

	nm.Parasite = pc
	nm.Docker = connector
}

func (nm *NodeMinder) RunIteration() bool {
	sess := nm.Stores.LS.Session(nm.Context)
	node := nm.Stores.NS.MustGetNode(nm.Key, sess, data.LockModeNone)
	PanicIf(node == nil, "node disappeared")

	nm.tryDockerConnection(node.Managed)

	nm.SubtaskMtx.Lock()
	defer nm.SubtaskMtx.Unlock()

	subtasks := nm.Stores.NS.GetNodeSubtasks(nm.Key)
	if len(nm.Subtasks) == 0 && (node.State == models.NodeStateEnumShuttingDown ||
		node.State == models.NodeStateEnumDead) {
		return false
	}

	// We can't launch new tasks without a docker connection
	if nm.Docker == nil {
		return true
	}

	nm.tryReaping()

	// Get subtasks assigned to the node and create the appropriate minders
	var seen = make(map[data.SubtaskKeyWithRetry]bool)
	for _, curKey := range subtasks {
		seen[curKey] = true
		_, ok := nm.Subtasks[curKey]
		if !ok {
			// We have received a new task and might need to create a new minder
			// for it.
			facet := nm.runMinder(curKey, nm.Docker)
			nm.Subtasks[curKey] = facet
		}
	}

	return true
}

func (nm *NodeMinder) tryReaping() {
	if nm.LastReapingTime.Add(ThresholdForReaping / 2).After(time.Now()) {
		return
	}
	nm.LastReapingTime = time.Now()

	nm.Processes.Add(1)
	go func() {
		defer nm.Processes.Done()
		if nm.Docker == nil {
			return
		}
		SweepDeadContainers(nm.Context, nm.Key, nm.Docker, nm.Stores, ThresholdForReaping)
	}()
}

// Remove containers that do not correspond to any assigned task
func SweepDeadContainers(ctx context.Context, nodeKey string, docker docker.ConnectorFacet,
	stores data.Stores, thresholdTime time.Duration) {
	ctx = DeriveNewLoggerContext(ctx)
	AddLoggerFields(ctx, logrus.Fields{"REAPER": "1"})

	CL(ctx).Infof("Running dead containers reaper")

	containers, err := docker.ListApolloContainers(ctx)
	if err != nil {
		CL(ctx).Warnf("Failed to get container list: %s", err.Error())
		return
	}
	// Get currently assigned subtasks
	subtasks := stores.NS.GetNodeSubtasks(nodeKey)

	subtaskMap := make(map[string]*data.Subtask)
	for _, st := range subtasks {
		subtask := stores.TS.GetSubtask(st.SKey, nil, data.LockModeNone)
		if subtask != nil && subtask.CurrentAssignment != nil &&
			subtask.CurrentAssignment.ContainerID != "" {
			subtaskMap[subtask.CurrentAssignment.ContainerID] = subtask
		}
	}

	// Now go through containers and clean them up
	for _, cnt := range containers {
		// Find a subtask with this key
		_, ok := subtaskMap[cnt.ID]
		if ok {
			continue
		}

		// Hmm... A possible zombie. Check if the container is recent enough
		info, err := docker.InspectContainer(ctx, cnt.ID)
		if err != nil {
			CL(ctx).Infof("Skipping container during reaping: %s, err=%s", cnt.ID, err)
			continue
		}

		// Check the creation time first
		createdTime, err := time.Parse(time.RFC3339Nano, info.Created)
		if createdTime.Add(thresholdTime).After(time.Now()) {
			continue
		}

		// If the container has finished recently then skip it for now.
		finTime, err := time.Parse(time.RFC3339Nano, info.State.FinishedAt)
		if finTime.Add(thresholdTime).After(time.Now()) {
			continue
		}

		startTime, err := time.Parse(time.RFC3339Nano, info.State.StartedAt)
		// If the container is still running and it's more than threshold time then
		// it's definitely a zombie.
		if startTime.Add(thresholdTime).Before(time.Now()) {
			if cnt.State != "exited" {
				CL(ctx).Infof("Killing a running container: %s", cnt.ID[:16])
				_ = docker.KillContainer(ctx, cnt.ID)
			}
			CL(ctx).Infof("Cleaning up the container: %s", cnt.ID[:16])
			docker.CleanupContainer(ctx, cnt.ID)
		}
	}
}

func (nm *NodeMinder) runMinder(key data.SubtaskKeyWithRetry,
	conn docker.ConnectorFacet) TaskMinderFacet {

	CL(nm.Context).Infof("Dispatching task %s", key.String())

	tm := nm.TaskMinderFactory.CreateTaskMinder(nm.Context, key, conn)

	nm.Processes.Add(1)
	go func() {
		defer func() {
			nm.SubtaskMtx.Lock()
			defer nm.SubtaskMtx.Unlock()
			delete(nm.Subtasks, key)

			CL(nm.Context).Infof("Stopped tracking completed task %s", key.String())
			nm.Processes.Done()
		}()
		tm.DoTransitions()
		// We're guaranteed to have the node unassigned upon the return from
		// the TaskMinder, so we can safely unregister this handler in the defer block.
	}()

	return tm
}

func (nm *NodeMinder) doNodeTransitions(info *models.NodeInfo) {
	sess := nm.Stores.LS.Session(nm.Context)
	defer sess.UnlockAll()
	node := *nm.Stores.NS.MustGetNode(nm.Key, sess, data.LockModeFull)

	var changed bool
	if info != nil && node.Info.Timestamp != info.Timestamp {
		node.Info = *info
		changed = true
	}

	var online = bool(time.Now().Unix() - node.Info.Timestamp < int64(OfflineTimeout.Seconds()))
	if online != node.Online {
		changed = true
		node.Online = online
		if online {
			logrus.Infof("Node is now online")
		} else {
			logrus.Infof("Node is offline")
		}
	}

	if changed {
		nm.Stores.NS.UpdateNode(&node, sess)
	}
	//
	//if changed {
	//	// TODO: state transitions
	//}
}

//func (nm *NodeMinder) transitionNode(nd data.StoredNode,
//	newState models.NodeStateEnum, message string, sess *data.Session) bool {
//
//	if online && node.State != models.NodeStateEnumActive {
//		changed = nm.transitionNode(node, models.NodeStateEnumActive,
//			"Node has started communicating", sess)
//	}
//	if !online && node.State != models.NodeStateEnumOffline {
//		changed = nm.transitionNode(node, models.NodeStateEnumOffline,
//			"Transitioning node to offline because of a watchdog timeout", sess)
//	}
//
//	return true
//}

func (nm *NodeMinder) closeDocker() {
	if nm.Parasite != nil {
		nm.Parasite.Close()
		nm.Parasite = nil
	}
	if nm.Docker != nil {
		nm.Docker.Close()
		nm.Docker = nil
	}
}

func (nm *NodeMinder) RunControlLoop() {
	defer func() {
		nm.closeDocker()
	}()

	scheduledNotifies := make(chan string, 1)
	nm.Stores.LS.Subscribe(data.NotifySubtaskScheduled, nm.Key, scheduledNotifies, false)
	defer nm.Stores.LS.Unsubscribe(data.NotifySubtaskScheduled, nm.Key, scheduledNotifies)

	ticker := time.NewTicker(controlLoopPeriod)
	defer ticker.Stop()
	defer nm.Processes.Wait()

loop:
	for ; ; {
		if !nm.RunIteration() {
			break
		}

		var dieCh chan bool
		if nm.Parasite != nil {
			dieCh = nm.Parasite.DeathChan
		}

		select {
		case <-dieCh:
			nm.closeDocker()
		case measure := <-nm.MeasurementsChan:
			// Update the node with the latest stats, possibly performing state
			// transitions
			nm.doNodeTransitions(&measure)
		case <-scheduledNotifies:
		case <-ticker.C:
		case <-nm.Context.Done():
			break loop
		}
	}
}
