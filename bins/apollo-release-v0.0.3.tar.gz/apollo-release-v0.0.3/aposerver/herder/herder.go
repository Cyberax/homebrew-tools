package herder

import (
	"apollo/data"
	"apollo/proto/gen/models"
	. "apollo/utils"
	"context"
	"github.com/sirupsen/logrus"
	"net"
	"sync"
	"time"
)

type Herder struct {
	mtx sync.Mutex

	Context context.Context
	cancel context.CancelFunc
	SiteSuffix string
	TMFF TaskMinderFactoryFacet
	proxyChan chan net.Conn

	Stores data.Stores

	Nodes map[string]*NodeMinder
	Processes sync.WaitGroup
}

func NewHerder(siteSuffix string, proxyChan chan net.Conn,
	stores data.Stores, tmff TaskMinderFactoryFacet) *Herder {

	ctx := context.Background()
	ctx = SaveLoggerToContext(ctx, logrus.StandardLogger())
	ctx, canceller := context.WithCancel(ctx)

	return &Herder{
		Context: ctx,
		SiteSuffix: siteSuffix,
		proxyChan: proxyChan,
		TMFF: tmff,
		cancel: canceller,
		Stores: stores,
		Nodes: make(map[string]*NodeMinder),
	}
}

func (h *Herder) Cancel() {
	h.cancel()
	h.Processes.Wait()
}

func (h *Herder) RunLoopIteration() {
	h.mtx.Lock()
	defer h.mtx.Unlock()

	sess := h.Stores.LS.Session(h.Context)
	nodes := h.Stores.NS.ListNodes([]string{}, func(node *data.StoredNode) bool {
		return node.State != models.NodeStateEnumDead &&
			node.State != models.NodeStateEnumShuttingDown
	}, sess)

	for _, n := range nodes {
		_, ok := h.Nodes[n.Key]
		if !ok {
			// Create a node minder

			nm := NewNodeMinder(h.Context, h.SiteSuffix, h.proxyChan, n.Key, h.TMFF, h.Stores)
			h.Nodes[n.Key] = nm
			h.Processes.Add(1)
			go func() {
				defer h.Processes.Done()
				nm.RunControlLoop()
				// Once the loop exits, remove the minder
				h.mtx.Lock()
				defer h.mtx.Unlock()
				delete(h.Nodes, n.Key)
			}()
		}
	}
}

func (h *Herder) RunLoop() {
	CL(h.Context).Infof("Starting the herder loop")
	ticker := time.NewTicker(controlLoopPeriod)
	defer ticker.Stop()
	defer h.Processes.Wait()

	loop: for ;; {
		h.RunLoopIteration()

		select {
		case <- ticker.C:
		case <- h.Context.Done():
			CL(h.Context).Infof("Interrupt signal received, herder is stopping")
			break loop
		}
	}
}
