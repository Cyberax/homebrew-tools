package herder

import (
	"apollo/aposerver/docker"
	_ "apollo/aposerver/statik"
	"apollo/data"
	"apollo/proto/gen/models"
	"apollo/utils"
	"context"
	"crypto/rand"
	"fmt"
	"github.com/sirupsen/logrus"
	"github.com/stretchr/testify/assert"
	"net"
	"sync"
	"testing"
	"time"
)

type NodeTestContext struct {
	locker *data.LockStore
	cancel context.CancelFunc
	stores data.Stores
	fdf *FakeDockerFactory
	nm *NodeMinder
}

func makeNodeMinder(t *testing.T) *NodeTestContext {
	store := data.NewFakeMemStore()
	//noinspection GoUnhandledErrorResult
	store.InitSchema(map[string]int64{
		data.ConfigStoreTable: 5,
		data.QueueTable:       5,
		data.NodeTable:        5,
		data.TaskTable:        5,
		data.SubtaskTable:     5,
	})

	locker := data.NewLockStore()
	queueStore := data.NewQueueStore(store)
	nodeStore := data.NewNodeStore(store)
	taskStore := data.NewTaskStore(store, nodeStore)
	ctx := context.Background()
	sess := locker.Session(ctx)
	defer sess.UnlockAll()

	_ = queueStore.StoreNewQueue(&data.StoredQueue{
		Key: "q-1",
	}, sess)

	//noinspection GoUnhandledErrorResult
	nodeStore.StoreNode(&data.StoredNode{
		Key:   "n-1",
		Queue: "q-1",
	}, sess)

	// Add the task and wait for it to start
	cmdLine := []string{"/bin/sh", "-c", "echo Hello; sleep 5; echo World; sleep 5; exit 1;"}
	ts := models.TaskStruct{Queue: "test-queue", DockerImageID: "docker.io/library/alpine:3.7",
		Cmdline: cmdLine, ExpectedRAMMb: 10, MaxRAMMb: 12,
		Tags: map[string]string{"test-run": "true"},
		StartArrayIndex: 0, EndArrayIndex: 2,}
	st := data.StoredTask{
		TaskStruct: ts,
		Key: "t-1",
	}
	_ = taskStore.StoreTask(&st, sess)

	stores := data.Stores {
		TS: taskStore,
		LS: locker,
		NS: nodeStore,
		QS: queueStore,
	}

	ctx, canceller := context.WithCancel(ctx)
	ctx = utils.SaveLoggerToContext(ctx, logrus.StandardLogger())
	fdf := NewFakeDockerFactory(t)
	nm := NewNodeMinder(ctx, makeTestSuffix(), make(chan net.Conn), "n-1", fdf,  stores)
	return &NodeTestContext{
		locker: locker,
		cancel: canceller,
		stores: stores,
		fdf: fdf,
		nm: nm,
	}
}

func makeTestSuffix() string {
	// Generate a random 6-character suffix
	var randBytes = make([]byte, 3)
	_, err := rand.Read(randBytes)
	utils.PanicIf(err != nil, "")

	return fmt.Sprintf("-%x%x%x", randBytes[0], randBytes[1], randBytes[2])
}

func TestNodeUpdates(t *testing.T) {
	t.Parallel()
	tc := makeNodeMinder(t)

	wg := sync.WaitGroup{}
	wg.Add(1)
	go func() {
		defer wg.Done()
		tc.nm.RunControlLoop()
	}()

	waitForUpdates(tc, t)

	markNodeFinished(tc)

	// So now the poller will eventually die
	wg.Wait()
}

func waitForUpdates(tc *NodeTestContext, t *testing.T) {
	sess := tc.locker.Session(context.Background())

	for ; ; {
		nd := tc.stores.NS.GetNode("n-1", sess, data.LockModeNone)

		// Wait for the node to come online
		time.Sleep(100 * time.Millisecond)
		if nd.Info.RAM.RAMTotalMb > 0 {
			assert.True(t, nd.Online)
			break
		}
	}
}

// Mark the node as finished
func markNodeFinished(tc *NodeTestContext) {
	sess := tc.locker.Session(context.Background())
	defer sess.UnlockAll()

	nd := *tc.stores.NS.MustGetNode("n-1", sess, data.LockModeFull)
	nd.State = models.NodeStateEnumShuttingDown
	tc.stores.NS.UpdateNode(&nd, sess)
}

func createTaskAssignment(tc *NodeTestContext) {
	// Assign the subtask
	sess := tc.locker.Session(context.Background())
	defer sess.UnlockAll()

	tc.stores.NS.MustGetNode("n-1", sess, data.LockModeFull)
	tc.stores.TS.GetSubtask(data.MustParseSubtaskKey("t-1.1"), sess, data.LockModeFull)

	sub1 := data.Subtask{
		Key:             "t-1.1",
		RetryNum:        2,

		SubtaskInfo: models.SubtaskInfo{
			Status: models.SubtaskStateEnumDispatched,
			CurrentAssignment: &models.SubtaskAssignment{AssignedNode: "n-1"},
			PriorAssignments: make(map[string]models.SubtaskAssignment),},
	}
	tc.stores.TS.UpdateSubtask(&sub1, sess)
}

type SimpleTaskRunner struct {
	ctx context.Context
	endSignal chan bool
	startSignal chan bool
}

func (s *SimpleTaskRunner) DoTransitions() {
	s.startSignal <- true
	select {
	case <-s.endSignal:
	case <-s.ctx.Done():
	}
}

func TestTaskRunner(t *testing.T) {
	t.Parallel()
	tc := makeNodeMinder(t)

	wg := sync.WaitGroup{}
	wg.Add(1)
	go func() {
		defer wg.Done()
		tc.nm.RunControlLoop()
	}()
	waitForUpdates(tc, t)

	str := tc.fdf.str

	createTaskAssignment(tc)
	// Make sure task update is picked up
	waitForUpdates(tc, t)
	waitForUpdates(tc, t)

	markNodeFinished(tc)
	<-str.startSignal

	// The node doesn't die immediately, it still produces updates
	// until the last task is finished
	waitForUpdates(tc, t)
	waitForUpdates(tc, t) // Make sure we definitely went through the loop

	// De-assign the subtask
	deAssignSubtask(tc)

	str.endSignal <- true // Signal the task to finish, this should release the node minder

	// So now the poller will eventually die
	wg.Wait()
}

func deAssignSubtask(tc *NodeTestContext) {
	sess := tc.locker.Session(context.Background())
	defer sess.UnlockAll()
	tc.stores.NS.MustGetNode("n-1", sess, data.LockModeFull)
	tc.stores.TS.GetSubtask(data.MustParseSubtaskKey("t-1.1"), sess, data.LockModeFull)
	sub1 := data.Subtask{
		Key:             "t-1.1",
		RetryNum:        2,
		SubtaskInfo: models.SubtaskInfo{
			Status: models.SubtaskStateEnumWaiting,
			CurrentAssignment: &models.SubtaskAssignment{AssignedNode: ""},
			PriorAssignments: make(map[string]models.SubtaskAssignment),}}
	tc.stores.TS.UpdateSubtask(&sub1, sess)
}

type FakeDockerFactory struct {
	t *testing.T
	str *SimpleTaskRunner
}

func NewFakeDockerFactory(t *testing.T) *FakeDockerFactory {
	str := &SimpleTaskRunner{}
	str.startSignal = make(chan bool, 1)
	str.endSignal = make(chan bool, 1)

	return &FakeDockerFactory {
		t: t,
		str: str,
	}
}

func (t *FakeDockerFactory) CreateTaskMinder(ctx context.Context, key data.SubtaskKeyWithRetry,
	conn docker.ConnectorFacet) TaskMinderFacet {

	assert.Equal(t.t, "t-1.1", key.SKey.String())
	assert.Equal(t.t, int64(2), key.RetryNum)
	t.str.ctx = ctx

	return t.str
}

func TestCancellation(t *testing.T) {
	t.Parallel()
	tc := makeNodeMinder(t)

	wg := sync.WaitGroup{}
	wg.Add(1)
	go func() {
		defer wg.Done()
		tc.nm.RunControlLoop()
	}()

	waitForUpdates(tc, t)

	// Run the task
	createTaskAssignment(tc)
	<-tc.fdf.str.startSignal

	// Cancellation is hierarchic
	tc.cancel()

	// So now the poller will eventually die
	wg.Wait()
}
