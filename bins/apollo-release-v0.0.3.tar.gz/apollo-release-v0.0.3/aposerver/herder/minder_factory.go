package herder

import (
	"apollo/aposerver/docker"
	"apollo/data"
	"context"
)

type TaskMinderFacet interface {
	DoTransitions()
}

type TaskMinderFactoryFacet interface {
	CreateTaskMinder(ctx context.Context, key data.SubtaskKeyWithRetry,
		conn docker.ConnectorFacet) TaskMinderFacet
}

type TaskMinderFactory struct {
	SiteSuffix   string
	Stores       data.Stores
	TokenManager *data.TokenManager
	ServerCert   string
}

func NewTaskMinderFactory(siteSuffix string, stores data.Stores,
	tokenManager *data.TokenManager, serverCert string) *TaskMinderFactory {

	return &TaskMinderFactory{
		SiteSuffix: siteSuffix,
		Stores: stores,
		TokenManager: tokenManager,
		ServerCert: serverCert,
	}
}

func (t *TaskMinderFactory) CreateTaskMinder(ctx context.Context,
	key data.SubtaskKeyWithRetry, conn docker.ConnectorFacet) TaskMinderFacet {

	return NewTaskMinder(ctx, t.SiteSuffix, key, conn, t.TokenManager, t.ServerCert, t.Stores)
}
