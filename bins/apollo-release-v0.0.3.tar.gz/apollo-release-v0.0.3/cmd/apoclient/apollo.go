package main

import (
	"apollo/apoclient"
	"apollo/utils"
	"github.com/spf13/cobra"
	"os"
	"path"
)

//noinspection GoUnhandledErrorResult
func makeCompletionCmd() *cobra.Command {
	var completionCmd = &cobra.Command{
		Use:   "completion",
		Short: "Generates bash/zsh completion scripts",
		Long: `To load completion run
	. <(completion)
	To configure your bash or zsh shell to load completions for each session add to your
	# ~/.bashrc or ~/.profile
	. <(completion)
	`,
		Run: func(cmd *cobra.Command, args []string) {
			zsh := utils.GetFlagB(cmd, "zsh")
			if zsh {
				cmd.Parent().GenZshCompletion(os.Stdout)
			} else {
				cmd.Parent().GenBashCompletion(os.Stdout)
			}
		},
	}
	completionCmd.Flags().BoolP("zsh", "z", false, "Generate ZSH completion")

	return completionCmd
}

func main() {
	cobra.EnableCommandSorting = false

	var rootCmd = &cobra.Command{
		Use: "apollo",
		PersistentPreRunE: func(cmd *cobra.Command, args []string) error {
			verbose, _ := cmd.Flags().GetBool("verbose")
			utils.SetupClientLogging(verbose)
			return utils.CheckRequiredFlags(cmd.Flags())
		},
	}

	rootCmd.Flags().SortFlags = false

	rootCmd.PersistentFlags().BoolP("verbose", "v", false, "Verbose mode")
	home := os.Getenv("HOME")
	rootCmd.PersistentFlags().StringP("token-file", "t",
		path.Join(home, ".apollo-token"),
		"The token file containing the connection token")

	rootCmd.AddCommand(makeCompletionCmd())

	// Login
	var authCmd = &cobra.Command{Use: "auth", Short: "Authentication-related commands"}
	rootCmd.AddCommand(authCmd)
	authCmd.AddCommand(apoclient.MakeLoginCmd())
	authCmd.AddCommand(apoclient.MakePingCmd())
	authCmd.AddCommand(apoclient.MakeGetCaCertCmd())
	authCmd.AddCommand(apoclient.MakeGetWhitelistCmd())
	authCmd.AddCommand(apoclient.MakeAddWhitelistCmd())
	authCmd.AddCommand(apoclient.MakeDeleteWhitelistCmd())

	// Task
	var taskCmd = &cobra.Command{Use: "task", Short: "Task-related commands"}
	rootCmd.AddCommand(taskCmd)
	taskCmd.AddCommand(apoclient.MakeSubmitCmd())
	taskCmd.AddCommand(apoclient.MakeListCmd())
	taskCmd.AddCommand(apoclient.MakeDescribeCommand())
	taskCmd.AddCommand(apoclient.MakeSubtaskListCmd())
	taskCmd.AddCommand(apoclient.MakeAssignCmd())
	taskCmd.AddCommand(apoclient.MakeCancelCmd())
	taskCmd.AddCommand(apoclient.MakeWaitCmd())
	taskCmd.AddCommand(apoclient.MakeTaskLogsCmd())

	// Queue
	var queueCmd = &cobra.Command{Use: "queue", Short: "Queue-related commands"}
	rootCmd.AddCommand(queueCmd)
	queueCmd.AddCommand(apoclient.MakeQueueListCmd())
	queueCmd.AddCommand(apoclient.MakePutQueueCommand())
	queueCmd.AddCommand(apoclient.MakePutEcrQueueCommand())
	queueCmd.AddCommand(apoclient.MakeDeleteQueueCommand())
	queueCmd.AddCommand(apoclient.MakeQueueAuthCommand())
	queueCmd.AddCommand(apoclient.MakeQueuePushCommand())

	// Nodes
	var nodeCmd = &cobra.Command{Use: "node", Short: "Node-related commands"}
	rootCmd.AddCommand(nodeCmd)
	nodeCmd.AddCommand(apoclient.MakePutUnmanagedNodeCommand())
	nodeCmd.AddCommand(apoclient.MakePutEc2NodeCommand())
	nodeCmd.AddCommand(apoclient.MakeNodeListCmd())

	// Nodes
	var filesCmd = &cobra.Command{Use: "file", Short: "File-related commands"}
	rootCmd.AddCommand(filesCmd)
	filesCmd.AddCommand(apoclient.MakePutFileCommand())
	filesCmd.AddCommand(apoclient.MakeFinishFilesUploadCommand())
	filesCmd.AddCommand(apoclient.MakeListFilesCommand())
	filesCmd.AddCommand(apoclient.MakeExposeFileCommand())
	filesCmd.AddCommand(apoclient.MakeGetFileCommand())
	filesCmd.AddCommand(apoclient.MakeDeleteFileCommand())

	// Docker
	rootCmd.AddCommand(apoclient.MakeDockerCommand())

	err := rootCmd.Execute()
	if err != nil {
		apoclient.PrintError(err)
		os.Exit(1)
	}
}
