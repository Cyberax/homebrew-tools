# Apollo - the task manager

# Client Installation

## Mac OS X
Installation on Mac OS X is automated through Homebrew. The easiest way to install the 
client is to run:
````
brew tap Cyberax/tools
brew install aurora-apollo-client
```` 
This should check out, compile and install the Apollo client. It will also install the Bash
completion support.

## Building from source
Apollo is a Go-language executable and needs Go and [Dep](https://github.com/golang/dep) tools 
to compile. Install both of them and make sure that both work.
After this the code should be ready to be compiled, check it out into your GOPATH and use "make" 
to compile it.

# Connecting to the server
Apollo offloads the authentication to AWS to avoid supporting its own user management 
infrastructure. See [Whitelisting] chapter for details on whitelisting the accounts.

As long as you have your AWS CLI utilities configured (refer to [AWS Documentation](https://docs.aws.amazon.com/en_us/polly/latest/dg/setup-aws-cli.html))
you should be able to use Apollo client directly:
````
apollo auth login --host <host>:<port>
````
The default server port is *9443*. You can specify the AWS profile by using *"-p"* switch.

As a result of running *"apollo auth login"* a new file *~/.apollo_token* will be created with
contents that looks like:
```
serverhost.com:9443#d0365ed36b21654f1a57e7f8:....
```

This file contains the URL of the server, server's TLS certificate and the authentication token.

## Renewing tokens
Tokens expire in 24 hours by default and need to be updated. Usually simple *"apollo auth login"*
without any additional arguments is enough to do that, as Apollo will re-use the previous URL from
the existing token file.

# Apollo concepts
Apollo has several core concepts: tasks, subtasks, jobs, queues and nodes. Let's look into them:

## Tasks
Tasks are submitted by the users (or by other tasks) to do computation. Each task is run in a
separate ephemeral Docker container on a computation node.

Tasks are submitted by using:
```
apollo submit 
```

## Subtasks
