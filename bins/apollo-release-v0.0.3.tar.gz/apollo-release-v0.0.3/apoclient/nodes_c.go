package apoclient

import (
	"apollo/proto/gen/restcli"
	"apollo/proto/gen/restcli/node"
	. "apollo/utils"
	"fmt"
	"github.com/olekukonko/tablewriter"
	"github.com/spf13/cobra"
	"os"
	"sort"
	"strings"
	"time"
)

func MakePutUnmanagedNodeCommand() *cobra.Command {
	var cmdLogin = &cobra.Command{
		Use:          "create-unmanaged <queue-name> <docker-address>",
		Short:        "Create a new unmanaged node",
		Long:         `Create a new unmanaged node`,
		Args:         cobra.MinimumNArgs(2),
		SilenceUsage: true,
		SilenceErrors: true,
		RunE: func(cmd *cobra.Command, args []string) error {
			conn, err := ObtainConnection(cmd)
			if err != nil {
				return err
			}
			return DoPutUnmanagedNode(conn, args[0], args[1])
		},
	}
	return cmdLogin
}


func DoPutUnmanagedNode(cli *restcli.Apollo, queue string, addr string) error {
	params := node.NewPutUnmanagedNodeParams()
	params.Node.Queue = queue
	params.Node.DockerAddress = addr

	res, err := cli.Node.PutUnmanagedNode(params, nil)
	if err != nil {
		return err
	}

	fmt.Printf("ID\t"+res.Payload.NodeID+"\n")
	return nil
}

func MakePutEc2NodeCommand() *cobra.Command {
	var cmdLogin = &cobra.Command{
		Use:          "enroll-ec2-node <queue-name> <instance-id>",
		Short:        "Enroll EC2 node into Apollo",
		Long:         `Enroll an EC2 node into Apollo using AWS SSM`,
		Args:         cobra.MinimumNArgs(2),
		SilenceUsage: true,
		SilenceErrors: true,
		RunE: func(cmd *cobra.Command, args []string) error {
			conn, err := ObtainConnection(cmd)
			if err != nil {
				return err
			}
			return DoPutEc2Node(conn, args[0], args[1])
		},
	}
	return cmdLogin
}


func DoPutEc2Node(cli *restcli.Apollo, queue string, instanceId string) error {
	params := node.NewPutEc2NodeParams()
	params.Node.Queue = queue
	params.Node.InstanceID = instanceId

	res, err := cli.Node.PutEc2Node(params, nil)
	if err != nil {
		return err
	}

	fmt.Printf("ID\t"+res.Payload.NodeID+"\n")
	return nil
}

func MakeNodeListCmd() *cobra.Command {
	var cmdList = &cobra.Command{
		Use:          "list",
		Short:        "List nodes",
		Long:         `list compute nodes`,
		Args:         cobra.MinimumNArgs(0),
		SilenceUsage: true,
		SilenceErrors: true,
		RunE: func(cmd *cobra.Command, args []string) error {
			conn, err := ObtainConnection(cmd)
			if err != nil {
				return err
			}

			return DoListNodes(conn, GetFlagS(cmd,"queue"), GetFlagB(cmd,"json"))
		},
	}
	cmdList.Flags().StringP("queue", "q", "", "Queue Name")
	cmdList.Flags().Bool("json", false, "JSON output")
	return cmdList
}

func renderTimeDiff(d int64) string {
	if d < 999 {
		return fmt.Sprintf("%d sec", d)
	}
	if d < 10000 {
		return fmt.Sprintf("%d min", d/60)
	}
	return fmt.Sprintf("%d hr", d/3600)
}

func DoListNodes(cli *restcli.Apollo, queueName string, json bool) error {
	params := node.NewGetNodeListParams()
	if queueName != "" {
		params.QueueName = &queueName
	}

	nodes, err := cli.Node.GetNodeList(params, nil)
	if err != nil {
		return err
	}

	if json {
		for _, t := range nodes.Payload {
			bytes, e := t.MarshalBinary()
			if e != nil {
				return e
			}
			fmt.Print(string(bytes)+"\n")
		}
		return nil
	}

	table := tablewriter.NewWriter(os.Stdout)
	table.SetHeader([]string{"ID (*)", "Queue", "State", "Cloud ID/\nDocker Addr",
		"Info", "Tasks"})
	table.SetRowLine(true)         // Enable row line
	table.SetAutoWrapText(false)

	var data [][]string

	now := time.Now().Unix()

	for _, n := range nodes.Payload {
		diff := now - n.NodeInfo.Timestamp/1000
		//if n.NodeState != models.NodeStateEnumActive {
		//	diff = now - n.LastTransitionTime
		//}
		var state = "Online"

		m := ""
		if !n.ManagedNode {
			m = "\n(U)"
		}
		ni := n.NodeInfo

		var totalMb, freeMb int64
		for _, d := range ni.Disks {
			totalMb += d.SpaceTotalMb
			freeMb += d.SpaceFreeMb
		}
		info := fmt.Sprintf("Load: %.2f%% of %d CPUs\nRAM: %s, free: %s\n" +
			"Swap: %s, free %s\nDisks: %s, free %s",
			ni.CPU.AggregateCPULoad*100, ni.CPU.CPUCount,
			renderSize(ni.RAM.RAMTotalMb), renderSize(ni.RAM.RAMFreeMb),
			renderSize(ni.RAM.SwapTotalMb), renderSize(ni.RAM.SwapFreeMb),
			renderSize(totalMb), renderSize(freeMb))

		data = append(data, []string{
			n.NodeID + m,
			n.QueueName,
			state+"\n("+ renderTimeDiff(diff)+" ago)",
			n.CloudInstanceID + "\n" + n.DockerAddress,
			info,
			wrapString(n.AssignedSubtasks, 25),
		})
	}

	sort.Slice(data, func(i, j int) bool {
		return strings.Compare(data[i][0], data[j][0]) < 0 ||
			strings.Compare(data[i][1], data[j][1]) < 0
	})

	table.AppendBulk(data)
	table.Render()
	fmt.Printf("* (U) - Unamanaged Node\n")

	return nil
}

func wrapString(text []string, sz int) string {
	var res = ""
	var curLine = ""
	for _, s := range text {
		if len(curLine) + len(s) > sz {
			res += curLine + "\n"
			curLine = s
		} else {
			if curLine != "" {
				curLine += ", "
			}
			curLine += s
		}
	}
	res += curLine
	return res
}
