package utils

import (
	"github.com/go-openapi/strfmt"
	"time"
)

type AbsoluteTime int64

func (at AbsoluteTime) ToTime() time.Time {
	return time.Unix(int64(at) / 1000, (int64(at) % 1000) * 1e6)
}

func FromTime(tm time.Time) AbsoluteTime {
	return AbsoluteTime(tm.Unix()*1000 + int64(tm.Nanosecond() / 1e6))
}

func (at AbsoluteTime) Validate(formats strfmt.Registry) error {
	return nil
}