package data

import (
	"apollo/utils"
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"strings"
)

type TokenManager struct {
	cipher cipher.AEAD
}

type TokenType string
const UserToken = "UserToken"
const TaskToken = "TaskToken"

const NeverExpires = 0

// Authentication token: there are several token types,
// each of them linked to a different entity: node, user, or task
type AuthToken struct {
	Expires utils.AbsoluteTime
	Type    TokenType
	// The entity key this token is linked to (or account ID for user tokens)
	EntityKey string
	// The requesting entity
	RequestedBy string
	RequestedOn utils.AbsoluteTime
}

func (a *AuthToken) RenderEntity() string {
	if a.Type == UserToken {
		return "user/" + a.EntityKey
	}
	if a.Type == TaskToken {
		return "task/" + a.EntityKey
	}
	panic("Unknown token type: " + a.Type)
}

func NewTokenManager(key string) (*TokenManager, error) {
	bytes, err := hex.DecodeString(key)
	if err != nil {
		return nil, err
	}
	block, err := aes.NewCipher(bytes)
	if err != nil {
		return nil, err
	}

	aead, err := cipher.NewGCM(block)
	if err != nil {
		return nil, err
	}
	return &TokenManager{cipher: aead}, nil
}

func NewAesKey() string {
	key := make([]byte, 16)
	if _, err := io.ReadFull(rand.Reader, key); err != nil {
		panic(err.Error())
	}
	return hex.EncodeToString(key)
}

func (tm *TokenManager) EncryptToken(token AuthToken) string {
	bytes, e := json.Marshal(token)
	utils.PanicIf(e != nil, "Failed to marshall token")

	nonce := make([]byte, 12)
	if _, err := io.ReadFull(rand.Reader, nonce); err != nil {
		panic(err.Error())
	}

	ciphertext := tm.cipher.Seal(nil, nonce, bytes, nil)
	return hex.EncodeToString(nonce) + ":" + hex.EncodeToString(ciphertext)
}

func (tm *TokenManager) DecryptToken(tokenStr string) (*AuthToken, error) {
	splits := strings.Split(tokenStr, ":")
	if len(splits) != 2 {
		return nil, fmt.Errorf("incorrect token size")
	}
	nonce, err := hex.DecodeString(splits[0])
	if err != nil {
		return nil, err
	}
	tokenData, err := hex.DecodeString(splits[1])

	bytes, err := tm.cipher.Open(nil, nonce, tokenData, nil)
	if err != nil {
		return nil, err
	}

	token := AuthToken{}
	err = json.Unmarshal(bytes, &token)
	if err != nil {
		return nil, err
	}

	return &token, nil
}
