package data

import (
	"apollo/utils"
	"fmt"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
)

type Stores struct {
	QS *QueueStore
	NS *NodeStore
	TS *TaskStore
	LS *LockStore
}

var RowAlreadyExistsError = fmt.Errorf("row already exists")
var IdempotencyTokenAlreadyExistsError = fmt.Errorf("idempotency token already exists")

type TableRow struct {
	What LockTarget
	Key string

	Lock sync.RWMutex
	Deleted bool
	Value atomic.Value
}

func (t *TableRow) GetType() LockTarget {
	return t.What
}

func (t *TableRow) GetKey() string {
	return t.Key
}

func (t *TableRow) GetLock() *sync.RWMutex {
	return &t.Lock
}

func (t *TableRow) String() string {
	return fmt.Sprintf("{%s, key=%s, deleted=%t}",
		t.What.String(), t.Key, t.Deleted)
}

func (t *TableRow) loadVal() interface{} {
	if t==nil || t.Deleted {
		return nil
	}
	return t.Value.Load()
}

func (t *TableRow) storeVal(data Keyed) {
	utils.PanicIf(t==nil || data==nil, "Need to specify a task")
	if t.Deleted {
		panic("Table row is already deleted")
	}
	if t.Key != data.GetKey() {
		panic("Key is inconsistent")
	}
	t.Value.Store(data)
}

// A manual specialization of atomic Value for StoredTask
type TaskTableRow struct {
	*TableRow
}

func NewTaskTableRow(st *StoredTask) TaskTableRow {
	res := TaskTableRow{&TableRow{}}
	res.What = LockTask
	res.Key = st.Key
	res.Store(st)
	return res
}

func (s TaskTableRow) Load() *StoredTask {
	return s.loadVal().(*StoredTask)
}

func (s TaskTableRow) Store(v *StoredTask) {
	s.storeVal(v)
}

// A manual specialization of atomic Value for StoredNode
type NodeTableRow struct {
	*TableRow
}

func NewNodeTableRow(st *StoredNode) NodeTableRow {
	res := NodeTableRow{&TableRow{}}
	res.What = LockNode
	res.Key = st.Key
	res.Store(st)
	return res
}

func (s NodeTableRow) Load() *StoredNode {
	return s.loadVal().(*StoredNode)
}

func (s NodeTableRow) Store(v *StoredNode) {
	s.storeVal(v)
}

// A manual specialization of atomic Value for StoredQueue
type QueueTableRow struct {
	*TableRow
}

func NewQueueTableRow(queue *StoredQueue) QueueTableRow {
	res := QueueTableRow{&TableRow{}}
	res.What = LockQueue
	res.Key = queue.Key
	res.Store(queue)
	return res
}

func (s QueueTableRow) Load() *StoredQueue {
	return s.loadVal().(*StoredQueue)
}

func (s QueueTableRow) Store(v *StoredQueue) {
	s.storeVal(v)
}

// A manual specialization of atomic Value for StoredSubtask
type SubtaskTableRow struct {
	*TableRow
}

func NewSubtaskTableRow(st *Subtask) SubtaskTableRow {
	res := SubtaskTableRow{&TableRow{}}
	res.What = LockSubtask
	res.Key = st.Key
	res.Store(st)
	return res
}

func (s SubtaskTableRow) Load() *Subtask {
	return s.loadVal().(*Subtask)
}

func (s SubtaskTableRow) Store(v *Subtask) {
	s.storeVal(v)
}

// A manual specialization of atomic Value for []*SubtaskKeyWithRetry
type SubtaskWithRetryListValue struct {
	atomic.Value
}

func (s *SubtaskWithRetryListValue) Load() []SubtaskKeyWithRetry {
	return s.Value.Load().([]SubtaskKeyWithRetry)
}

func (s *SubtaskWithRetryListValue) Store(v []SubtaskKeyWithRetry) {
	s.Value.Store(v)
}

// Subtask key
type SubtaskKey struct {
	ParentKey string
	Index int64
}

func MustParseSubtaskKey(key string) SubtaskKey {
	subtaskKey, _, err := ParseSubtaskKey(key)
	if err != nil {
		panic(err)
	}
	return subtaskKey
}

func ParseSubtaskKey(key string) (SubtaskKey, bool, error) {
	splits := strings.SplitN(key, ".", 2)

	if len(splits) == 2 {
		index, err := strconv.ParseInt(splits[1], 10, 64)
		if err != nil {
			return SubtaskKey{}, false, fmt.Errorf("failed to parse subtsk id: %s", key)
		}
		return SubtaskKey{ParentKey: splits[0], Index: index}, true, nil
	}
	return SubtaskKey{key, 0}, false, nil
}

func (a *SubtaskKey) String() string {
	return fmt.Sprintf("%s.%d", a.ParentKey, a.Index)
}

type SubtaskKeyWithRetry struct {
	SKey     SubtaskKey
	RetryNum int64
}

func (s *SubtaskKeyWithRetry) String() string {
	return fmt.Sprintf("%s_%d", s.SKey.String(), s.RetryNum)
}
