package data

import (
	"encoding/json"
	"github.com/go-redis/redis"
	"reflect"
	"sync"
)

type RedisStore struct {
	Client *redis.Client
	TablePrefix string

	counterMutex sync.Mutex
	counters map[string]*counterValue
	fatalHandler func(err error)
}

func NewRedisStore(prefix, addr, pass string) *RedisStore {
	cli := redis.NewClient(&redis.Options{
		Addr:     addr,
		Password: pass,
		DB:       0,  // use default DB
	})

	return &RedisStore{
		Client: cli,
		TablePrefix: prefix,
		counters: make(map[string]*counterValue),
	}
}

func (rs *RedisStore) Close() {
	_ = rs.Client.Close()
	rs.Client = nil
}

func (rs *RedisStore) getKey(table string, keyName string) string {
	return rs.TablePrefix + table + "--" + keyName
}

func (rs *RedisStore) mustSucceed(err error) {
	if err != nil {
		rs.fatalHandler(err)
	}
}

func (rs *RedisStore) StoreValues(table string, data interface{}) {
	val := reflect.ValueOf(data)
	if val.Kind() != reflect.Array && val.Kind() != reflect.Slice {
		panic("A slice or an array is expected")
	}

	pairs := make([]string, 0, val.Len()*2)
	for i := 0; i < val.Len(); i++ {
		value := val.Index(i)
		if value.Type().Kind() == reflect.Ptr {
			value = value.Elem()
		}
		key := value.FieldByName("Key").String()

		bytes, e := json.Marshal(value.Interface())
		if e != nil {
			rs.fatalHandler(e)
		}

		pairs = append(pairs, rs.getKey(table, key), string(bytes))
	}
	rs.mustSucceed(rs.Client.MSet(pairs).Err())
}

func (rs *RedisStore) DeleteValue(table string, key string) {
	rs.mustSucceed(rs.Client.Unlink(rs.getKey(table, key)).Err())
}

func (rs *RedisStore) LoadValue(table string, key string, output interface{}) error {
	curVal, err := rs.Client.Get(rs.getKey(table, key)).Result()
	if err == redis.Nil {
		return NoDataError
	}
	rs.mustSucceed(err)

	return json.Unmarshal([]byte(curVal), output)
}

func (rs *RedisStore) LoadTable(table string, output interface{}) error {

	outputVal := reflect.ValueOf(output)
	if outputVal.Kind() != reflect.Ptr || reflect.Indirect(outputVal).Kind() != reflect.Slice {
		panic("Was expecting a pointer to a slice")
	}

	sliceType := reflect.Indirect(outputVal).Type()
	result := reflect.MakeSlice(sliceType, 0, 100)

	cursor := uint64(0)
	for ;; {
		var page []string
		var err error
		template := rs.getKey(table, "*")
		page, cursor, err = rs.Client.Scan(cursor, template, 1000).Result()
		rs.mustSucceed(err)

		if len(page) != 0 {
			val, err := rs.Client.MGet(page...).Result()
			rs.mustSucceed(err)

			for _, curVal := range val {
				var res= reflect.New(sliceType.Elem())
				err := json.Unmarshal([]byte(curVal.(string)), res.Interface())
				if err != nil {
					return err
				}
				result = reflect.Append(result, reflect.Indirect(res))
			}
		}

		if cursor == 0 {
			break
		}
	}

	outputVal.Elem().Set(result)
	return nil
}

func (rs *RedisStore) GetCounter(counterName string) (int64, error) {
	val, err := rs.Client.IncrBy(rs.getKey("counter", counterName), 1).Result()
	rs.mustSucceed(err)
	return val, nil
}

func (*RedisStore) InitSchema(tables map[string]int64) error {
	// No schema needed!
	return nil
}
