package data

import (
	"apollo/proto/gen/models"
	"apollo/utils"
	"bufio"
	"fmt"
	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/aws/defaults"
	"github.com/aws/aws-sdk-go-v2/service/dynamodb"
	"github.com/stretchr/testify/assert"
	"os"
	"os/exec"
	"sort"
	"strconv"
	"testing"
	"time"
)

type testContext struct {
	ddb *exec.Cmd
	conn *dynamodb.DynamoDB
	port uint16
}

//noinspection GoUnhandledErrorResult
func closeContext(ctx testContext) {
	ctx.ddb.Process.Kill()
	ctx.ddb.Wait()
}

func prepareContext(t *testing.T) testContext {
	// Get a free port
	port, e := utils.GetFreeTcpPort()
	if e != nil {
		t.FailNow()
	}

	// Try to launch the Local DDB
	cmd := exec.Command("java", "-Xmx256m",
		"-jar", "DynamoDBLocal.jar", "-inMemory", "-port", strconv.Itoa(port))
	out, _ := cmd.StdoutPipe()
	cmd.Stderr = os.Stderr
	cmd.Dir = "../localddb"
	cmd.Stdin = os.Stdin

	e = cmd.Start()
	if e != nil {
		t.Log("Can't launch DDB local")
		t.SkipNow()
	}

	scanner := bufio.NewScanner(out)
	scanner.Split(bufio.ScanWords)
	var found = false
	for {
		scanner.Scan()
		if scanner.Err() != nil {
			t.Log("Can't launch DDB local")
			t.SkipNow()
		}
		if scanner.Text() == "CorsParams:" {
			found = true
			break
		}
	}

	if !found {
		t.Log("Failed to initialize the DDB")
		t.SkipNow()
	}

	config := defaults.Config()
	config.Region = "mock-region"
	config.EndpointResolver = aws.ResolveWithEndpointURL(
		"http://localhost:" + strconv.Itoa(port))
	config.Credentials = aws.StaticCredentialsProvider{
		Value: aws.Credentials{
			AccessKeyID: "AKID", SecretAccessKey: "SECRET", SessionToken: "SESSION",
			Source: "unit test credentials",
		},
	}

	return testContext{
		conn: dynamodb.New(config),
		ddb: cmd,
		port: uint16(port),
	}
}

type TestTaskData struct {
	Key           string
	Cmd           string
	Env           map[string]string
	TimeoutMillis int64
}

func TestKvStore(t *testing.T) {
	context := prepareContext(t)
	defer func() { closeContext(context) }()

	store := NewDynamoDbStore(context.conn, "test_")
	err := store.InitSchema(map[string]int64{"table1": 100, "table2": 200})
	assert.NoError(t, err)

	doTestStore(store, t)
}

type byKeyToken []Subtask

func (s byKeyToken) Len() int {
	return len(s)
}
func (s byKeyToken) Swap(i, j int) {
	s[i], s[j] = s[j], s[i]
}
func (s byKeyToken) Less(i, j int) bool {
	return s[i].GetKey() < s[j].GetKey()
}

func doTestStore(store KVStore, t *testing.T) {
	numItems := 10000
	allData := make([]Subtask, numItems)
	for i := 0; i < numItems; i++ {
		allData[i] = Subtask{Key:     "key" + strconv.Itoa(i),
			SubtaskInfo: models.SubtaskInfo{
				Status:  models.SubtaskStateEnumStarted},
		}
	}
	store.StoreValues("table1", allData)

	for i := 0; i < numItems/10; i++ {
		var si Subtask
		assert.NoError(t, store.LoadValue("table1", "key" + strconv.Itoa(i), &si))
		assert.Equal(t, allData[i], si)
	}
	var si Subtask
	assert.Equal(t, NoDataError, store.LoadValue("table1", "doesnt", &si))

	var data []Subtask
	err := store.LoadTable("table1", &data)
	assert.NoError(t, err)
	assert.Equal(t, numItems, len(data))

	// Sort the table
	sort.Sort(byKeyToken(allData))
	sort.Sort(byKeyToken(data))

	// Assert items are equal
	for i := 0; i < numItems; i++ {
		assert.Equal(t, allData[i].Key, data[i].Key)
		assert.Equal(t, allData[i].Status, data[i].Status)
	}

	store.DeleteValue("table1", "key1")

	err = store.LoadTable("table1", &data)
	assert.NoError(t, err)
	assert.Equal(t, numItems-1, len(data))
}

func TestCounters(t *testing.T) {
	context := prepareContext(t)
	defer func() { closeContext(context) }()

	store := NewDynamoDbStore(context.conn, "test_")
	err := store.InitSchema(map[string]int64{})
	assert.NoError(t, err)

	doTestCounters(store, t)
}

func doTestCounters(store KVStore, t *testing.T) {
	counter, err := store.GetCounter("tasks")
	assert.NoError(t, err)
	assert.Equal(t, int64(1), counter)

	for i := 0; i < 1000; i++ {
		counter, err = store.GetCounter("tasks")
		assert.NoError(t, err)
		assert.Equal(t, int64(i+2), counter)
	}
}

func TestCounterPanic(t *testing.T) {
	type Counter struct {
		Key          string
		CounterValue int64
	}

	context := prepareContext(t)
	defer func() { closeContext(context) }()

	store := NewDynamoDbStore(context.conn, "test_")
	err := store.InitSchema(map[string]int64{})
	assert.NoError(t, err)

	counter, err := store.GetCounter("tasks")
	assert.NoError(t, err)
	assert.Equal(t, int64(1), counter)

	data := []Counter{{Key: "tasks", CounterValue: 0}}
	store.StoreValues("counter", data)

	assert.Panics(t, func() {
		for i := 0; i < 100; i++ {
			//noinspection GoUnhandledErrorResult
			store.GetCounter("tasks")
		}
	})
}

func TestFakeMemStore(t *testing.T) {
	store := NewFakeMemStore()

	err := store.InitSchema(map[string]int64{"table1": 100, "table2": 200})
	assert.NoError(t, err)

	for i := 0; i<100; i++ {
		counter, err := store.GetCounter("tasks")
		assert.NoError(t, err)
		assert.Equal(t, int64(i+1), counter)
	}

	numItems := 10000
	allData := make([]TestTaskData, numItems)
	for i := 0; i < numItems; i++ {
		allData[i] = TestTaskData{
			Key:           "key" + strconv.Itoa(i),
			Cmd:           "cmd--" + strconv.Itoa(i),
			Env:           map[string]string{"env1": "env2", "env3": "env4"},
			TimeoutMillis: int64(i),
		}
	}
	store.StoreValues("table1", allData)

	var data []TestTaskData
	err = store.LoadTable("table1", &data)
	assert.NoError(t, err)
	assert.Equal(t, numItems, len(data))
}

func TestRedisStore(t *testing.T) {
	redisAddr := os.Getenv("REDIS_ADDR")
	if redisAddr == "" {
		redisAddr = "localhost:6379"
	}
	redisPass := os.Getenv("REDIS_PASS")
	prefix := fmt.Sprintf("test-%d-", time.Now().Unix())

	store := NewRedisStore(prefix, redisAddr, redisPass)
	if store.Client.Ping().Err() != nil {
		t.SkipNow()
	}
	defer store.Close()

	doTestStore(store, t)
	doTestCounters(store, t)

	// Cleanup the store
	cursor := uint64(0)
	for ;; {
		var page []string
		page, cursor, _ = store.Client.Scan(cursor, prefix+"*", 1000).Result()
		if len(page) != 0 {
			store.Client.Del(page...)
		}
		if cursor == 0 {
			break
		}
	}

}
