package data

import (
	"apollo/proto/gen/models"
	"apollo/utils"
	"encoding/json"
	"fmt"
	"sync"
)

type Keyed interface {
	GetKey() string
}

func jsonString(a interface{}) string {
	bytes, e := json.Marshal(a)
	if e != nil {
		panic(e.Error())
	}
	return string(bytes)
}

type ImageUpdateRecord struct {
	UpdatedAt utils.AbsoluteTime
	ImageId string
}

// Queue
type StoredQueue struct {
	models.Queue
	Key string

	Disabled bool
	DisabledMessage string

	SubmittedOn utils.AbsoluteTime
	SubmittedBy string
}

func (a *StoredQueue) GetKey() string {
	return a.Key
}

func (a *StoredQueue) String() string {
	return jsonString(a)
}

func (a *StoredQueue) StringNoPass() string {
	tmp := *a
	tmp.DockerPassword = "CENSORED"
	return jsonString(tmp)
}

// Job Info
type JobInfo struct {
	JobName string
	MaxFailedPercentage float64
	MaxFailedCount int
}

// Node
type StoredNode struct {
	Key string
	Queue string
	CloudID string

	DockerAddress string
	CACert string
	CAKey string

	Managed bool
	Online bool

	CreatedOn utils.AbsoluteTime
	LastTransitionTime utils.AbsoluteTime
	State models.NodeStateEnum
	StateReason string

	Info models.NodeInfo

	Lock *sync.RWMutex `json:""`
}

func (s *StoredNode) GetLock() *sync.RWMutex {
	return s.Lock
}

func (s *StoredNode) GetKey() string {
	return s.Key
}

func (s *StoredNode) GetLockType() LockTarget {
	return LockNode
}

func (s *StoredNode) String() string {
	return jsonString(s)
}

func (s *StoredNode) StringNoPass() string {
	tmp := *s
	tmp.CACert = "CENSORED"
	tmp.CAKey = "CENSORED"
	return jsonString(tmp)
}

// The representation of the task array (multiple tasks that differ
// only by their index within the parent task)
type StoredTask struct {
	models.TaskStruct

	Key string
	SubmittedOn utils.AbsoluteTime
	SubmittedBy string

	OverallStatus models.TaskStateEnum
	OverallPerfStats models.TaskPerfStatsList
}

func (a *StoredTask) GetKey() string {
	return a.Key
}

func (a *StoredTask) GetLockType() LockTarget {
	return LockTask
}

func (a *StoredTask) String() string {
	return jsonString(a)
}


type Subtask struct {
	models.SubtaskInfo
	Key string
	RetryNum int64
}

func (a *Subtask) GetKey() string {
	return a.Key
}

func (a *Subtask) GetLockType() LockTarget {
	return LockSubtask
}

func (a *Subtask) GetSubtaskKey() SubtaskKey {
	return MustParseSubtaskKey(a.Key)
}

func (a *Subtask) GetSubtaskKeyWithRetry() SubtaskKeyWithRetry {
	return SubtaskKeyWithRetry {SKey: a.GetSubtaskKey(), RetryNum: a.RetryNum}
}

func (a *Subtask) String() string {
	return jsonString(a)
}

func (a *Subtask) PushCurrentAssignmentToHistory() {
	newAssignments := make(map[string]models.SubtaskAssignment)
	for k, v := range a.PriorAssignments {
		newAssignments[k] = v
	}
	newAssignments[fmt.Sprintf("%d", a.RetryNum)] = *a.CurrentAssignment
	a.PriorAssignments = newAssignments
}

func (a *Subtask) Exited() bool {
	return a.Status == models.SubtaskStateEnumDone ||
		a.Status == models.SubtaskStateEnumFailed
}
